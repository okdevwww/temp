
import Immutable from 'immutable';
import React, {View, Text} from 'react-native';
import {Button} from 'react-native-material-design';
import {shallow} from 'enzyme';

import ModalDirections from './../../../src/js/components/modal/modal-directions';

import mStyles from './../../../src/js/styles/modal-styles';

describe("<ModalDirections />", function() {

    beforeEach( (done) => {

        this._sandbox = sinon.sandbox.create();

        this.closeModalSpy = this._sandbox.spy();

        this.modalProps = {data: Immutable.fromJS({
                baseInfo: [
                    'See Stacey or Rasheed in Leasing office for KEY',
                    'No reservation required'
                ],
                additionalInfo: [
                    'Deliver after 1p',
                    'Andy has classes in the morning.',
                    'Row house. Sofa didnt fit in the door on initial delivery.'
                ]
            })
        };

        this.getElement = (modalProps = this.modalProps, closeModal = this.closeModalSpy) => {
            return (<ModalDirections
                        modalProps={modalProps}
                        closeModal={this.closeModalSpy} />);
        };

        done();
    });

    afterEach( (done) => {
        this._sandbox.restore();
        done();
    });

    it("should render View container", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View).first();

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.equal(mStyles.modal);
        done();
    });

    it("should render title Text", (done) => {

        const wrapper = shallow(this.getElement());
        const text = wrapper.find(Text).first();

        expect(text.length).to.equal(1);
        expect(text.prop('style')).to.equal(mStyles.title);
        expect(text.prop('children')).to.equal('Delivery Instructions');
        done();
    });

    it("should render content Views", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.findWhere( (element) => {
            return element.prop('style') === mStyles.text;
        });

        expect(view.length).to.equal(2);
        done();
    });

    it("should render content Texts", (done) => {

        const wrapper = shallow(this.getElement());
        const text = wrapper.find(Text);

        expect(text.length).to.equal(6);
        expect(text.at(1).prop('children')).to.equal(this.modalProps.data.getIn(['baseInfo', 0]));
        expect(text.at(2).prop('children')).to.equal(this.modalProps.data.getIn(['baseInfo', 1]));
        expect(text.at(3).prop('children')).to.equal(this.modalProps.data.getIn(['additionalInfo', 0]));
        expect(text.at(4).prop('children')).to.equal(this.modalProps.data.getIn(['additionalInfo', 1]));
        expect(text.at(5).prop('children')).to.equal(this.modalProps.data.getIn(['additionalInfo', 2]));

        done();
    });

    it("should render button container View", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.findWhere( (element) => {
            return element.prop('style') === mStyles.buttonContainer;
        });

        expect(view.length).to.equal(1);
        done();
    });

    it("should render Button", (done) => {

        const wrapper = shallow(this.getElement());
        const button = wrapper.find(Button);

        expect(button.length).to.equal(1);
        expect(button.prop('primary')).to.equal('googleRed');
        expect(button.prop('theme')).to.equal('dark');
        expect(button.prop('raised')).to.equal(true);
        expect(button.prop('text')).to.equal('DONE');
        done();
    });

    it("should call closeModal when button is pressed", (done) => {
        const wrapper = shallow(this.getElement());
        const button = wrapper.find(Button);

        button.simulate('press');

        expect(this.closeModalSpy.called).to.be(true);
        done();
    });

});

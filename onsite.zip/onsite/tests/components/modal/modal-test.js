

import Immutable from 'immutable';
import React, {View, Modal} from 'react-native';
import {shallow} from 'enzyme';

import ModalDirections from './../../../src/js/components/modal/modal-directions';
import ModalConfirmation from './../../../src/js/components/modal/modal-confirmation';
import ModalCustom from  './../../../src/js/components/modal/modal';

import mStyles from './../../../src/js/styles/modal-styles';

describe("<Modal />", function() {

    beforeEach( (done) => {

        this._sandbox = sinon.sandbox.create();

        this.openModalSpy = this._sandbox.spy();
        this.closeModalSpy = this._sandbox.spy();

        this.getElement = (modalType = '', modalProps = {}) => {
            return (<ModalCustom
                        modalType={modalType}
                        modalProps={modalProps}
                        openModal={this.openModalSpy}
                        closeModal={this.closeModalSpy} />);
        };

        done();
    });

    afterEach( (done) => {
        this._sandbox.restore();
        done();
    });

    it("should not render modal", (done) => {

        const wrapper = shallow(this.getElement());
        const modal = wrapper.find(Modal);

        expect(modal.length).to.equal(0);
        done();
    });

    it("should render modal container and ModalDirections", (done) => {
        const wrapper = shallow(this.getElement('directions', {'test': 'props'}));

        const modal = wrapper.find(Modal);

        expect(modal.prop('animationType')).to.equal('none');
        expect(modal.prop('transparent')).to.equal(true);

        const view = wrapper.find(View);

        expect(view.length).to.equal(2);
        expect(view.first().prop("style")).to.equal(mStyles.page);
        expect(view.last().prop("style")).to.equal(mStyles.overlay);

        const modalDirections = wrapper.find(ModalDirections);
        expect(modalDirections.length).to.equal(1);
        expect(modalDirections.props()).to.eql({
            modalType: 'directions',
            modalProps: {'test': 'props'},
            openModal: this.openModalSpy,
            closeModal: this.closeModalSpy
        });

        done();
    });

    it("should render modal container and ModalConfirmation", (done) => {
        const wrapper = shallow(this.getElement('confirmation', {'test': 'props'}));

        const modal = wrapper.find(Modal);

        expect(modal.prop('animationType')).to.equal('none');
        expect(modal.prop('transparent')).to.equal(true);

        const view = wrapper.find(View);

        expect(view.length).to.equal(2);
        expect(view.first().prop("style")).to.equal(mStyles.page);
        expect(view.last().prop("style")).to.equal(mStyles.overlay);

        const modalConfirmation = wrapper.find(ModalConfirmation);
        expect(modalConfirmation.length).to.equal(1);
        expect(modalConfirmation.props()).to.eql({
            modalType: 'confirmation',
            modalProps: {'test': 'props'},
            openModal: this.openModalSpy,
            closeModal: this.closeModalSpy
        });

        done();
    });

});

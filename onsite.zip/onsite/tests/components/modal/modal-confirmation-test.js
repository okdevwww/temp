
import Immutable from 'immutable';
import React, {View, Text} from 'react-native';
import {Button} from 'react-native-material-design';
import {shallow} from 'enzyme';

import ModalConfirmation from './../../../src/js/components/modal/modal-confirmation';

import mStyles from './../../../src/js/styles/modal-styles';

describe("<ModalConfirmation />", function() {

    beforeEach( (done) => {

        this._sandbox = sinon.sandbox.create();
        this.closeModalSpy = this._sandbox.spy();
        this.onClose = this._sandbox.spy();

        this.modalProps = {
            title: 'Confirm signature save',
            text: 'Are you sure you want to save this signature?',
            onClose: this.onClose
        };

        this.getElement = (modalProps = this.modalProps, closeModal = this.closeModalSpy) => {
            return (<ModalConfirmation
                        modalProps={modalProps}
                        closeModal={this.closeModalSpy} />);
        };

        done();
    });

    afterEach( (done) => {
        this._sandbox.restore();
        done();
    });

    it("should render View container", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View).first();

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.equal(mStyles.modal);
        done();
    });

    it("should render title Text", (done) => {

        const wrapper = shallow(this.getElement());
        const text = wrapper.find(Text).first();

        expect(text.length).to.equal(1);
        expect(text.prop('style')).to.equal(mStyles.title);
        expect(text.prop('children')).to.equal(this.modalProps.title);
        done();
    });

    it("should render content View and Text", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View).at(1);
        const text = wrapper.find(Text).at(1);

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.equal(mStyles.text);

        expect(text.length).to.equal(1);
        expect(text.prop('children')).to.equal(this.modalProps.text);

        done();
    });

    it("should render buttons container View", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.findWhere( (element) => {
            return element.prop('style') === mStyles.buttonContainer;
        });

        expect(view.length).to.equal(1);
        done();
    });

    it("should render Buttons", (done) => {

        const wrapper = shallow(this.getElement());
        const button = wrapper.find(Button);

        expect(button.length).to.equal(2);
        expect(button.first().prop('primary')).to.equal('googleRed');
        expect(button.first().prop('theme')).to.equal('dark');
        expect(button.first().prop('raised')).to.equal(true);
        expect(button.first().prop('text')).to.equal('NO');

        expect(button.last().prop('primary')).to.equal('googleRed');
        expect(button.last().prop('theme')).to.equal('dark');
        expect(button.last().prop('raised')).to.equal(true);
        expect(button.last().prop('text')).to.equal('YES');
        done();
    });

    it("should call closeModal when NO button is pressed", (done) => {
        const wrapper = shallow(this.getElement());
        const button = wrapper.find(Button);

        button.first().simulate('press');

        expect(this.closeModalSpy.called).to.be(true);
        expect(this.modalProps.onClose.called).to.be(false);
        done();
    });

    it("should call closeModal and onClose when YES button is pressed", (done) => {
        const wrapper = shallow(this.getElement());
        const button = wrapper.find(Button);

        button.last().simulate('press');

        expect(this.closeModalSpy.called).to.be(true);
        expect(this.modalProps.onClose.called).to.be(true);
        done();
    });

});


import React, {TouchableHighlight, View, Text} from 'react-native';
import {shallow} from 'enzyme';
import FooterButton from './../../../src/js/components/footer/footer-button';
import fStyles from './../../../src/js/styles/footer-styles';
import AppInitialState from './../../../src/js/app-state/app-initial-state';
import Icon from 'react-native-vector-icons/MaterialIcons';

describe("<FooterButton />", function() {

    beforeEach( (done) => {

        this._sandbox = sinon.sandbox.create();

        this.btn = AppInitialState.buttons.first();
        this.onPressSpy = this._sandbox.spy();

        this.getElement = (btn = this.btn, onPress = this.onPressSpy) => {
            return (<FooterButton
                        btn={btn}
                        onPress={onPress} />);
        };

        done();
    });

    afterEach( (done) => {

        this._sandbox.restore();

        done();
    });

    it("should render element", (done) => {

        const wrapper = shallow(this.getElement());

        expect(wrapper.length).to.equal(1);
        expect(wrapper.prop('onPress')).to.equal(wrapper.instance().onPress);

        done();
    });

    it("should render container View", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View);

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.eql(fStyles.button);
        done();
    });

    // TO DO
    // unit test for Icon and Text

});


import React, {View} from 'react-native';
import {shallow} from 'enzyme';
import Footer from './../../src/js/components/footer';
import FooterButton from './../../src/js/components/footer/footer-button';

import fStyles from './../../src/js/styles/footer-styles';

import AppInitialState from './../../src/js/app-state/app-initial-state';


describe("<Footer />", function() {

    beforeEach( (done) => {

        this._sandbox = sinon.sandbox.create();

        this.scene = {sceneKey: 'stops'};
        this.btns = AppInitialState.buttons;
        this.session = AppInitialState.session.set('id', '1234');
        this.onButtonPressSpy = this._sandbox.spy();

        this.getElement = (scene = this.scene, buttons = this.btns, session = this.session, onButtonPress = this.onButtonPressSpy) => {
            return (<Footer
                        scene={scene}
                        btns={buttons}
                        session={session}
                        onButtonPress={onButtonPress} />);
        };

        done();
    });

    afterEach( (done) => {

        this._sandbox.restore();

        done();
    });

    it("should not render footer when session id is not set", (done) => {

        const wrapper = shallow(this.getElement(this.scene, this.btns, AppInitialState.session));
        const view = wrapper.find(View);

        expect(view.length).to.equal(0);
        done();
    });

    it("should not render footer when in login scene", (done) => {
        const scene = {sceneKey: 'login'};
        const wrapper = shallow(this.getElement(scene));
        const view = wrapper.find(View);

        expect(view.length).to.equal(0);
        done();
    });

    it("should render container View", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View);

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.eql(fStyles.container);
        done();
    });

    it("should render footer buttons", (done) => {
        const wrapper = shallow(this.getElement());
        const btns = wrapper.find(FooterButton);

        expect(btns.length).to.eql(this.btns.size);
        done();
    });

    it("should pass props to buttons", (done) => {
        const wrapper = shallow(this.getElement());
        const first = wrapper.find(FooterButton).first();

        expect(first.prop('btn')).to.equal(this.btns.first());
        expect(first.prop('onPress')).to.equal(this.onButtonPressSpy);
        done();
    });

});

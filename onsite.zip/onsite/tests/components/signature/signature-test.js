
import Immutable from 'immutable';
import React, {View, Text, TouchableHighlight, Image} from 'react-native';
import {shallow} from 'enzyme';

import SignatureCapture from 'react-native-signature-capture';

import Signature from './../../../src/js/components/signature/signature';
import sStyles from './../../../src/js/styles/signature-styles';

describe("<Signature />", function() {

    beforeEach( () => {

        this._sandbox = sinon.sandbox.create();

        this.signature = Immutable.Map({
            driverSignature: null,
            customerSignature: null
        });
        this.onSaveSignaturesSpy = this._sandbox.spy();
        this.onClearSignaturesSpy = this._sandbox.spy();
        this.onCancelSignaturesSpy = this._sandbox.spy();
        this.openModalSpy = this._sandbox.spy();

        this.getElement = (signature = this.signature) => {
            return (<Signature
                        signature={signature}
                        onSaveSignatures={this.onSaveSignaturesSpy}
                        onClearSignatures={this.onClearSignaturesSpy}
                        onCancelSignatures={this.onCancelSignaturesSpy}
                        openModal={this.openModalSpy} />);
        };

    });

    afterEach( (done) => {
        this._sandbox.restore();
        done();
    });

    it("should render container View", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View).first();

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.eql(sStyles.signaturesContainer);

        done();
    });

    it("should render signature sub-container View", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View).at(1);

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.eql(sStyles.signaturesSubContainer);

        done();
    });

    it("should render driver and customer signatures containers", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.findWhere( (element) => {
            return element.prop('style') === sStyles.signature;
        });

        expect(view.length).to.equal(2);

        done();
    });

    it("should render SignatureCapture for driver and customer", (done) => {

        const wrapper = shallow(this.getElement());
        const sig = wrapper.find(SignatureCapture);

        expect(sig.length).to.equal(2);

        const cust = sig.first();

        expect(cust.prop('onSaveEvent')).to.equal(wrapper.instance().onSaveCustomerSign);
        expect(cust.prop('onDragEvent')).to.equal(wrapper.instance().onDragEventCustomer);
        expect(cust.prop('saveImageFileInExtStorage')).to.equal(true);
        expect(cust.prop('showNativeButtons')).to.equal(false);
        expect(cust.prop('viewMode')).to.equal('portrait');

        const driv = sig.last();

        expect(driv.prop('onSaveEvent')).to.equal(wrapper.instance().onSaveDriverSign);
        expect(driv.prop('onDragEvent')).to.equal(wrapper.instance().onDragEventDriver);
        expect(driv.prop('saveImageFileInExtStorage')).to.equal(true);
        expect(driv.prop('showNativeButtons')).to.equal(false);
        expect(driv.prop('viewMode')).to.equal('portrait');

        done();
    });

    it("should render caption Text for driver and customer", (done) => {

        const wrapper = shallow(this.getElement());
        const text = wrapper.findWhere( (element) => {
            return element.prop('style') === sStyles.textRotated;
        });

        expect(text.length).to.equal(2);
        expect(text.first().prop('children')).to.equal('Customer Signature');
        expect(text.last().prop('children')).to.equal('Driver Signature');

        done();
    });

    it("should render driver and customer signature Images", (done) => {
        const signature = Immutable.Map({
            driverSignature: { 'testDriver': 'signature'},
            customerSignature: { 'testCustomer': 'signature'}
        });

        const wrapper = shallow(this.getElement(signature));
        const img = wrapper.find(Image);

        expect(img.length).to.equal(2);
        expect(img.first().prop('style')).to.equal(sStyles.signatureImage);
        expect(img.first().prop('source')).to.equal(signature.get('customerSignature'));
        expect(img.last().prop('style')).to.equal(sStyles.signatureImage);
        expect(img.last().prop('source')).to.equal(signature.get('driverSignature'));

        done();
    });

    it("should render signature buttons", (done) => {
        const wrapper = shallow(this.getElement());
        const touchable = wrapper.find(TouchableHighlight);

        expect(touchable.length).to.equal(3);
        expect(touchable.first().prop('style')).to.equal(sStyles.buttonStyle);
        expect(touchable.first().prop('onPress')).to.equal(wrapper.instance().resetSign);
        expect(touchable.at(1).prop('style')).to.eql([sStyles.buttonStyle, sStyles.buttonStyleBordered]);
        expect(touchable.at(1).prop('onPress')).to.equal(wrapper.instance().cancel);
        expect(touchable.last().prop('style')).to.eql([sStyles.buttonStyle, sStyles.buttonStyleFilled]);
        expect(touchable.last().prop('onPress')).to.equal(wrapper.instance().saveSign);

        const text = wrapper.find(Text);

        expect(text.length).to.equal(5);

        expect(text.at(2).prop('style')).to.eql([sStyles.buttonText, sStyles.buttonTextReverted]);
        expect(text.at(2).prop('children')).to.eql('CLEAR');
        expect(text.at(3).prop('style')).to.eql([sStyles.buttonText, sStyles.buttonTextReverted]);
        expect(text.at(3).prop('children')).to.eql('CANCEL');
        expect(text.at(4).prop('style')).to.eql(sStyles.buttonText);
        expect(text.at(4).prop('children')).to.eql('SAVE');

        done();
    });

    it("should call resetSign when CLEAR button is pressed", (done) => {

        /*
        const onSaveCustomerSign = this._sandbox.stub(Signature.prototype, 'onSaveCustomerSign');
        const onDragEventCustomer = this._sandbox.stub(Signature.prototype, 'onDragEventCustomer');
        const onSaveDriverSign = this._sandbox.stub(Signature.prototype, 'onSaveDriverSign');
        const onDragEventDriver = this._sandbox.stub(Signature.prototype, 'onDragEventDriver');
        */

        const resetSign = this._sandbox.stub(Signature.prototype, 'resetSign');

        const wrapper = shallow(this.getElement());
        const touchable = wrapper.find(TouchableHighlight);

        touchable.first().simulate('press');

        expect(resetSign.called).to.equal(true);

        done();
    });

    it("should call cancel when CANCEL button is pressed", (done) => {

        const cancel = this._sandbox.stub(Signature.prototype, 'cancel');
        const wrapper = shallow(this.getElement());
        const touchable = wrapper.find(TouchableHighlight);

        touchable.at(1).simulate('press');

        expect(cancel.called).to.equal(true);

        done();
    });

    it("should call onCancelSignatures when CANCEL button is pressed", (done) => {

        const wrapper = shallow(this.getElement());
        const touchable = wrapper.find(TouchableHighlight);

        touchable.at(1).simulate('press');

        expect(this.onCancelSignaturesSpy.called).to.equal(true);

        done();
    });

    it("should call saveSign when SAVE button is pressed", (done) => {

        const saveSign = this._sandbox.stub(Signature.prototype, 'saveSign');
        const wrapper = shallow(this.getElement());
        const touchable = wrapper.find(TouchableHighlight);

        touchable.at(2).simulate('press');

        expect(saveSign.called).to.equal(true);

        done();
    });

    it("should call openModal when SAVE button is pressed", (done) => {

        const wrapper = shallow(this.getElement());
        const touchable = wrapper.find(TouchableHighlight);

        wrapper.setState({ 'driverSigned': true});
        touchable.at(2).simulate('press');

        const expectedCalledWithParam = {
            title: 'Confirm save signature',
            text: 'Are you sure you want to save this signature?',
            onClose: wrapper.instance().onSaveModal
        };

        expect(this.openModalSpy.called).to.equal(true);
        expect(this.openModalSpy.calledWith('confirmation', expectedCalledWithParam)).to.equal(true);

        done();
    });
});

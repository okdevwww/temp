
import React, {View, Text} from 'react-native';
import {shallow} from 'enzyme';

import config from './../../src/js/config/config';
import Header from './../../src/js/components/header';
import hStyles from './../../src/js/styles/header-styles';


describe("<Header />", function() {

    beforeEach( (done) => {
        this.getElement = () => {
            return (<Header />);
        };

        done();
    });

    afterEach( (done) => {
        done();
    });

    it("should render 3 Views", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View);

        expect(view.length).to.equal(3);
        done();
    });

    it("should render container View", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View).first();

        expect(view.prop('style')).to.eql(hStyles.header);
        done();
    });

    it("should render logo View", (done) => {
        const wrapper = shallow(this.getElement());
        const logoView = wrapper.find(View).at(1);

        expect(logoView.length).to.eql(1);
        expect(logoView.prop('style')).to.eql(hStyles.logo);

        const text = logoView.find(Text);
        expect(text.length).to.equal(1);
        expect(text.prop('style')).to.equal(hStyles.companyName);
        expect(text.prop('children')).to.equal(config.companyName);
        done();
    });

    it("should render appName View", (done) => {
        const wrapper = shallow(this.getElement());
        const appTitleView = wrapper.find(View).at(2);

        expect(appTitleView.length).to.eql(1);
        expect(appTitleView.prop('style')).to.eql(hStyles.app);

        const text = appTitleView.find(Text);
        expect(text.length).to.equal(1);
        expect(text.prop('style')).to.equal(hStyles.appName);
        expect(text.prop('children')).to.equal(config.appTitle);
        done();
    });

});

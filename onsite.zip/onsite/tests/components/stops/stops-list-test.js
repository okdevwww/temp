

import Immutable from 'immutable';
import React, {View, ScrollView} from 'react-native';
import {shallow} from 'enzyme';

import StopsList from './../../../src/js/components/stops/stops-list';
import Stop from './../../../src/js/components/stops/stop';
import slStyles from './../../../src/js/styles/stops-list-styles';

import {stopsData, itemsData} from './../../reducers/reducers-data';
import stops from './../../../src/js/reducers/stops-reducers';
import {RECEIVE_STOPS} from './../../../src/js/actions/actions';

describe("<StopsList />", function() {

    beforeEach( (done) => {

        this._sandbox = sinon.sandbox.create();
        const action = {
            type: RECEIVE_STOPS,
            stops: { value: stopsData },
            items: { value: itemsData }
        }
        this.stops = stops(Immutable.Map({}), action);
        this.onStopPress = this._sandbox.spy();

        this.getElement = (stp = this.stops, onStopPress = this.onStopPress) => {
            return (<StopsList
                    stops={stp}
                    onStopPress={onStopPress} />);
        };

        done();
    });

    afterEach( (done) => {
        this._sandbox.restore();
        done();
    });

    it("should render StopsList container View", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View);

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.equal(slStyles.container);
        done();
    });

    it("should render StopsList ScrollView", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(ScrollView);

        expect(view.length).to.eql(1);
        expect(view.prop('contentContainerStyle')).to.eql(slStyles.scrollContainer);
        done();
    });

    it("should render Stop components", (done) => {
        const wrapper = shallow(this.getElement());
        const stopsEl = wrapper.find(Stop);


        expect(stopsEl.length).to.equal(3);

        const firstStop = stopsEl.first();

        expect(firstStop.prop('stop')).to.eql(this.stops.first());
        expect(firstStop.prop('onPress')).to.eql(this.onStopPress);
        expect(firstStop.prop('id')).to.equal('3');

        done();
    });

});

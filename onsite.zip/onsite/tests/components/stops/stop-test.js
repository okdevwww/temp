

import Immutable from 'immutable';
import React, {View, Text} from 'react-native';
import {Card, Button} from 'react-native-material-design';
import Icon from 'react-native-vector-icons/MaterialIcons';

import {shallow} from 'enzyme';

import Stop from './../../../src/js/components/stops/stop';
import slStyles from './../../../src/js/styles/stops-list-styles';

import {stopsData, itemsData} from './../../reducers/reducers-data';
import stops from './../../../src/js/reducers/stops-reducers';
import {RECEIVE_STOPS} from './../../../src/js/actions/actions';

describe("<Stop />", function() {

    beforeEach( (done) => {

        this._sandbox = sinon.sandbox.create();
        const action = {
            type: RECEIVE_STOPS,
            stops: { value: stopsData },
            items: { value: itemsData }
        }
        this.stop = stops(Immutable.Map({}), action).first();
        this.onPress = this._sandbox.spy();

        this.getElement = (stp = this.stop, onPress = this.onPress) => {
            return (<Stop
                        stop={stp}
                        onPress={onPress}
                        id={this.stop.get('STOP_ID')} />);
        };

        done();
    });

    afterEach( (done) => {
        this._sandbox.restore();
        done();
    });

    it("should render Card container", (done) => {

        const wrapper = shallow(this.getElement());
        const card = wrapper.find(Card);

        expect(card.length).to.equal(1);
        expect(card.prop('style')).to.equal(slStyles.stop);
        done();
    });

    it("should render bordered View", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View).first();

        expect(view.length).to.eql(1);
        expect(view.prop('style')).to.eql(slStyles.containerBordered);
        done();
    });

    it("should render Stop body View", (done) => {
        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View);

        const bodyView = wrapper.find(View).at(1);
        expect(bodyView.length).to.equal(1);
        expect(bodyView.prop('style')).to.eql(slStyles.stopBody);

        done();
    });

    it("should render Stop stop number container", (done) => {
        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View).at(2);

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.eql(slStyles.stopIconContainer);

        done();
    });

    it("should render Stop number Text", (done) => {
        const wrapper = shallow(this.getElement());
        const text = wrapper.find(Text).first();

        expect(text.length).to.equal(1);
        expect(text.prop('style')).to.eql(slStyles.stopIcon);
        expect(text.prop('children')).to.eql(this.stop.get('STOP_ID'));

        done();
    });

    it("should render Stop details container", (done) => {
        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View).at(3);

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.eql(slStyles.stopDetails);

        done();
    });

    it("should render Stop name container", (done) => {
        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View).at(4);

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.eql(slStyles.stopName);

        done();
    });

    it("should render Stop name", (done) => {
        const wrapper = shallow(this.getElement());
        const text = wrapper.find(Text).at(1);

        expect(text.length).to.equal(1);
        expect(text.prop('children')).to.eql(this.stop.get('SHIPTO_NAME1'));

        done();
    });

    it("should render Stop detail containers", (done) => {
        const wrapper = shallow(this.getElement());
        const view = wrapper.findWhere( (element) => {
            return element.prop('style') === slStyles.stopDetail
        });

        expect(view.length).to.equal(3);

        done();
    });

    it("should render location Icon and phone Icon", (done) => {
        const wrapper = shallow(this.getElement());
        const icon = wrapper.find(Icon);

        expect(icon.length).to.equal(2);
        expect(icon.at(0).prop('name')).to.eql('location-on');
        expect(icon.at(0).prop('size')).to.eql('20');
        expect(icon.at(0).prop('style')).to.eql(slStyles.stopDetailIcon);

        expect(icon.at(1).prop('name')).to.eql('phone');
        expect(icon.at(1).prop('size')).to.eql('20');
        expect(icon.at(1).prop('style')).to.eql(slStyles.stopDetailIcon);

        done();
    });

    it("should render Stop detail content", (done) => {
        const wrapper = shallow(this.getElement());
        const view = wrapper.findWhere( (element) => {
            return element.prop('style') === slStyles.stopDetailContent;
        });

        const viewNoIcon = wrapper.findWhere( (element) => {
            return element.prop('style') === slStyles.stopDetailContentNoIcon;
        });

        expect(view.length).to.equal(2);
        expect(viewNoIcon.length).to.equal(1);

        done();
    });

    it("should render Stop address content texts", (done) => {
        const wrapper = shallow(this.getElement());
        const text = wrapper.find(Text);

        expect(text.at(2).prop('children')).to.eql('Address');
        expect(text.at(3).prop('children')).to.eql(this.stop.get('SHIPTO_ADDRESS1'));
        expect(text.at(4).prop('children')).to.eql(this.stop.get('SHIPTO_ADDRESS2'));
        expect(text.at(5).prop('children')).to.eql([this.stop.get('SHIPTO_CITY'), ', ', this.stop.get('SHIPTO_STATE'), ' ', this.stop.get('SHIPTO_ZIP')]);

        done();
    });

    it("should render Stop phone content texts", (done) => {
        const wrapper = shallow(this.getElement());
        const text = wrapper.find(Text);

        expect(text.at(6).prop('children')).to.eql('Contact Number');
        expect(text.at(7).prop('children')).to.eql(this.stop.get('SHIPTO_PHONE_NBR'));

        done();
    });

    it("should render Stop quantity content texts", (done) => {
        const wrapper = shallow(this.getElement());
        const text = wrapper.find(Text);

        expect(text.at(8).prop('children')).to.eql('Quantity');
        expect(text.at(9).prop('children')).to.eql([this.stop.get('DELIVERY_QTY'), ' ', this.stop.get('PICKUP_QTY')]);

        done();
    });

    it("should render Stop actions container", (done) => {
        const wrapper = shallow(this.getElement());
        const view = wrapper.findWhere( (element) => {
            return element.prop('style') === slStyles.stopActions;
        });

        expect(view.length).to.eql(1);

        done();
    });

    it("should render Stop start button", (done) => {
        const wrapper = shallow(this.getElement());
        const btn = wrapper.find(Button);

        expect(btn.length).to.eql(1);
        expect(btn.prop('primary')).to.eql('googleRed');
        expect(btn.prop('theme')).to.eql('dark');
        expect(btn.prop('raised')).to.eql(true);
        expect(btn.prop('text')).to.eql('START');
        done();
    });

    it('should call onPress function when start button is pressed', (done) => {
        const wrapper = shallow(this.getElement());
        const btn = wrapper.find(Button);

        btn.simulate('press');

        expect(this.onPress.called).to.be(true);
        expect(this.onPress.calledWith(this.stop.get('STOP_ID'))).to.be(true);

        done();
    });

});

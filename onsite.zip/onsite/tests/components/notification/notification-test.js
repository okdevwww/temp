
import React, {View, Text} from 'react-native';
import {shallow} from 'enzyme';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Notification from './../../../src/js/components/notification/notification';
import nStyles from './../../../src/js/styles/notification-styles';

describe("<Notification />", function() {

    beforeEach( () => {

        this._sandbox = sinon.sandbox.create();
        this.removeNotificationSpy = this._sandbox.spy();

        this.getElement = (notification = null, removeNotification = this.removeNotificationSpy) => {
            return (<Notification
                        notification={notification}
                        removeNotification={removeNotification} />);
        };

        this.setTimerSpy = this._sandbox.stub(Notification.prototype, 'setTimer');

    });

    afterEach( (done) => {
        this._sandbox.restore();
        done();
    });

    it("should render 1 empty view", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View);

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.eql(nStyles.container);

        const text = wrapper.find(Text);
        expect(text.length).to.equal(0);

        done();
    });

    it("should render View and notification Text", (done) => {
        const wrapper = shallow(this.getElement('test'));
        const view = wrapper.find(View);
        const text = wrapper.find(Text);

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.eql([nStyles.container]);
        expect(text.length).to.equal(1);
        expect(text.prop('style')).to.eql([nStyles.text]);
        expect(text.prop('children')).to.equal('test');

        done();
    });

    it("should render notification Icon", (done) => {
         const wrapper = shallow(this.getElement('test'));
         const icon = wrapper.find(Icon);

         expect(icon.length).to.equal(1);
         expect(icon.prop('name')).to.equal('report-problem');
         expect(icon.prop('size')).to.equal(16);
         expect(icon.prop('style')).to.equal(nStyles.icon);

         done();
    });

    it("should setTimer to call removeNotification", (done) => {
        const wrapper = shallow(this.getElement('test'));

        expect(this.setTimerSpy.called).to.be(true);
        done();
    });

});



import Immutable from 'immutable';
import React, {View, Text} from 'react-native';
import {shallow} from 'enzyme';

import SubHeader from './../../src/js/components/sub-header';
import shStyles from './../../src/js/styles/sub-header-styles';


describe("<SubHeader />", function() {

    beforeEach( (done) => {

        const session = Immutable.fromJS({'id': '1234'});
        this.scene = {sceneKey: 'stops'};

        this.getElement = (scene = this.scene, sess = session) => {
            return (<SubHeader
                        scene={scene}
                        session={sess} />);
        };

        done();
    });

    afterEach( (done) => {
        done();
    });

    it("should not render header if no session id", (done) => {
        const session = Immutable.fromJS({'id': null});
        const wrapper = shallow(this.getElement(this.scene, session));
        const view = wrapper.find(View);

        expect(view.length).to.equal(0);
        done();
    });

    it("should not render header if scene is login", (done) => {
        const scene = {sceneKey: 'login'};
        const wrapper = shallow(this.getElement(scene));
        const view = wrapper.find(View);

        expect(view.length).to.equal(0);
        done();
    });

    it("should render container View", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View).first();

        expect(view.length).to.eql(1);
        expect(view.prop('style')).to.eql(shStyles.container);
        done();
    });

    it("should render SubHeader Text elements", (done) => {
        const wrapper = shallow(this.getElement());
        const routeId = wrapper.find(Text).first();
        const driver = wrapper.find(Text).last();

        expect(routeId.length).to.equal(1);
        expect(routeId.prop('style')).to.eql(shStyles.route);

        expect(driver.length).to.equal(1);
        expect(driver.prop('style')).to.eql(shStyles.driver);
        done();
    });

});

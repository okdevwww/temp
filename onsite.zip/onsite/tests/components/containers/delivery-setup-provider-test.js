
import React from 'react';
import {mount} from 'enzyme';

import DeliverySetupProvider from './../../../src/js/components/containers/delivery-setup-provider';
import DeliverySetup from './../../../src/js/components/delivery-setup/delivery-setup';

import SetupStore from './setup-store';

describe('Provider delivery setup', function() {

    beforeEach( (done) => {
        this.getElement = () => {
            return SetupStore.getElement(<DeliverySetupProvider />);
        };
        this.state = SetupStore.getInitialState();

        done();
    });

    afterEach( (done) => {

        this.getElement = null;
        this.state = null;

        done();
    });

    it('should map state to props', (done) => {

        const wrapper = mount(this.getElement());
        const props = wrapper.find(DeliverySetup).props();

        expect(props.stops).to.equal(this.state.stops);

        done();
    });

    it('should map dispatch to props', (done) => {
        const wrapper = mount(this.getElement());
        const props = wrapper.find(DeliverySetup).props();

        expect(props.checkDeliveryItem).to.be.a('function');

        done();
    });

});


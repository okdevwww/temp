
import React from 'react';
import {mount} from 'enzyme';

import LoginProvider from './../../../src/js/components/containers/login-provider';
import Login from './../../../src/js/components/login/login';

import SetupStore from './setup-store';

describe('Provider login', function() {

    beforeEach( (done) => {
        this.getElement = () => {
            return SetupStore.getElement(<LoginProvider />);
        };
        this.state = SetupStore.getInitialState();

        done();
    });

    afterEach( (done) => {

        this.getElement = null;
        this.state = null;

        done();
    });

    it('should map state to props', (done) => {

        const wrapper = mount(this.getElement());
        const props = wrapper.find(Login).props();

        expect(props.session).to.equal(this.state.session);

        done();
    });

    it('should map dispatch to props', (done) => {
        const wrapper = mount(this.getElement());
        const props = wrapper.find(Login).props();

        expect(props.login).to.be.a('function');

        done();
    });

});


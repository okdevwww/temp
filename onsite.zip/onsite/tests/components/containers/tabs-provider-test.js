
import React from 'react';
import {mount} from 'enzyme';

import TabsProvider from './../../../src/js/components/containers/tabs-provider';
import TabsList from './../../../src/js/components/tabs/tabs-list';

import SetupStore from './setup-store';

describe('Provider tabs', function() {

    beforeEach( (done) => {
        this.getElement = () => {
            return SetupStore.getElement(<TabsProvider />);
        };
        this.state = SetupStore.getInitialState();

        done();
    });

    afterEach( (done) => {

        this.getElement = null;
        this.state = null;

        done();
    });

    it('should map state to props', (done) => {

        const wrapper = mount(this.getElement());
        const props = wrapper.find(TabsList).props();

        expect(props.tabs).to.equal(this.state.tabs);
        expect(props.keyRelease).to.equal(this.state.keyRelease);

        done();
    });

    it('should map dispatch to props', (done) => {
        const wrapper = mount(this.getElement());
        const props = wrapper.find(TabsList).props();

        expect(props.onTabPress).to.be.a('function');
        expect(props.openModal).to.be.a('function');

        done();
    });

});



import React from 'react';
import {mount} from 'enzyme';

import ButtonsProvider from '../../../src/js/components/containers/footer-provider';
import Footer from './../../../src/js/components/footer';

import SetupStore from './setup-store';

describe('Provider buttons', function() {

    beforeEach( (done) => {
        this.getElement = () => {
            return SetupStore.getElement(<ButtonsProvider />);
        };
        this.state = SetupStore.getInitialState();

        done();
    });

    afterEach( (done) => {

        this.getElement = null;
        this.state = null;

        done();
    });

    it('should map state to props', (done) => {

        const wrapper = mount(this.getElement());
        const props = wrapper.find(Footer).props();

        expect(props.scene).to.equal(this.state.scene);
        expect(props.btns).to.equal(this.state.buttons);
        expect(props.session).to.equal(this.state.session);

        done();
    });

    it('should map dispatch to props', (done) => {
        const wrapper = mount(this.getElement());
        const props = wrapper.find(Footer).props();

        expect(props.onButtonPress).to.be.a('function');

        done();
    });

});



import React from 'react';
import {mount} from 'enzyme';

import SubHeaderProvider from './../../../src/js/components/containers/sub-header-provider';
import SubHeader from './../../../src/js/components/sub-header';

import SetupStore from './setup-store';

describe('Provider sub header', function() {

    beforeEach( (done) => {
        this.getElement = () => {
            return SetupStore.getElement(<SubHeaderProvider />);
        };
        this.state = SetupStore.getInitialState();

        done();
    });

    afterEach( (done) => {

        this.getElement = null;
        this.state = null;

        done();
    });

    it('should map state to props', (done) => {

        const wrapper = mount(this.getElement());
        const props = wrapper.find(SubHeader).props();

        expect(props.scene).to.equal(this.state.scene);
        expect(props.session).to.equal(this.state.session);

        done();
    });

});


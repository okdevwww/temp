
import React from 'react';
import {mount} from 'enzyme';

import SignatureProvider from './../../../src/js/components/containers/signature-provider';
import Signature from './../../../src/js/components/signature/signature';

import SetupStore from './setup-store';

describe('Provider signature', function() {

    beforeEach( (done) => {
        this.getElement = () => {
            return SetupStore.getElement(<SignatureProvider />);
        };
        this.state = SetupStore.getInitialState();

        done();
    });

    afterEach( (done) => {

        this.getElement = null;
        this.state = null;

        done();
    });

    it('should map state to props', (done) => {

        const wrapper = mount(this.getElement());
        const props = wrapper.find(Signature).props();

        expect(props.signature).to.equal(this.state.signature);

        done();
    });

    it('should map dispatch to props', (done) => {
        const wrapper = mount(this.getElement());
        const props = wrapper.find(Signature).props();

        expect(props.onSaveSignatures).to.be.a('function');
        expect(props.onClearSignatures).to.be.a('function');
        expect(props.onCancelSignatures).to.be.a('function');
        expect(props.openModal).to.be.a('function');

        done();
    });

});



import React from 'react';
import {Provider} from 'react-redux';
import configureMockStore from 'redux-mock-store'
import thunk from 'redux-thunk'

import AppInitialState from './../../../src/js/app-state/app-initial-state';
const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

class SetupStore {

    constructor() {
        this.store = mockStore(AppInitialState);
    }

    getElement(element) {
        return (<Provider store={this.store}>
                    {element}
                </Provider>);
    }

    getInitialState() {
        return AppInitialState;
    }
}

export default new SetupStore;

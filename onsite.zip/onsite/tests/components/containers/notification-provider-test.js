
import React from 'react';
import {mount} from 'enzyme';

import NotificationProvider from './../../../src/js/components/containers/notification-provider';
import Notification from './../../../src/js/components/notification/notification';

import SetupStore from './setup-store';

describe('Provider notification', function() {

    beforeEach( (done) => {
        this.getElement = () => {
            return SetupStore.getElement(<NotificationProvider test={'test'} />);
        };
        this.state = SetupStore.getInitialState();

        done();
    });

    afterEach( (done) => {

        this.getElement = null;
        this.state = null;

        done();
    });

    it('should map state to props', (done) => {

        const wrapper = mount(this.getElement());
        const props = wrapper.find(Notification).props();

        expect(props.notification).to.equal(this.state.notification);
        expect(props.test).to.equal('test');

        done();
    });

    it('should map dispatch to props', (done) => {
        const wrapper = mount(this.getElement());
        const props = wrapper.find(Notification).props();

        expect(props.removeNotification).to.be.a('function');

        done();
    });

});


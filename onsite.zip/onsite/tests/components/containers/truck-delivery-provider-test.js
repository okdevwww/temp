
import React from 'react';
import {mount} from 'enzyme';

import TruckDeliveryProvider from './../../../src/js/components/containers/truck-delivery-provider';
import TruckDelivery from './../../../src/js/components/truck-delivery/truck-delivery';

import SetupStore from './setup-store';

describe('Provider truck delivery', function() {

    beforeEach( (done) => {
        this.getElement = () => {
            return SetupStore.getElement(<TruckDeliveryProvider />);
        };
        this.state = SetupStore.getInitialState();

        done();
    });

    afterEach( (done) => {

        this.getElement = null;
        this.state = null;

        done();
    });

    it('should map state to props', (done) => {

        const wrapper = mount(this.getElement());
        const props = wrapper.find(TruckDelivery).props();

        expect(props.pictures).to.equal(this.state.pictures.get('truckDelivery'));

        done();
    });

    it('should map dispatch to props', (done) => {
        const wrapper = mount(this.getElement());
        const props = wrapper.find(TruckDelivery).props();

        expect(props.onAddPicture).to.be.a('function');
        expect(props.onDeletePicture).to.be.a('function');

        done();
    });

});


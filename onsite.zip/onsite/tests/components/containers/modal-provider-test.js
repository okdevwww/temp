
import React from 'react';
import {mount} from 'enzyme';

import ModalProvider from './../../../src/js/components/containers/modal-provider';
import Modal from './../../../src/js/components/modal/modal';

import SetupStore from './setup-store';

describe('Provider modal', function() {

    beforeEach( (done) => {
        this.getElement = () => {
            return SetupStore.getElement(<ModalProvider />);
        };
        this.state = SetupStore.getInitialState();

        done();
    });

    afterEach( (done) => {

        this.getElement = null;
        this.state = null;

        done();
    });

    it('should map state to props', (done) => {

        const wrapper = mount(this.getElement());
        const props = wrapper.find(Modal).props();

        expect(props.modalType).to.equal(this.state.modal.get('modalType'));
        expect(props.modalProps).to.equal(this.state.modal.get('modalProps'));

        done();
    });

    it('should map dispatch to props', (done) => {
        const wrapper = mount(this.getElement());
        const props = wrapper.find(Modal).props();

        expect(props.openModal).to.be.a('function');
        expect(props.closeModal).to.be.a('function');

        done();
    });

});



import React from 'react';
import {mount} from 'enzyme';

import StopsProvider from './../../../src/js/components/containers/stops-provider';
import StopsList from './../../../src/js/components/stops/stops-list';

import SetupStore from './setup-store';

describe('Provider stops', function() {

    beforeEach( (done) => {
        this.getElement = () => {
            return SetupStore.getElement(<StopsProvider />);
        };
        this.state = SetupStore.getInitialState();

        done();
    });

    afterEach( (done) => {

        this.getElement = null;
        this.state = null;

        done();
    });

    it('should map state to props', (done) => {

        const wrapper = mount(this.getElement());
        const props = wrapper.find(StopsList).props();

        expect(props.stops).to.equal(this.state.stops);

        done();
    });

    it('should map dispatch to props', (done) => {
        const wrapper = mount(this.getElement());
        const props = wrapper.find(StopsList).props();

        expect(props.onStopPress).to.be.a('function');

        done();
    });

});


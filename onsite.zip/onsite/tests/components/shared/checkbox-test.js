
import React, {TouchableOpacity, View} from 'react-native';
import {shallow} from 'enzyme';
import Checkbox from './../../../src/js/components/shared/checkbox';
import Icon from 'react-native-vector-icons/MaterialIcons';
import ckStyles from './../../../src/js/styles/checkbox-styles';

describe("<Checkbox />", function() {

    beforeEach( () => {

        this._sandbox = sinon.sandbox.create();

        this.onSelectSpy = this._sandbox.spy();

        this.getElement = (selected = false) => {
            return (<Checkbox
                        selected={selected}
                        onSelect={this.onSelectSpy} />);
        };
    });

    afterEach( (done) => {

        this._sandbox.restore();
        done();
    });

    it("should render TouchableOpacity and pass props to it", (done) => {

        const wrapper = shallow(this.getElement());
        const touchableOpacity = wrapper.find(TouchableOpacity);

        expect(touchableOpacity.length).to.equal(1);
        expect(touchableOpacity.prop('onPress')).to.equal(wrapper.instance().onSelect);
        expect(touchableOpacity.prop('activeOpacity')).to.equal(0.5);
        done();
    });

    it("should render View and pass selected styles to it", (done) => {
        const wrapper = shallow(this.getElement(!!"selected"));
        const view = wrapper.find(View);

        const expectedStyle = [ckStyles.base, ckStyles.selected];

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.eql(expectedStyle);
        done();
    });

    it("should render View and pass unselected styles to it", (done) => {
        const wrapper = shallow(this.getElement(!"selected"));
        const view = wrapper.find(View);

        const expectedStyle = [ckStyles.base, ckStyles.unselected];

        expect(view.length).to.equal(1);
        expect(view.prop('style')).to.eql(expectedStyle);
        done();
    });

    it("should not render Icon when checkbox is not selected", (done) => {
        const wrapper = shallow(this.getElement(!"selected"));
        const icon = wrapper.find(Icon);

        expect(icon.length).to.equal(0);
        done();
    });

    it("should render Icon when checkbox is selected", (done) => {
        const wrapper = shallow(this.getElement(!!"selected"));
        const icon = wrapper.find(Icon);

        expect(icon.length).to.equal(1);
        expect(icon.prop('name')).to.equal('done');
        expect(icon.prop('size')).to.equal(20);
        expect(icon.prop('style')).to.equal(ckStyles.icon);
        done();
    });

    it("should call onSelect with false value when TouchableOpacity is pressed", (done) => {
        const wrapper = shallow(this.getElement(!!"selected"));

        wrapper.find(TouchableOpacity).simulate('press');

        expect(this.onSelectSpy.calledOnce).to.be(true);
        expect(this.onSelectSpy.calledWith(!"selected")).to.be(true);
        done();
    });

    it("should call onSelect with true value when TouchableOpacity is pressed", (done) => {
        const wrapper = shallow(this.getElement(!"selected"));

        wrapper.find(TouchableOpacity).simulate('press');

        expect(this.onSelectSpy.calledOnce).to.be(true);
        expect(this.onSelectSpy.calledWith(!!"selected")).to.be(true);
        done();
    });

});

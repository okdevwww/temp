
import React, {View} from 'react-native';
import {shallow} from 'enzyme';
import Hr from './../../../src/js/components/shared/hr';
import hrStyles from './../../../src/js/styles/hr-styles';

describe("<Hr />", function() {

    beforeEach( () => {

        this.getElement = (marginLeft = 0, marginRight = 0, marginTop = 0, marginBottom = 0) => {
            return (<Hr
                        lineColor="#999999"
                        marginLeft={marginLeft}
                        marginRight={marginRight}
                        marginTop={marginTop}
                        marginBottom={marginBottom} />);
        };

    });

    it("should render 2 views", (done) => {

        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View);

        expect(view.length).to.equal(2);
        done();
    });

    it("should pass margins to container View", (done) => {
        const wrapper = shallow(this.getElement(10, 11, 12, 13));
        const view = wrapper.find(View).first();

        const expectedStyle = [hrStyles.lineContainer, { marginLeft: 10, marginRight: 11, marginTop: 12, marginBottom: 13}];

        expect(view.prop('style')).to.eql(expectedStyle);
        done();
    });

    it("should pass lineColor as style to inner View", (done) => {
        const wrapper = shallow(this.getElement());
        const view = wrapper.find(View).last();

        const expectedStyle = [hrStyles.line, {backgroundColor: "#999999"}];

        expect(view.prop('style')).to.eql(expectedStyle);
        done();
    });

});

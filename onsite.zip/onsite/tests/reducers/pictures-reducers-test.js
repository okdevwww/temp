
import Immutable from 'immutable';
import {ADD_PICTURE, DELETE_PICTURE} from './../../src/js/actions/actions';
import pictures from './../../src/js/reducers/pictures-reducers';

describe('Reducers pictures', function() {

    it('should handle add picture', (done) => {

        const action = {
            type: ADD_PICTURE,
            section: 'truckDelivery',
            picture: { 'testPicture': 'text' }
        };

        const picturesState = Immutable.fromJS({'truckDelivery': []});

        const updatedState = pictures(picturesState, action);

        expect(updatedState.get('truckDelivery').toJS()).to.eql([action.picture]);
        done();
    });

    it('should handle delete picture', (done) => {

        const picturesState = Immutable.fromJS({'truckDelivery': [{'pic2': 'text'}, {'pic1': 'text'}]});

        const action = {
            type: DELETE_PICTURE,
            section: 'truckDelivery',
            picture: picturesState.get('truckDelivery').get(1)
        };

        const updatedState = pictures(picturesState, action);

        expect(updatedState.get('truckDelivery').toJS()).to.eql([{'pic2': 'text'}]);
        done();
    });
});

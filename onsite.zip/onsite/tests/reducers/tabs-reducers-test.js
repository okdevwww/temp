
import Immutable from 'immutable';
import {SET_TAB_ACTIVE, SET_TAB_DONE} from './../../src/js/actions/actions';
import tabs from './../../src/js/reducers/tabs-reducers';

describe('Reducers tabs', function() {
    it('should handle set tab as active', (done) => {

        const action = {
            type: SET_TAB_ACTIVE,
            id: '2',
            active: true
        };

        const updatedState = tabs(tabsState, action);

        expect(updatedState.getIn(['2', 'active'])).to.equal(true);
        expect(updatedState.getIn(['1', 'active'])).to.equal(false);

        done();
    });

    it('should handle set tab as inactive', (done) => {
        const action = {
            type: SET_TAB_ACTIVE,
            id: '2',
            active: false
        };

        var tabState = tabsState.setIn(['2', 'active'], true);

        const updatedState = tabs(tabsState, action);

        expect(updatedState.getIn(['2', 'active'])).to.equal(false);
        done();
    });

    it('should handle set tab as done', (done) => {
        const action = {
            type: SET_TAB_DONE,
            id: '2'
        };

        const updatedState = tabs(tabsState, action);

        expect(updatedState.getIn(['2', 'done'])).to.equal(true);
        done();
    });

});


import Immutable from 'immutable';
import {OPEN_MODAL, CLOSE_MODAL} from './../../src/js/actions/actions';
import modals from './../../src/js/reducers/modal-reducers';

describe('Reducers modal', function() {

    it('should handle open modal', (done) => {

        const action = {
            type: OPEN_MODAL,
            modalType: 'test-modal',
            modalProps: { value: 'test-prop' }
        };

        const modalState = Immutable.Map({modalType: '', modalProps: {}});

        const updatedState = modals(modalState, action);

        expect(updatedState.get('modalType')).to.equal(action.modalType);
        expect(updatedState.get('modalProps')).to.eql(action.modalProps);
        done();
    });

    it('should handle close modal', (done) => {

        const action = {
            type: CLOSE_MODAL
        };

        const modalState = Immutable.Map({modalType: 'test-modal', modalProps: { value: 'test-prop'}});

        const updatedState = modals(modalState, action);

        expect(updatedState.get('modalType')).to.equal('');
        expect(updatedState.get('modalProps')).to.eql({});
        done();
    });
});


import Immutable from 'immutable';
import {SET_STOP_ACTIVE, SET_STOP_DONE, RECEIVE_STOPS, CHECK_DELIVERY_ITEM} from './../../src/js/actions/actions';
import stops from './../../src/js/reducers/stops-reducers';

import {stopsData, itemsData} from './reducers-data';

describe('Reducers stops', function() {

    before( (done) => {
        var stopsProcessed = {};

        stopsData.map( (stopDetails) => {
            stopsProcessed[stopDetails.STOP_ID] = stopDetails;
        });

        itemsData.map( (itemDetails) => {

            if (itemDetails.hasOwnProperty('STOP_ID') &&
                itemDetails.hasOwnProperty('type') &&
                typeof stopsProcessed[itemDetails.STOP_ID] !== "undefined") {

                if (typeof stopsProcessed[itemDetails.STOP_ID][itemDetails.type] == "undefined") {
                    stopsProcessed[itemDetails.STOP_ID][itemDetails.type] = [];
                }
                stopsProcessed[itemDetails.STOP_ID][itemDetails.type].push(itemDetails);
            }
        });

        this.stopsState = stopsProcessed;
        done();
    });

    after( (done) => {
        this.stopsState = null;
        done();
    })

    it('should process received stops and items', (done) => {

        const action = {
            type: RECEIVE_STOPS,
            stops: { value: stopsData },
            items: { value: itemsData }
        };

        const updatedState = stops(Immutable.Map(), action);

        expect(updatedState.toJS()).to.eql(this.stopsState);
        done();
    });

    it('should set stop as active', (done) => {
        const action = {
            type: SET_STOP_ACTIVE,
            id: 3
        };

        const updatedState = stops(Immutable.fromJS(this.stopsState), action);
        expect(updatedState.getIn([action.id, 'active'])).to.equal(true);
        done();
    });

    it('should set stop as done', (done) => {
        const action = {
            type: SET_STOP_DONE,
            id: 3
        };

        const updatedState = stops(Immutable.fromJS(this.stopsState), action);
        expect(updatedState.getIn([action.id, 'done'])).to.equal(true);
        done();
    });

    it('should check delivery item', (done) => {
        const action = {
            type: CHECK_DELIVERY_ITEM,
            stopId: "3",
            id: "1006888647",
            check: true
        };

        var stopsState = Immutable.fromJS(this.stopsState);
        const updatedState = stops(stopsState, action);

        var items = stopsState.getIn([action.stopId, 'Delivery']);
        items = items.map( (item) => {
            if (item.get('Barcode_id') === action.id) {
                item = item.set('checked', action.check);
            }
            return item;
        });
        const expectedState = stopsState.setIn([action.stopId, 'Delivery'], items);

        expect(updatedState.toJS()).to.eql(expectedState.toJS());
        done();
    });


});


import Immutable from 'immutable';
import {SAVE_SIGNATURES, CLEAR_SIGNATURES} from './../../src/js/actions/actions';
import signatures from './../../src/js/reducers/signature-reducers';

describe('Reducers signature', function() {

    it('should handle save signature for driver', (done) => {

        const action = {
            type: SAVE_SIGNATURES,
            driverSignature: { 'driverSignature': 'obj'},
            customerSignature: null
        };

        const signatureState = Immutable.fromJS({'driverSignature': null, 'customerSignature': null});

        const updatedState = signatures(signatureState, action);

        expect(updatedState.get('driverSignature')).to.eql(action.driverSignature);
        expect(updatedState.get('customerSignature')).to.eql(null);
        done();
    });

    it('should handle save signature for customer', (done) => {

        const action = {
            type: SAVE_SIGNATURES,
            driverSignature: null,
            customerSignature: { 'customerSignature': 'obj'}
        };

        const signatureState = Immutable.fromJS({'driverSignature': null, 'customerSignature': null});

        const updatedState = signatures(signatureState, action);

        expect(updatedState.get('driverSignature')).to.eql(null);
        expect(updatedState.get('customerSignature')).to.eql(action.customerSignature);
        done();
    });

    it('should handle clear signatures', (done) => {

        const action = {
            type: CLEAR_SIGNATURES
        };

        const signatureState = Immutable.Map({'driverSignature': {'d': 'obj'}, 'customerSignature': {'c': 'obj'}});

        const updatedState = signatures(signatureState, action);

        expect(updatedState.get('driverSignature')).to.eql(null);
        expect(updatedState.get('customerSignature')).to.eql(null);
        done();
    });
});

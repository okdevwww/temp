
import Immutable from 'immutable';
import {REQUEST_LOGIN, RECEIVE_LOGIN} from './../../src/js/actions/actions';
import session from './../../src/js/reducers/session-reducers';

describe('Reducers session', function() {

    it('should handle request login', (done) => {

        const action = {
            type: REQUEST_LOGIN
        };

        const sessionState = Immutable.fromJS({'loginInProgress': false, id: null, username: null});

        const updatedState = session(sessionState, action);

        expect(updatedState.get('loginInProgress')).to.equal(true);
        expect(updatedState.get('id')).to.equal(null);
        expect(updatedState.get('username')).to.equal(null);
        done();
    });

    it('should handle receive login', (done) => {

        const action = {
            type: RECEIVE_LOGIN,
            id: '1234'
        };

        const sessionState = Immutable.fromJS({'loginInProgress': true, id: null, username: null});

        const updatedState = session(sessionState, action);

        expect(updatedState.get('loginInProgress')).to.equal(false);
        expect(updatedState.get('id')).to.equal('1234');
        done();
    });

});

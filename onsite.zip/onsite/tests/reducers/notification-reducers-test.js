
import Immutable from 'immutable';
import {ADD_NOTIFICATION, REMOVE_NOTIFICATION} from './../../src/js/actions/actions';
import notification from './../../src/js/reducers/notification-reducers';
import {NOTIFICATION_LIST} from './../../src/js/config/constants';

describe('Reducers notification', function() {

    it('should handle add notification', (done) => {

        const action = {
            type: ADD_NOTIFICATION,
            id: NOTIFICATION_LIST.NETWORK_ERROR
        };

        const notificationState = null;;
        const updatedState = notification(notificationState, action);

        expect(updatedState).to.equal(NOTIFICATION_LIST.NETWORK_ERROR);
        done();
    });

    it('should handle remove notification', (done) => {

        const action = {
            type: REMOVE_NOTIFICATION
        };

        const notificationState = NOTIFICATION_LIST.NETWORK_ERROR;
        const updatedState = notification(notificationState, action);

        expect(updatedState).to.equal(null);

        done();
    });
});

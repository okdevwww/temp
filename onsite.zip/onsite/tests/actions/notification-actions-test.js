
import {ADD_NOTIFICATION, REMOVE_NOTIFICATION} from './../../src/js/actions/actions';
import {addNotification, removeNotification} from './../../src/js/actions/notification-actions';

describe('Notification actions', function() {

    it('should handle add notification', (done) => {

        const expected = {
            type: ADD_NOTIFICATION,
            id: 'test'
        };

        const value = addNotification(expected.id);

        expect(value).to.eql(expected)
        done();
    });

    it('should handle remove notification', (done) => {
        const expected = {
            type: REMOVE_NOTIFICATION
        };

        const value = removeNotification();
        expect(value).to.eql(expected);

        done();
    });
});


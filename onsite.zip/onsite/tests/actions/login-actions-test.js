
import {REQUEST_LOGIN, RECEIVE_LOGIN, RECEIVE_STOPS, ADD_NOTIFICATION} from './../../src/js/actions/actions';
import {login, requestLogin, receiveLogin} from './../../src/js/actions/login-actions';
import {Actions} from 'react-native-router-flux';

import {NOTIFICATION_LIST} from './../../src/js/config/constants';

import configureMockStore from 'redux-mock-store'
import thunk from 'redux-thunk';

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

import fetchMock from 'fetch-mock';

describe('Login actions', function() {

    beforeEach( (done) => {
        if (this.store) {
            this.store.clearActions();
        }
        this.store = mockStore({ stops: {} });
        done();
    });

    afterEach( (done) => {
        done();
    });

    it('creates RECEIVE_STOPS when fetching of stops and items are done', (done) => {

        const jsBody = {
                    stops: { "value": [{"stop": '1'}] },
                    items: { "value": [{"item": '1'}] }
                };
        const id = '1234';
        const expectedActions = [
            {
                type: REQUEST_LOGIN
            }, {
                type: RECEIVE_STOPS,
                stops: jsBody.stops,
                items: jsBody.items
            }, {
                type: RECEIVE_LOGIN,
                id: id
            }
        ];

        fetchMock.once(/.*\/GetStops\?.*/, jsBody.stops);
        fetchMock.once(/.*\/GetItemsbyDriver\?.*/, jsBody.items);

        this.store.dispatch(login(id))
            .then(() => { // return of async actions
                const actions = this.store.getActions();
                expect(actions).to.eql(expectedActions);
                done();
            });
    });

    it('creates ADD_NOTIFICATION of MALFORMED_STOPS when stops are not received', (done) => {
        this.store.clearActions();

        const id = '1234';
        const expectedActions = [
            {
                type: REQUEST_LOGIN
            }, {
                type: ADD_NOTIFICATION,
                id: NOTIFICATION_LIST.MALFORMED_STOPS
            }
        ];

        fetchMock.once(/.*\/GetStops\?.*/, { body: {} });
        fetchMock.once(/.*\/GetItemsbyDriver\?.*/, { body: {} });

        this.store.dispatch(login(id))
            .then(() => { // return of async actions
                const actions = this.store.getActions();
                expect(actions).to.eql(expectedActions);
                done();
            });
    });

    it('creates ADD_NOTIFICATION of MALFORMED_ITEMS when stops are not received', (done) => {

        const jsBody = {
                    stops: { "value": [{"stop": '1'}] }
                };
        const id = '1234';
        const expectedActions = [
            {
                type: REQUEST_LOGIN
            }, {
                type: ADD_NOTIFICATION,
                id: NOTIFICATION_LIST.MALFORMED_ITEMS
            }
        ];

        fetchMock.once(/.*\/GetStops\?.*/, jsBody.stops);
        fetchMock.once(/.*\/GetItemsbyDriver\?.*/, { body: {} });

        this.store.dispatch(login(id))
            .then(() => { // return of async actions
                const actions = this.store.getActions();
                expect(actions).to.eql(expectedActions);
                done();
            });
    });

    it('should return REQUEST_LOGIN type', (done) => {

        const expected = {
            type: REQUEST_LOGIN
        };
        const value = requestLogin();

        expect(value).to.eql(expected);
        done();
    });

    it('should return RECEIVE_LOGIN type', (done) => {

        const expected = {
            type: RECEIVE_LOGIN,
            id: 'test'
        };
        const value = receiveLogin(expected.id);

        expect(value).to.eql(expected);
        done();
    });


});


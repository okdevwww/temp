
import {SET_TAB_ACTIVE, SET_TAB_DONE} from './../../src/js/actions/actions';
import {setTabActive, setTabDone} from './../../src/js/actions/tab-actions';
import {Actions} from 'react-native-router-flux';

describe('Tab actions', function() {

    it('should return SET_TAB_ACTIVE type and call Actions.tabs from router', (done) => {

        const expected = {
            type: SET_TAB_ACTIVE,
            id: '1',
            active: true
        };
        const value = setTabActive(expected.id, expected.active);

        expect(value).to.eql(expected)
        done();
    });

    it('should return SET_TAB_ACTIVE type and call Actions.signature from router', (done) => {

        const expected = {
            type: SET_TAB_ACTIVE,
            id: '7',
            active: true
        };
        const value = setTabActive(expected.id, expected.active);

        expect(value).to.eql(expected)
        expect(Actions.signature.called).to.be(true);
        done();
    });

    it('should return SET_TAB_DONE type', (done) => {
        const expected = {
            type: SET_TAB_DONE,
            id: '4'
        };

        const value = setTabDone(expected.id);

        expect(value).to.eql(expected);
        done();
    });

});


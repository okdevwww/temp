
import {ADD_PICTURE, DELETE_PICTURE} from './../../src/js/actions/actions';
import {addPicture, deletePicture} from './../../src/js/actions/picture-actions';

describe('Picture actions', function() {

    it('should return ADD_PICTURE type', (done) => {

        const expected = {
            type: ADD_PICTURE,
            section: 'truckdelivery',
            picture: { testProp: 'test'}
        };

        const value = addPicture(expected.section, expected.picture);

        expect(value).to.eql(expected)
        done();
    });

    it('should return DELETE_PICTURE type', (done) => {
        const expected = {
            type: DELETE_PICTURE,
            section: 'truckdelivery',
            picture: {testProp: 'text'}
        };

        const value = deletePicture(expected.section, expected.picture);

        expect(value).to.eql(expected);
        done();
    });

});



import {OPEN_MODAL, CLOSE_MODAL} from './../../src/js/actions/actions';
import {openModal, closeModal} from './../../src/js/actions/modal-actions';

describe('Modal actions', function() {

    it('should return OPEN_MODAL type', (done) => {

        const expected = {
            type: OPEN_MODAL,
            modalType: 'test',
            modalProps: { test: 'test'}
        };

        const value = openModal(expected.modalType, expected.modalProps);

        expect(value).to.eql(expected)
        done();
    });

    it('should return CLOSE_MODAL type', (done) => {
        const expected = {
            type: CLOSE_MODAL
        };

        const value = closeModal();

        expect(value).to.eql(expected);
        done();
    });

});



import {SET_STOP_ACTIVE, SET_STOP_DONE, RECEIVE_STOPS, CHECK_DELIVERY_ITEM} from './../../src/js/actions/actions';
import {setStopActive, setStopDone, receiveStops, checkDeliveryItem} from './../../src/js/actions/stop-actions';
import {Actions} from 'react-native-router-flux';

describe('Stop actions', function() {

    it('should return SET_STOP_ACTIVE type and call Actions.tabs from router', (done) => {

        const expected = {
            type: SET_STOP_ACTIVE,
            id: 'test'
        };

        const value = setStopActive(expected.id);

        expect(value).to.eql(expected)
        expect(Actions.tabs.called).to.be(true);
        expect(Actions.tabs.calledWith({stopId: expected.id})).to.be(true);
        done();
    });

    it('should return SET_STOP_DONE type', (done) => {
        const expected = {
            type: SET_STOP_DONE,
            id: 'test'
        };

        const value = setStopDone(expected.id);

        expect(value).to.eql(expected);
        done();
    });

    it('should return RECEIVE_STOPS type', (done) => {
        const expected = {
            type: RECEIVE_STOPS,
            stops: [{stop: '1'}, {stop: '2'}],
            items: [{item: '1'}, {item: '2'}]
        };

        const value = receiveStops(expected.stops, expected.items);

        expect(value).to.eql(expected);
        done();
    });

    it('should return CHECK_DELIVERY_ITEM type', (done) => {
        const expected = {
            type: CHECK_DELIVERY_ITEM,
            stopId: '1',
            id: '234',
            check: false
        };

        const value = checkDeliveryItem(expected.stopId, expected.id, expected.check);

        expect(value).to.eql(expected);
        done();
    });

});


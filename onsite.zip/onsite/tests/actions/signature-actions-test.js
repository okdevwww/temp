
import {SAVE_SIGNATURES, CLEAR_SIGNATURES, CANCEL_SIGNATURES} from './../../src/js/actions/actions';
import {saveSignatures, clearSignatures, cancelSignatures} from './../../src/js/actions/signature-actions';
import {Actions} from 'react-native-router-flux';

describe('Signature actions', function() {

    it('should return SAVE_SIGNATURES type', (done) => {

        const expected = {
            type: SAVE_SIGNATURES,
            driverSignature: { driverSignatureTest: ''},
            customerSignature: {customerSignatureTest: ''}
        };

        const value = saveSignatures(expected.driverSignature, expected.customerSignature);

        expect(value).to.eql(expected)
        done();
    });

    it('should return CLEAR_SIGNATURES type', (done) => {
        const expected = {
            type: CLEAR_SIGNATURES
        };

        const value = clearSignatures();

        expect(value).to.eql(expected);
        done();
    });

    it('should return CANCEL_SIGNATURES type and call Actions.pop from router', (done) => {
        const expected = {
            type: CANCEL_SIGNATURES
        };

        const value = cancelSignatures();

        expect(value).to.eql(expected);
        expect(Actions.pop.called).to.be(true);
        done();
    });

});


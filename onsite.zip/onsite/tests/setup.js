
var fs = require('fs');
var path = require('path');

// set global modules to reduce code duplication
var expect = require('expect.js');
var sinon = require('sinon');
var fetch = require('isomorphic-fetch');
var jsdom = require('jsdom').jsdom;

// Ignore all node_modules except these
const modulesToCompile = [
    //'react',
    // 'react-addons-shallow-compare',
    // 'react-native',
    'react-native-image-picker',
    'react-native-material-design',
    'react-native-vector-icons',
    'react-native-signature-capture',
    // 'react-redux',
    // 'redux-persist-transform-immutable',
    // 'redux-action-buffer',
    // 'redux',
    // 'redux-persist',
    // 'redux-thunk',
    // 'remote-redux-devtools',
    'react-native-router-flux',
    'react-native-collapsible'
].map( (moduleName) => new RegExp(`/node_modules/${moduleName}`));

const rcPath = path.join(__dirname, '..', '.babelrc');
const source = fs.readFileSync(rcPath).toString();
const config = JSON.parse(source);

config.ignore = function(filename) {
    if (!(/\/node_modules\//).test(filename)) {
        return false;
    }

    if ((/\/lodash\//).test(filename)) {
        return true;
    }

    /*if ((/\/\.png\//).test(filename)) {
        return true;
    }*/

    const matches = modulesToCompile.filter((regex) => regex.test(filename));
    const shouldIgnore = matches.length === 0;
    return shouldIgnore;
};

//console.log(config);
//var register = require('babel-core/register');
require('babel-core/register')(config);

// Setup globals
global.__DEV__ = true;
global.document = jsdom('');
global.window = document.defaultView;
var exposedProperties = ['window', 'navigator', 'document'];

Object.keys(document.defaultView).forEach((property) => {
    if (typeof global[property] === 'undefined') {
        exposedProperties.push(property);
        global[property] = document.defaultView[property];
    }
});

global.navigator = {
    userAgent: 'node.js'
};

global.expect = expect;
global.sinon = sinon;
global.fetch = fetch;

// Setup mocks

// trying to mock request for images - not working yet
// throws this error:
// TypeError: Plugin 1 specified in "/node_modules/react-native-router-flux/node_modules/react-native-experimental-navigation/package.json" was expected to return a function but returned "undefined"
// const m = require('module');
// const originalLoader = m._load;

// m._load = function hookedLoader(request, parent, isMain) {
//     var file = m._resolveFilename(request, parent);
//     if (file.match(/.jpeg|.jpg|.png$/)) {
//         return {uri: file};
//     }
//     if (request.match(/.jpeg|.jpg|.png$/)) {
//         return { uri: request };
//     }
//     return originalLoader(request, parent, isMain);
// };

require('react-native-mock/mock');

var mockery = require("mockery");
mockery.enable({
    warnOnReplace: false,
    warnOnUnregistered: false
});
mockery.registerMock('react-native-router-flux', {Actions:{ pop: sinon.spy(), tabs: sinon.spy(), signature: sinon.spy() }});
mockery.registerMock('./menu_burger.png', 0);
mockery.registerMock('./back_chevron.png', 0);
//mockery.registerMock('./../node_modules/react-native-router-flux/src/menu_burger.png', 0);

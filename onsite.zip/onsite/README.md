# react-native-sample
Code collaboration

``` shell
git clone http://pmccluskey@ausd-prod-stash-1.insidecort.local:7990/scm/pmcc/onsite-ui-demo.git .
git submodule init
git submodule sync
git submodule update --init --recursive
cp ./external/android/external/shared/libs/react.force.* ./src/js/bridges/
cp ./external/build.gradle.hacked ./external/android/libs/SalesforceReact/build.gradle
cp ./external/servers.xml.hacked ./external/android/libs/SalesforceSDK/res/xml/servers.xml
npm install
emulator -avd reactEmulator
react-native run-android
```

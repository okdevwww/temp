/* index.android.js */

import React , { Component } from 'react';
import { AppRegistry } from 'react-native';
import { Provider } from 'react-redux';

import App from './src/js/app';
import configureStore from './src/js/config/configure-store';

const { store , persistor } = configureStore();

class onsite extends Component {
    render() {
        return (
            <Provider store={ store } persistor={ persistor } >
                <App />
            </Provider>
        );
    }
}

AppRegistry.registerComponent( "onsite" , () => onsite );

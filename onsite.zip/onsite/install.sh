# time git clone http://pmccluskey@ausd-prod-stash-1.insidecort.local:7990/scm/pmcc/onsite-ui-demo.git .
time git submodule init
time git submodule sync
time git submodule update --init --recursive
time cp ./external/android/external/shared/libs/react.force.* ./src/js/bridges/
time cp ./external/build.gradle.hacked ./external/android/libs/SalesforceReact/build.gradle
time cp ./external/servers.xml.hacked ./external/android/libs/SalesforceSDK/res/xml/servers.xml
time cp ./external/settings.gradle.hacked ./external/android/settings.gradle
time rm ./external/android/external/shared/dependencies/react/react-with-addons.*
time npm install
# emulator -avd reactEmulator
# time react-native run-android

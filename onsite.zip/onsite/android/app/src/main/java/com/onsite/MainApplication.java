/* MainApplication.java */

package com.onsite;

import java.util.Arrays;
import java.util.List;
import android.app.Application;

// first...  react native dependencies...
import com.facebook.react.ReactApplication;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.react.shell.MainReactPackage;

// second...  salesforce dependecies...
import com.salesforce.androidsdk.reactnative.app.SalesforceReactSDKManager;
import com.salesforce.androidsdk.app.SalesforceSDKManager;
import com.salesforce.androidsdk.security.Encryptor;

// third...  onsite dependencies...
import com.imagepicker.ImagePickerPackage;
//import com.learnium.RNDeviceInfo.RNDeviceInfo; // breaks the assembleRelease task...
import com.burnweb.rnsendintent.RNSendIntentPackage;
import com.rssignaturecapture.RSSignatureCapturePackage;
import com.cboy.rn.splashscreen.SplashScreenReactPackage;

public class MainApplication extends Application implements ReactApplication {

    private final ReactNativeHost mReactNativeHost = new ReactNativeHost( this ) {
        @Override
        public boolean getUseDeveloperSupport() {
            return BuildConfig.DEBUG;
        }

        @Override
        protected List<ReactPackage> getPackages() {
            //new RNDeviceInfo() ,  // breaks the assembleRelease task...
            return Arrays.<ReactPackage>asList(
                new MainReactPackage() ,
                SalesforceReactSDKManager.getInstance().getReactPackage() ,
                new ImagePickerPackage() ,
                new RNSendIntentPackage() ,
                new RSSignatureCapturePackage() ,
                new SplashScreenReactPackage()
            );
        }
    };

    public ReactNativeHost getReactNativeHost() {
        return mReactNativeHost;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        SalesforceReactSDKManager.initReactNative(
            getApplicationContext() ,
            new ReactNativeKeyImpl() ,
            MainActivity.class
        );
    }
}

class ReactNativeKeyImpl implements SalesforceSDKManager.KeyInterface {
    @Override
    public String getKey( String name ) {
        return Encryptor.hash(
            name + "12s9adpahk;n12-97sdainkasd=012" ,
            name + "12kl0dsakj4-cxh1qewkjasdol8"
        );
    }
}

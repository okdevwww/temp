/* app-initial-state.js */

import Immutable from 'immutable';

const AppInitialState = {
    scene : null ,
    session : Immutable.fromJS(
        {
            animating : true ,
            completed_stops : null ,
            id : null ,
            stop : 0 ,
            username : null ,
        }
    ) ,
    stops : Immutable.OrderedMap( { } ) ,
    signature : Immutable.fromJS( { } ) ,
    pictures : Immutable.fromJS( { } ) ,
    buttons : Immutable.fromJS(
        {
            "1" : {
                text : "Back" ,
                icon : "history" ,
            } ,
            "2" : {
                text : "Instructions" ,
                icon : "announcement" ,
            } ,
        }
    ) ,
    notification : null ,
    modal : Immutable.fromJS(
        {
            modalType : "" ,
            modalProps : { } ,
        }
    )
};

export default AppInitialState;

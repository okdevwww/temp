/* tab-actions.js */

import {
    SET_TAB_STARTED ,
    SET_TAB_COMPLETED ,
} from "./actions";

export function setTabStarted( stopId : string , id : string ) : Object {
    return {
        stopId ,
        id ,
        type : SET_TAB_STARTED ,
    };
}

export function setTabCompleted( stopId : string , id : string ) : Object {
    return {
        stopId ,
        id ,
        type : SET_TAB_COMPLETED ,
    };
}

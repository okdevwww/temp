/* process-actions.js */

import {
    SET_PROCESS_OPEN ,
} from "./actions";

export function onProcessPressed( stopId : string , processId : number , active : boolean ) : Object {
    return {
        stopId ,
        processId ,
        active ,
        type : SET_PROCESS_OPEN ,
    };
}

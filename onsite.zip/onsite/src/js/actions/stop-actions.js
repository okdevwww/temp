/* stop-actions.js */

import { Actions } from 'react-native-router-flux';

import {
    CHECK_DELIVERY_ITEM ,
    RECEIVE_CHECKLISTS ,
    RECEIVE_CONTENT ,
    RECEIVE_QUESTIONS ,
    RECEIVE_RESPONSE ,
    RECEIVE_STOPS ,
    SET_STOP_ACTIVE ,
    SET_STOP_COMPLETE ,
} from './actions';

export function setStopActive( stopKey : string ) : Object {
    Actions.tabs( { stopId : stopKey } );
    return {
        stopKey ,
        type : SET_STOP_ACTIVE ,
    };
}

export function setStopComplete( stopKey : string ) : Object {
    return {
        stopKey ,
        type : SET_STOP_COMPLETE ,
    };
}

export function receiveStops( stops : Array<Object> , items : Array<Object> ) : Object {
    return {
        stops ,
        items ,
        type : RECEIVE_STOPS ,
    };
}

export function receiveQuestions( stopId : string , questions : Array<Object> ) : Object {
    return {
        stopId ,
        questions ,
        type : RECEIVE_QUESTIONS ,
    };
}

export function receiveResponse( stopId : string , process : string , room : string , index : string , response : Array<Object> ) : Object {
    return {
        stopId ,
        process ,
        room ,
        index ,
        response ,
        type : RECEIVE_RESPONSE ,
    };
}

export function receiveContent( stopId : string , process : string , room : string , index : string , content : Array<Object> ) : Object {
    return {
        stopId ,
        process ,
        room ,
        index ,
        content ,
        type : RECEIVE_CONTENT ,
    };
}

export function checkDeliveryItem( stopId : string , item : Object , value : string , exceptionId : string ) : Object {
    return {
        stopId ,
        item ,
        value ,
        exceptionId ,
        type : CHECK_DELIVERY_ITEM ,
    };
}

export function receiveChecklists( transactions : Array ) : Object {
    return {
        transactions : transactions ,
        type : RECEIVE_CHECKLISTS ,
    };
}
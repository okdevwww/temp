/* route-actions.js */

import { NetInfo } from 'react-native';
import { Actions } from 'react-native-router-flux';
import SplashScreen from 'react-native-splash-screen';

import {
    CONTINUE_ROUTE ,
    END_ROUTE ,
    RECONNECT_ROUTE ,
    START_ROUTE ,
} from './actions';
import {
    REFRESH_SOUPS_ENABLED ,
    ROUTE_KEY ,
    SPLASHSCREEN_DEBUG ,
} from './../config/constants';
import { locale } from './../config/locale';
import { connectOnsite } from './network-actions';
import {
    openConnectModal ,
    openModal ,
} from './modal-actions';

var storeManager = require( './../bridges/StoreManager.js' );

export function reconnectRoute() : Object {
    return {
        type : RECONNECT_ROUTE ,
    };
}

export function startRoute( driverId : string ) : Object {
    if ( ! driverId ) {
        return function ( dispatch ) {
            dispatch(
                openConnectModal(
                    {
                        onClose : ( driverId : string ) => {
                            dispatch( connectOnsite( driverId , ROUTE_KEY ) );
                        } ,
                    }
                )
            );
        }
    } else {
        return {
            type : START_ROUTE ,
        };
    }
}

export function continueRoute( driverId : string ) : Object {
    if ( driverId ) {
        return function ( dispatch ) {
            dispatch( connectOnsite( driverId , ROUTE_KEY ) );
        }
    } else {
        return {
            type : CONTINUE_ROUTE ,
        };
    }
}

function finishEndRoute() : void {
    // hide the splash screen when the action is complete...
    if ( SPLASHSCREEN_DEBUG ) {
        SplashScreen.hide();
    }
}

function executeEndRoute( driverId : string , stops : Object ) : Object {
    NetInfo.isConnected.fetch().then(
        ( isConnected ) => {
            if ( isConnected ) {
                // proceed with execution...
                console.log( "executeEndRoute ~ NetInfo.isConnected " + ( isConnected ? "online" : "offline" ) );
                if ( REFRESH_SOUPS_ENABLED ) {
                    console.log( "PMCC DBG ~ ################################################################################" );
                    console.log( "PMCC DBG ~ executeEndRoute.initSoups" );
                    var endRouteStart = Date.now();
                    storeManager.initSoups(
                        false ,
                        stops.toJS() ,
                        ( transactionsWithChecklist , completedStops ) => {
                            console.log( "executeEndRoute.initSoups finished ~ " + ( ( Date.now() - endRouteStart ) / 1000 ) + " seconds total" );
                            console.log( "PMCC DBG ~ ################################################################################" );
                            console.log( "PMCC DBG ~ executeEndRoute.syncSoups" );
                            storeManager.syncSoups(
                                ( pictures ) => {
                                    console.log( "executeEndRoute.syncSoups finished ~ " + ( ( Date.now() - endRouteStart ) / 1000 ) + " seconds total" );
                                    console.log( "PMCC DBG ~ ################################################################################" );
                                    storeManager.initSoups(
                                        true , // we want to init, then sync, and then flush the soups at the end of the day to start fresh...
                                        stops.toJS() ,
                                        ( transactionsWithChecklist , completedStops ) => {
                                            console.log( "executeEndRoute.initSoups flush finished ~ " + ( ( Date.now() - endRouteStart ) / 1000 ) + " seconds total" );
                                            console.log( "PMCC DBG ~ ################################################################################" );
                                            finishEndRoute();
                                        } ,
                                        ( error ) => {
                                            finishEndRoute();
                                        }
                                    );
                                }
                            );
                        } ,
                        ( error ) => {
                            finishEndRoute();
                        }
                    );
                } else {
                    finishEndRoute();
                }
            } else {
                finishEndRoute();
            }
        }
    );
    return {
        type : END_ROUTE ,
    };
}

export function endRoute( driverId : string , stops : Object ) : Object {
    return function ( dispatch ) {
        dispatch(
            openModal(
                "confirmation" ,
                {
                    title : locale.en_US.LOC_CONFIRMATION_TITLE ,
                    text : locale.en_US.LOC_CONFIRMATION_TEXT ,
                    confirmText : locale.en_US.LOC_YES ,
                    cancelText : locale.en_US.LOC_NO ,
                    onClose: () => {
                        if ( SPLASHSCREEN_DEBUG ) {
                            SplashScreen.show();
                        }
                        dispatch( executeEndRoute( driverId , stops ) );
                    }
                }
            )
        );
    }
}

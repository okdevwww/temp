/* locale-actions.js */

import { SET_LOCALE } from './actions';

export function setLocale( locale : string ) : Object {
    return {
        locale : locale ,
        type : SET_LOCALE ,
    };
}

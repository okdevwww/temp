/* modal-actions.js */

import {
    CLOSE_MODAL ,
    OPEN_MODAL ,
} from './actions';

export function closeModal() : Object {
    return {
        type : CLOSE_MODAL ,
    };
}

export function openModal( modalType : string , modalProps : Object ) : Object {
    return {
        modalType ,
        modalProps ,
        type : OPEN_MODAL ,
    };
}

export function openConnectModal( modalProps : Object ) : Object {
    const modalType = "connect";
    return {
        modalType ,
        modalProps ,
        type : OPEN_MODAL ,
    };
}

export function showDeliveryInstructions( message : string ) : Object {
    var modalType = "directions";
    var modalProps = { data : message };
    return {
        modalType ,
        modalProps ,
        type : OPEN_MODAL ,
    };
}

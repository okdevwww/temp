/* picture-actions.js */

import {
    ADD_PICTURE ,
    DELETE_PICTURE ,
} from './actions';

export function addPicture( stopId : string , question : Object , process : string , picture : Object ) : Object {
    return {
        stopId ,
        question ,
        process ,
        picture ,
        type : ADD_PICTURE ,
    };
}

export function deletePicture( stopId : string , process : string , questionId : string , picture : Object ) : Object {
    return {
        stopId ,
        process ,
        questionId ,
        picture ,
        type : DELETE_PICTURE ,
    };
}

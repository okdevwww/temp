/* platform-actions.js */

import { RECEIVE_STATE } from './actions';

export function saveState( state : Object ) : Object {
}

export function receiveSaveStatus( status : Object ) : Object {
    return {
        status ,
        type : RECEIVE_SAVE_STATUS ,
    };
}

/* refresh-actions.js */

import { NetInfo } from 'react-native';
import { Actions } from 'react-native-router-flux';
import SplashScreen from 'react-native-splash-screen';

import {
    REFRESH_CONNECTION_ENABLED ,
    REFRESH_SOUPS_ENABLED ,
    SPLASHSCREEN_DEBUG ,
} from './../config/constants';
import { locale } from './../config/locale';
import {
    openModal ,
    showDeliveryInstructions ,
} from './modal-actions';
import { connectOnsite } from './network-actions';
import {
    receiveContent ,
    receiveResponse ,
    receiveQuestions ,
    setStopActive ,
    setStopComplete ,
} from './stop-actions';

var storeManager = require( './../bridges/StoreManager.js' );

function finalizeRefreshDriver( nextAction : string ) {
    if ( SPLASHSCREEN_DEBUG ) {
        SplashScreen.hide();
    }
    if ( nextAction && ( nextAction == "pop" ) ) {
        Actions.pop();
    }
}

export function refreshDriverOnClose( dispatch : func , driverId : string , refreshConnection : bool , nextAction : string ) : Object {
    if ( SPLASHSCREEN_DEBUG ) {
        SplashScreen.show();
    }
    NetInfo.isConnected.fetch().then(
        ( isConnected ) => {
            if ( isConnected ) {
                // proceed with refresh...
                console.log( "refreshDriver ~ NetInfo.isConnected " + ( isConnected ? "online" : "offline" ) );
                if ( REFRESH_SOUPS_ENABLED ) {
                    console.log( "PMCC DBG ~ ################################################################################" );
                    console.log( "PMCC DBG ~ .syncSoups" );
                    var syncSoupsStart = Date.now();
                    storeManager.syncSoups(
                        ( pictures ) => {
                            // PMCC TODO ~ add dispatch to reset picture data from the content document results...
                            console.log( "PMCC DBG ~ .syncSoups.SUCCESS ~ " + ( ( Date.now() - syncSoupsStart ) / 1000 ) );
                            console.log( "PMCC DBG ~ ################################################################################" );
                            if ( REFRESH_CONNECTION_ENABLED && refreshConnection ) {
                                // refresh decartes data as well as salesforce...
                                dispatch( connectOnsite( driverId , nextAction , true ) );
                            } else {
                                // stop after salesforce sync...
                                finalizeRefreshDriver( nextAction );
                            }
                        }
                    );
                } else {
                    // just stop without updating soups...
                    finalizeRefreshDriver( nextAction );
                }
            } else {
                // abort due to lack of connection...
                finalizeRefreshDriver( null );
            }
        }
    );
    return {};
}

export function refreshDriver( driverId : string , titleText : string , messageText : string , refreshConnection : bool , nextAction : string , stopKey : string ) : Object {
    return function ( dispatch ) {
        dispatch(
            openModal(
                "confirmation" ,
                {
                    title : titleText ,
                    text : messageText ,
                    confirmText : locale.en_US.LOC_CONFIRM ,
                    cancelText : locale.en_US.LOC_CANCEL ,
                    onClose: () => {
                        refreshDriverOnClose( dispatch , driverId , refreshConnection , nextAction );
                    } ,
                }
            )
        );
    }
}

function finalizeRefreshStop() {
    if ( SPLASHSCREEN_DEBUG ) {
        SplashScreen.hide();
    }
}

export function refreshStop( stop : Object , showInstructions : bool ) : Object {
    return function ( dispatch ) {
        if ( SPLASHSCREEN_DEBUG ) {
            SplashScreen.show();
        }
        dispatch( setStopActive( stop.get( "STOP_KEY" ) ) );
        if ( true ) {
            // query local smartstore for the active stop key...
            //  ~ dispatch calls to update stops.questions and stops.questions.responses...
            //  ~ upate checklist instance with static stop information from decartes webservice...
            storeManager.getChecklistQuestionsByTransactionName(
                stop.get( "STOP_KEY" ) ,
                stop.get( "STOP_KEY" ) ,
                ( stopKey , checklistQuestions ) => {
                    // dispatch action handler for salesforce data containing all Checklist_Question__c's for each stop...
                    dispatch( receiveQuestions( stopKey , checklistQuestions ) );
                    if ( true ) {
                        storeManager.getAllResponsesForChecklistQuestions(
                            checklistQuestions ,
                            stopKey ,
                            ( stopKey , process , roomIndex , questionIndex , response ) => {
                                //console.warn( "dispatch.getAllResponsesForChecklistQuestions ~ stopKey == " + stopKey + " ~ process == " + process + " ~ roomIndex == " + roomIndex + " ~ questionIndex == " + questionIndex + " ~ response == " + JSON.stringify( response ) );
                                if ( true ) { // PMCC DBG ~ this is the trouble maker...
                                    // dispatch action handler for salesforce data containing Response_Value__c for each question of each stop...
                                    dispatch( receiveResponse( stopKey , process , roomIndex , questionIndex , response.Response_Value__c ) );
                                }
                            } ,
                            ( stopKey , checklistQuestions ) => {
                                //console.warn( "success.getAllResponsesForChecklistQuestions ~ stopKey == " + stopKey + " ~ checklistQuestions == " + JSON.stringify( checklistQuestions ) );
                                if ( true ) {
                                    storeManager.getAllContentVersionsForChecklistQuestions(
                                        checklistQuestions ,
                                        stopKey ,
                                        ( stopKey , process , roomIndex , questionIndex , content ) => {
                                            //console.warn( "dispatch.getAllContentVersionsForChecklistQuestions ~ stopKey == " + stopKey );
                                            if ( true ) {
                                                // PMCC TODO ~ need to resolve content.VersionData into a byte stream for the reducer to append to app state...
                                                //  ~ for now just pass the path url...
                                                //  ~ i.e. ~ /services/data/***salesforceVersion***/sobjects/ContentVersion/***salesforceId***/VersionData
                                                var versionData = content.VersionData;
                                                // dispatch handler for salesforce data containing ContentVersion objects for each question of each stop...
                                                dispatch( receiveContent( stopKey , process , roomIndex , questionIndex , versionData ) );
                                            }
                                        } ,
                                        ( stopKey , checklistQuestions ) => {
                                            //console.warn( "success.getAllContentVersionsForChecklistQuestions ~ stopKey == " + stopKey );
                                            if ( showInstructions ) {
                                                //console.warn( "showInstructions == " + showInstructions );
                                                if ( stop && stop.has( "DELIVERY_INSTRUCTIONS" ) && stop.get( "DELIVERY_INSTRUCTIONS" ) ) {
                                                    dispatch( showDeliveryInstructions( stop.get( "DELIVERY_INSTRUCTIONS" ) ) );
                                                } else {
                                                    dispatch( showDeliveryInstructions( "" ) );
                                                }
                                            }
                                            finalizeRefreshStop();
                                        } ,
                                        ( error ) => {
                                            finalizeRefreshStop();
                                        }
                                    );
                                } else {
                                    finalizeRefreshStop();
                                }
                            } ,
                            ( error ) => {
                                finalizeRefreshStop();
                            }
                        );
                    } else {
                        finalizeRefreshStop();
                    }
                } ,
                ( error ) => {
                    // no transaction or no questions exist...  default case...
                    finalizeRefreshStop();
                }
            );
        } else {
            finalizeRefreshStop();
        }
    }
}


/* network-actions.js */

import { NetInfo } from 'react-native';
import { Actions } from 'react-native-router-flux';
import SplashScreen from 'react-native-splash-screen';

import {
    CHECKLIST_DETECTION_ENABLED ,
    DEBUG_DECARTES_DATA ,
    DEBUG_SALESFORCE_WITHOUT_DECARTES ,
    GET_ITEMS_WEBSERVICE_ENABLED ,
    INIT_SOUPS_ENABLED ,
    NOTIFICATION_LIST ,
    PAYLOAD_KEY ,
    RECONNECT_ENABLED ,
    ROUTE_KEY ,
    SPLASHSCREEN_DEBUG ,
} from './../config/constants';
import {
    DATA_555_JOBS ,
    DATA_888_JOBS ,
} from './../config/data';
import {
    RECEIVE_CONNECT ,
    RECEIVE_DISCONNECT ,
} from './actions';
import {
    closeModal ,
    openModal ,
} from './modal-actions';
import { addNotification } from './notification-actions';
import {
    receiveChecklists ,
    receiveResponse ,
    receiveStops ,
} from './stop-actions';
import config from './../config/config';

var storeManager = require( './../bridges/StoreManager.js' );

function handleFetchStops( dispatch : Function , id : string , nextAction : string , isRefresh : boolean ) : Object {
    console.log( "PMCC DBG ~ .fetchStops" );
    var connectStartTime = Date.now();
    const webServiceUrlStops = config.getStops( id );
    console.log( " ~!~!~ ~!~!~ ~!~!~ ~!~!~ ~!~!~ webServiceUrlStops == " + webServiceUrlStops );
    return fetch( webServiceUrlStops )
        .then(
            ( stopsResponse ) => {
                return stopsResponse.json();
            }
        )
        .then(
            ( stopsResponseJson ) => {
                handleStopsResponse( dispatch , id , nextAction , isRefresh , stopsResponseJson , connectStartTime );
            }
        )
        .catch(
            ( error ) => {
                handleError( dispatch , NOTIFICATION_LIST.NETWORK_ERROR_STOPS , isRefresh );
            }
        );
}

function handleStopsResponse( dispatch : Function , id : string , nextAction : string , isRefresh : boolean , stopsResponseJson : Object , connectStartTime : integer ) : Object {
    console.log( JSON.stringify( stopsResponseJson ) );
    if ( DEBUG_SALESFORCE_WITHOUT_DECARTES
        && ( stopsResponseJson && stopsResponseJson.hasOwnProperty( PAYLOAD_KEY )
        && ( stopsResponseJson[ PAYLOAD_KEY ].length < 1 ) )
        )
    {
        stopsResponseJson[ PAYLOAD_KEY ].push( DEBUG_DECARTES_DATA );
    }
    // easter egg for testing ui...
    switch ( id ) {
        case "555" : // qa driver id...
            stopsResponseJson[ PAYLOAD_KEY ] = DATA_555_JOBS;
            break;
        case "888" : // dev driver id...
            stopsResponseJson[ PAYLOAD_KEY ] = DATA_888_JOBS;
            break;
        default : // do nothing...  normal behavior...
            break;
    }
    if ( stopsResponseJson && stopsResponseJson.hasOwnProperty( PAYLOAD_KEY ) && ( stopsResponseJson[ PAYLOAD_KEY ].length > 0 ) ) {
        console.log( "PMCC DBG ~ fetched stops ~ " + ( ( Date.now() - connectStartTime ) / 1000 ) );
        if ( ! GET_ITEMS_WEBSERVICE_ENABLED ) {
            // skip items webservice call...  pass null items response forward...
            //  ~ GetItemsbyDriverId returns an error message from 0030-0300 hours...  possibly longer...
            console.log( "PMCC DBG ~ .finalize" );
            dispatch( receiveStops( stopsResponseJson , null ) );
            dispatch( receiveConnectOnsite( dispatch , id , nextAction ) );
            console.log( " 333 finish connect ~ " + ( ( Date.now() - connectStartTime ) / 1000 ) + " seconds total" );
        } else {
            handleFetchItems( dispatch , id , nextAction , isRefresh , stopsResponseJson , connectStartTime );
        }
    }
    if ( ! stopsResponseJson || ! stopsResponseJson.hasOwnProperty( PAYLOAD_KEY ) ) {
        handleError( dispatch , NOTIFICATION_LIST.MALFORMED_STOPS , isRefresh );
    }
    if ( ( stopsResponseJson[ PAYLOAD_KEY ].length < 1 ) ) {
        handleError( dispatch , NOTIFICATION_LIST.DRIVER_NOT_FOUND , isRefresh );
    }
}

function handleFetchItems( dispatch : Function , driverId : string , nextAction : string , isRefresh : boolean , stopsResponseJson : Object , connectStartTime : integer ) : Object {
    // fetch item data after stop data has been acquired...
    const webServiceUrlItems = config.getItems( driverId );
    console.log( " ~!~!~ ~!~!~ ~!~!~ ~!~!~ ~!~!~ webServiceUrlItems == " + webServiceUrlItems );
    console.log( "PMCC DBG ~ .fetchItems" );
    return fetch( webServiceUrlItems )
        .then(
            ( itemsResponse ) => {
                return itemsResponse.json();
            }
        )
        .then(
            ( itemsResponseJson ) => {
                console.log( " ~ itemsResponseJson == " + JSON.stringify( itemsResponseJson ) );
                handleItemsResponse( dispatch , driverId , nextAction , isRefresh , stopsResponseJson , itemsResponseJson , connectStartTime );
            }
        )
        .catch(
            ( error ) => {
                console.log( "NETWORK_ERROR_ITEMS ~ error == " + JSON.stringify( error ) );
                handleError( dispatch , NOTIFICATION_LIST.NETWORK_ERROR_ITEMS , isRefresh );
            }
        );
}

function handleItemsResponse( dispatch : Function , driverId : string , nextAction : string , isRefresh : boolean , stopsResponseJson : Object , itemsResponseJson : Object , connectStartTime : integer ) : void {
    console.log( "PMCC DBG ~ fetched items ~ " + ( ( Date.now() - connectStartTime ) / 1000 ) );
    if ( itemsResponseJson && itemsResponseJson.hasOwnProperty( PAYLOAD_KEY ) ) {
        console.log( "~ itemsResponseJson[ PAYLOAD_KEY ] == " + JSON.stringify( itemsResponseJson[ PAYLOAD_KEY ] ) );
        dispatch( receiveStops( stopsResponseJson , itemsResponseJson ) );
        if ( ! INIT_SOUPS_ENABLED ) {
            console.log( "PMCC DBG ~ .finalize" );
            dispatch( receiveConnectOnsite( distpatch , driverId , nextAction ) );
            console.log( " 222 finish connect ~ " + ( ( Date.now() - connectStartTime ) / 1000 ) + " seconds total" );
        } else {
            handleInitSoups( dispatch , driverId , nextAction , isRefresh , stopsResponseJson[ PAYLOAD_KEY ] , connectStartTime );
        }
    } else {
        handleError( dispatch , NOTIFICATION_LIST.MALFORMED_ITEMS , isRefresh );
    }
}

function handleInitSoups( dispatch : Function , driverId : string , nextAction : string , isRefresh : boolean , payload : Object , connectStartTime : integer ) : void {
    console.log( "PMCC DBG ~ .handleInitSoups" );
    NetInfo.isConnected.fetch().then(
        ( isConnected ) => {
            // proceed with refresh...
            console.log( "PMCC DBG ~ .handleInitSoups ~ NetInfo.isConnected " + ( isConnected ? "online" : "offline" ) );
            if ( isConnected ) {
                // proceed with init soups...
                console.log( "PMCC DBG ~ .initSoups" );
                storeManager.initSoups(
                    isRefresh , // only flushing soups when we are on the route screen sync operation...
                    payload ,
                    ( transactionsWithChecklist , completedStops ) => {
                        // initSoups returns the Transaction__c.Name values that HAVE a Checklist_Instance__c record related...
                        //  ~ used to toggle the display of the START button of a stop...
                        console.log( "PMCC DBG ~ .finalize" );
                        if ( CHECKLIST_DETECTION_ENABLED ) {
                            dispatch( receiveChecklists( transactionsWithChecklist ) );
                        }
                        dispatch( receiveConnectOnsite( dispatch , driverId , nextAction , completedStops ) );
                        console.log( " 111 finish connect ~ " + ( ( Date.now() - connectStartTime ) / 1000 ) + " seconds total" );
                    } ,
                    ( error ) => {
                        handleError( dispatch , error , isRefresh );
                    }
                );
            } else {
                handleError( dispatch , NOTIFICATION_LIST.NETWORK_ERROR_SALESFORCE , isRefresh );
            }
        }
    );
}

function handleError( dispatch : Function , error : string , isRefresh : boolean ) : void {
    console.log( "PMCC DBG ~ .handleError ~ error == " + error );
    // handle errors with modals when not on the connection modal...
    if ( isRefresh ) {
        dispatch( openModal( "error" , { error : error } ) );
    }
    // hide the splash screen when the action is complete...
    if ( SPLASHSCREEN_DEBUG ) {
        SplashScreen.hide();
    }
    // display the error notification...
    dispatch( addNotification( error ) );
}

function receiveConnectOnsite( dispatch : Function , id : string , nextAction : string , completedStops : Array ) : Object {
    if ( RECONNECT_ENABLED ) {
        dispatch( closeModal() );
    }
    if ( SPLASHSCREEN_DEBUG ) {
        SplashScreen.hide();
    }
    if ( nextAction && ( nextAction == ROUTE_KEY ) ) {
        Actions.route();
    }
    return {
        id ,
        type : RECEIVE_CONNECT ,
        completed_stops : completedStops ,
    };
}

export function receiveDisconnectOnsite() : Object {
    return {
        type : RECEIVE_DISCONNECT ,
    };
}

export function connectOnsite( id : string , nextAction : string , isRefresh : boolean ) : Object {
    // Thunk middleware knows how to handle functions.
    // It passes the dispatch method as an argument to the function,
    // thus making it able to dispatch actions itself.
    return function ( dispatch ) {
        // First dispatch: the app state is updated to inform
        // that the API call is starting.
        if ( ! isRefresh && SPLASHSCREEN_DEBUG ) {
            SplashScreen.show();
        }
        handleFetchStops( dispatch , id , nextAction , isRefresh );
        // The function called by the thunk middleware can return a value,
        // that is passed on as the return value of the dispatch method.
        // In this case, we return a promise to wait for.
        // This is not required by thunk middleware, but it is convenient for us.
    };
}

/* notification-actions.js */

import {
    ADD_NOTIFICATION ,
    REMOVE_NOTIFICATION ,
} from './actions';

export function addNotification( id : string ) : Object {
    return {
        id ,
        type : ADD_NOTIFICATION ,
    };
}

export function removeNotification() : Object {
    return {
        type : REMOVE_NOTIFICATION ,
    };
}

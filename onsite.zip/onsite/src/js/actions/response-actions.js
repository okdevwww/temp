/* response-actions.js */

import Immutable from 'immutable';
import {
    CONFIRM_CLOSE ,
    CONFIRM_OPEN ,
    STORE_RESPONSE ,
    STORE_TIMESTAMP ,
} from './actions';
import { Actions } from 'react-native-router-flux';

export function confirmClose( driverId : string , stopKey : string , question : Immutable.Map< string , any > , responseValue : string ) : Object {
    return {
        driverId ,
        question ,
        responseValue ,
        stopKey ,
        type : CONFIRM_CLOSE ,
    };
}

export function confirmOpen( driverId : string , stopKey : string , question : Immutable.Map< string , any > , responseValue : string ) : Object {
    return {
        driverId ,
        question ,
        responseValue ,
        stopKey ,
        type : CONFIRM_OPEN ,
    };
}

export function storeResponse( checklistInstanceId : string , question : Immutable.Map< string , any > , choice : string , stopId : string ) : Object {
    return {
        checklistInstanceId ,
        question ,
        choice ,
        stopId ,
        type : STORE_RESPONSE ,
    };
}

export function storeTimestamp( stopKey : string , timestampId : string ) : Object {
    return {
        stopKey ,
        timestampId ,
        type : STORE_TIMESTAMP ,
    };
}

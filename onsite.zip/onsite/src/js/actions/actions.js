/* actions.js */

export const ADD_NOTIFICATION = "add_notification";
export const ADD_PICTURE = "add_picture";
export const CANCEL_SIGNATURES = "cancel_signatures";
export const CHECK_DELIVERY_ITEM = "check_delivery_item";
export const CLEAR_SIGNATURES = "clear_signatures";
export const CLOSE_MODAL = "close_modal";
export const CONFIRM_CLOSE = "confirm_close";
export const CONFIRM_OPEN = "confirm_open";
export const CONTINUE_ROUTE = "continue_route";
export const DELETE_PICTURE = "delete_picture";
export const END_ROUTE = "end_route";
export const OPEN_MODAL = "open_modal";
export const RECEIVE_CONNECT = "receive_connect";
export const RECEIVE_CONTENT = "receive_content";
export const RECEIVE_CHECKLISTS = "receive_checklists";
export const RECEIVE_DISCONNECT = "receive_disconnect";
export const RECEIVE_LOGOUT = "receive_logout";
export const RECEIVE_QUESTIONS = "receive_questions";
export const RECEIVE_RESPONSE = "receive_response";
export const RECEIVE_SAVE_STATUS = "save_state";
export const RECEIVE_STOPS = "receive_stops";
export const RECONNECT_ROUTE = "reconnect_route";
export const REMOVE_NOTIFICATION = "remove_notification";
export const SET_LOCALE = "set_locale";
export const SET_PROCESS_OPEN = "set_process_open";
export const SET_STOP_ACTIVE = "set_stop_active";
export const SET_STOP_COMPLETE = "set_stop_complete";
export const SET_TAB_COMPLETED = "set_tab_completed";
export const SET_TAB_STARTED = "set_tab_started";
export const START_ROUTE = "start_route";
export const STORE_RESPONSE = "store_response";
export const STORE_SIGNATURES = "store_signatures";
export const STORE_TIMESTAMP = "store_timestamp";


/* app.js */

import React from 'react';
import {
    Dimensions ,
    Text ,
    View ,
} from 'react-native';
import { Router } from 'react-native-router-flux';
import { connect } from 'react-redux';

import { NUKE_BACK_BUTTON } from './config/constants';
import { saveState } from './actions/platform-actions';
import FooterProvider from './components/containers/footer-provider';
import HeaderProvider from './components/containers/header-provider';
import ModalProvider from './components/containers/modal-provider';
import SubHeaderProvider from './components/containers/sub-header-provider';
import Scenes from './scenes/scenes';
import AppStyles from './styles/app-styles';

// onsite crash busters exception handling...
import { setupOnsiteExceptionHandler } from './error-report';
setupOnsiteExceptionHandler();

// Create connected Router if you want dispatch() method.
const ConnectedRouter = connect() ( Router );
const ScreenHeight = Dimensions.get( "window" ).height;

class App extends React.Component {
    saveState : () => void;
    unsubscribe : () => void;

    constructor( props ) : void {
        super( props );
        this.saveState = this.saveState.bind( this );
        this.testStates = this.testStates.bind( this );
        this.observeStore = this.observeStore.bind( this );
    }

    componentDidMount() : void {
        const { store } = this.context;
        this.state = store.getState();
        this.unsubscribe = this.observeStore( store , this.saveState );
    }

    componentWillUnmount() : void {
        this.unsubscribe();
    }

    testStates( cState , nState ) {
        // check what properties changed in state
        // and decide if a save action is needed
        if ( ( cState !== undefined ) && ( nState !== undefined ) ) {
            if ( ( cState.pictures !== nState.pictures )
                || ( cState.session !== nState.session )
                || ( cState.signature !== nState.signature )
                || ( cState.stops !== nState.stops )
            )
            {
                return true;
            }
        }
        return false;
    }

    observeStore( store , onChange ) {
        let currentState;
        var handleChange = () => {
            let nextState = store.getState();
            if ( this.testStates( currentState , nextState ) ) {
                currentState = nextState;
                onChange( currentState );
            }
            if ( currentState === undefined ) {
                currentState = nextState;
            }
        }
        let unsubscribe = store.subscribe( handleChange );
        handleChange();
        return unsubscribe;
    }

    saveState( state ) : void {
        // call saveState action
        saveState( state );
    }

    render() : React.Element<any> {
        return (
            <View style={ AppStyles.container } >
                <ModalProvider />
                <HeaderProvider />
                <SubHeaderProvider />
                <ConnectedRouter scenes={ Scenes } />
                <FooterProvider />
            </View>
        );
    }
}

App.contextTypes = {
    store : React.PropTypes.object ,
};

export default App;

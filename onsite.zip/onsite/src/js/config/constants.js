/* constants.js */

// tier system...
export const TIER_PROD = "PROD";
export const TIER_QA = "QA";
export const TIER_DEV = "DEV";
export const DEFAULT_TIER = TIER_PROD;
export const IS_TIER_EXTERNAL = true;

// live in production...
export const ADD_PICTURE_ENABLED = true;
export const CHECKLIST_DETECTION_ENABLED = true;
export const COMPLETED_STOPS_ENABLED = true;
export const CRASH_BUSTERS_ENABLED = ( ! __DEV__ );
export const DAYS_FORWARD = 0;
export const GET_ITEMS_WEBSERVICE_ENABLED = true;
export const INIT_SOUPS_ENABLED = true;
export const LIMIT_SYNC_DOWN_SOUP = true;
export const NUKE_BACK_BUTTON = true;
export const RECONNECT_ENABLED = true;
export const REFRESH_CONNECTION_ENABLED = true;
export const REFRESH_SOUPS_ENABLED = true;
export const RESPONSE_IMAGE_ENABLED = true;
export const RESPONSE_SIGNATURE_ENABLED = true;
export const SKU_EXCEPTIONS_ENABLED = true;
export const SPLASHSCREEN_DEBUG = true;
export const STOP_ICON_SIZE = 32;

// ready to deploy...
export const LOCALE_ENABLED = ( __DEV__ );

// removed controls...
export const EMULATOR_ENABLED = false;
export const DEBUG_SALESFORCE_WITHOUT_DECARTES = false;
export const DEBUG_SIGNATURE_ENABLED = false;
export const REMOVE_SOUP_ENABLED = false;
export const SF_LOGOUT_ENABLED = false;

export const NOTIFICATION_LIST = {
    SALESFORCE_INIT_ERROR_AUTH : "Salesforce Initialization Error (Auth)" ,
    SALESFORCE_INIT_ERROR_CHECKLIST_INSTANCE : "Salesforce Initialization Error (ChecklistInstance)" ,
    SALESFORCE_INIT_ERROR_SMARTSTORE : "Salesforce Initialization Error (SmartStore)" ,
    DRIVER_NOT_FOUND : "Driver ID not found" ,
    MALFORMED_STOPS : "Malformed stops received" ,
    MALFORMED_ITEMS : "Malformed items received" ,
    NETWORK_ERROR_STOPS : "Network error (Stops)" ,
    NETWORK_ERROR_ITEMS : "Network error (Items)" ,
    NETWORK_ERROR_SALESFORCE : "Network error (Salesforce)" ,
};

export const STOP_TYPES = {
    EMPTY : "EMPTY" ,
    NEW : "New Delivery" ,
    PICK_UP : "Pick Up" ,
    EXCHANGE : "Exchange" ,
    PARTIAL_PICK_UP : "Partial Pick Up" ,
    ADD_ONS : "Add-ons" ,
    MOVE : "Move" ,
};

export const TIMESTAMP_KEY_RELEASE = "Key_Release_Time_Stamp__c";
export const TIMESTAMP_KEY_RETURN = "Checklist_Complete_Timestamp__c";
export const TIMESTAMP_SIGNATURE_CUSTOMER = "Customer_Signature_Timestamp__c";
export const TIMESTAMP_SIGNATURE_DRIVER = "CORT_Signature_Timestamp__c";

export const TIMESTAMP_KEYS = [
    TIMESTAMP_KEY_RELEASE ,
    TIMESTAMP_KEY_RETURN ,
    TIMESTAMP_SIGNATURE_CUSTOMER ,
    TIMESTAMP_SIGNATURE_DRIVER ,
];

export const PROCESS_KEY_RELEASE = "Key_Release";
export const PROCESS_TRUCK_INSPECTION = "Truck_Inspection";
export const PROCESS_PROPERTY_INSPECTION = "Property_Inspection";
export const PROCESS_UNIT_INSPECTION = "Unit_Inspection";
export const PROCESS_DELIVERY_SETUP = "Delivery_Setup";
export const PROCESS_CHECKLIST = "Checklist";
export const PROCESS_SIGNATURE = "Signature";
export const PROCESS_KEY_RETURN = "Key_Return";

export const PROCESS_KEYS = [
    PROCESS_KEY_RELEASE ,
    PROCESS_TRUCK_INSPECTION ,
    PROCESS_PROPERTY_INSPECTION ,
    PROCESS_UNIT_INSPECTION ,
    PROCESS_DELIVERY_SETUP ,
    PROCESS_CHECKLIST ,
    PROCESS_SIGNATURE ,
    PROCESS_KEY_RETURN ,
];

export var DELIVERY_CHECKLIST = {
    "Key_Release" : {
        id : PROCESS_KEY_RELEASE,
        text : "Key Release" ,
        icon : "vpn-key" ,
        active : false ,
        started : false ,
        completed : false ,
    } ,
    "Truck_Inspection" : {
        id : PROCESS_TRUCK_INSPECTION ,
        text : "Truck Inspection" ,
        icon : "local-shipping" ,
        active : false ,
        started : false ,
        completed : false ,
    } ,
    "Property_Inspection" : {
        id : PROCESS_PROPERTY_INSPECTION ,
        text : "Property Inspection" ,
        icon : "business" ,
        active : false ,
        started : false ,
        completed : false ,
    } ,
    "Unit_Inspection" : {
        id : PROCESS_UNIT_INSPECTION ,
        text : "Unit Inspection" ,
        icon : "grid-on" ,
        active : false ,
        started : false ,
        completed : false ,
    } ,
    "Delivery_Setup" : {
        id : PROCESS_DELIVERY_SETUP ,
        text : "Delivery Setup" ,
        icon : "weekend" ,
        active : false ,
        started : false ,
        completed : false ,
    } ,
    "Checklist" : {
        id : PROCESS_CHECKLIST ,
        text : "Checklist" ,
        icon : "low-priority" ,
        active : false ,
        started : false ,
        completed : false ,
    } ,
    "Signature" : {
        id : PROCESS_SIGNATURE ,
        text : "Signature" ,
        icon : "border-color" ,
        active : false ,
        started : false ,
        completed : false ,
    } ,
    "Key_Return" : {
        id : PROCESS_KEY_RETURN ,
        text : "Key Return" ,
        icon : "vpn-key" ,
        active : false ,
        started : false ,
        completed : false ,
    } ,
};

export const DEBUG_DECARTES_DATA = {
    LEASE_ID : "941372" ,
    TRANSACTION_ID : "1" ,
    ROUTE_NAME : "10" ,
    TRUCK_NUMBER : "10" ,
    STOP_NUMBER : "1" ,
    CUSTOMER_NAME : "Empire Office Inc. BuzzFeed" ,
    CUSTOMER_ID : "1281522" ,
    CUSTOMER_ADDRESS : "225 PARK AVE SOUTH" ,
    CUSTOMER_CITY : "NEW YORK" ,
    CUSTOMER_ZIP : "10003" ,
    CUSTOMER_PHONE : "6465317808" ,
    LEASE_TYPE : "20" ,
    DELIVERY_INSTRUCTIONS : "Please call 30 min before arrival: Ed Tassey- 646-531-7808 9 am start Meeting DJ's on site. JIC- Nicole Moeller 845-467-1403" ,
    WINDOW_START : "" ,
    WINDOW_END : "" ,
    DRIVER_ID : "010459" ,
    DRIVER_NAME : "DJ Pierre" ,
    HELPER_ID : "606143" ,
    HELPER_NAME : "Anthony Salcedo" ,
    DISTANCE : "0" ,
    ORIG_ETA : "" ,
    UPDATED_ETA : "" ,
    ACTUAL_ARRIVAL_TIME : "" ,
    GPS_ARRIVAL_TIME : "" ,
    PLANNED_SERVICE_TIME : "" ,
    ACTUAL_SERVICE_TIME : "" ,
    ORIG_ETD : "" ,
    UPDATED_ETD : "" ,
    ACTUAL_DEPARTURE_TIME : "" ,
    GPS_DEPARTURE_TIME : "" ,
    UPDATED_DT : "" ,
    STOP_STATUS : "" ,
    DELIVERY_QTY : "5" ,
    PICKUP_QTY : "0" ,
    Transaction_Type : "Delivery" ,
};

// PMCC TODO ~ collection of strings used multiple times in the code base stored here...

export const CHECKLIST_KEY = "tabs";
export const COMPLETED_STOPS_KEY = "completed_stops";
export const COMPLETED_STOP_KEY = "complete";
export const CURRENT_STOP_KEY = "stop";
export const DEFAULT_SYNC_MESSAGE_TEXT = "Sync?";
export const DEFAULT_SYNC_TITLE_TEXT = "Sync Confirmation";
export const DRIVER_KEY = "driver";
export const FOOTER_BACK_KEY = "back";
export const FOOTER_DEFAULT_KEY = "default";
export const FOOTER_INSTRUCTIONS_KEY = "instructions";
export const PAYLOAD_KEY = "payload";
export const ROUTE_KEY = "route";
export const SESSION_KEY = "id";
export const SETUP_KEY = "deliverySetup";
export const WEBSERVICE_TOKEN = "IM1gwxbD7Kr9FG2jO4ZS9Z2r7za8lcFB";

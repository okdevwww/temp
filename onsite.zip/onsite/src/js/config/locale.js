/* locale.js */

// build the set of locale keys based on the current en_US strings found in the app...
//  ~ each locale must contain every key to be valid...
export const LOC_BACK = "LOC_BACK";
export const LOC_BARCODE = "BARCODE";
export const LOC_INSTRUCTIONS = "LOC_INSTRUCTIONS";
export const LOC_CANCEL = "LOC_CANCEL";
export const LOC_CHECKLIST = "LOC_CHECKLIST";
export const LOC_CLEAR = "LOC_CLEAR";
export const LOC_CLOSE = "LOC_CLOSE";
export const LOC_CONFIRM = "LOC_CONFIRM";
export const LOC_CONFIRMATION_TEXT = "LOC_CONFIRMATION_TEXT";
export const LOC_CONFIRMATION_TITLE = "LOC_CONFIRMATION_TITLE";
export const LOC_CUSTOMER_REJECTED = "LOC_CUSTOMER_REJECTED";
export const LOC_DAMAGE = "LOC_DAMAGE";
export const LOC_DELIVERY_SETUP = "LOC_DELIVERY_SETUP";
export const LOC_DOES_NOT_FIT = "LOC_DOES_NOT_FIT";
export const LOC_EDIT = "LOC_EDIT";
export const LOC_INSTRUCTIONS_TITLE = "LOC_INSTRUCTIONS_TITLE";
export const LOC_CONNECT = "LOC_CONNECT";
export const LOC_CONTINUE_DAY = "LOC_CONTINUE_DAY";
export const LOC_DRIVER_ID = "LOC_DRIVER_ID";
export const LOC_END_DAY = "LOC_END_DAY";
export const LOC_KEY_RELEASE = "LOC_KEY_RELEASE";
export const LOC_KEY_RETURN = "LOC_KEY_RETURN";
export const LOC_MISSING = "LOC_MISSING";
export const LOC_NO = "LOC_NO";
export const LOC_OK = "LOC_OK";
export const LOC_PROPERTY_INSPECTION = "LOC_PROPERTY_INSPECTION";
export const LOC_SAVE = "LOC_SAVE";
export const LOC_SIGNATURE = "LOC_SIGNATURE";
export const LOC_SKU_EXCEPTION = "LOC_SKU_EXCEPTION";
export const LOC_SKU_NUMBER = "SKU#";
export const LOC_START = "LOC_START";
export const LOC_START_DAY = "LOC_START_DAY";
export const LOC_STOP = "LOC_STOP";
export const LOC_TRUCK_INSPECTION = "LOC_TRUCK_INSPECTION";
export const LOC_UNIT_INSPECTION = "LOC_UNIT_INSPECTION";
export const LOC_YES = "LOC_YES";
export const LOC_WRONG_ITEM = "LOC_WRONG_ITEM";

// debug version...  displays the keys only...
export const keys = {
    LOC_BACK : LOC_BACK ,
    LOC_BARCODE : LOC_BARCODE ,
    LOC_INSTRUCTIONS : LOC_INSTRUCTIONS ,
    LOC_CANCEL : LOC_CANCEL ,
    LOC_CHECKLIST : LOC_CHECKLIST ,
    LOC_CLEAR : LOC_CLEAR ,
    LOC_CLOSE : LOC_CLOSE ,
    LOC_CONFIRM : LOC_CONFIRM ,
    LOC_CONFIRMATION_TEXT : LOC_CONFIRMATION_TEXT ,
    LOC_CONFIRMATION_TITLE : LOC_CONFIRMATION_TITLE ,
    LOC_CUSTOMER_REJECTED : LOC_CUSTOMER_REJECTED ,
    LOC_DAMAGE : LOC_DAMAGE ,
    LOC_DELIVERY_SETUP : LOC_DELIVERY_SETUP ,
    LOC_DOES_NOT_FIT : LOC_DOES_NOT_FIT ,
    LOC_EDIT : LOC_EDIT ,
    LOC_INSTRUCTIONS_TITLE : LOC_INSTRUCTIONS_TITLE ,
    LOC_CONNECT : LOC_CONNECT ,
    LOC_CONTINUE_DAY : LOC_CONTINUE_DAY ,
    LOC_DRIVER_ID : LOC_DRIVER_ID ,
    LOC_END_DAY : LOC_END_DAY ,
    LOC_KEY_RELEASE : LOC_KEY_RELEASE ,
    LOC_KEY_RETURN : LOC_KEY_RETURN ,
    LOC_MISSING : LOC_MISSING ,
    LOC_NO : LOC_NO ,
    LOC_OK : LOC_OK ,
    LOC_PROPERTY_INSPECTION : LOC_PROPERTY_INSPECTION ,
    LOC_SAVE : LOC_SAVE ,
    LOC_SIGNATURE : LOC_SIGNATURE ,
    LOC_SKU_EXCEPTION : LOC_SKU_EXCEPTION ,
    LOC_SKU_NUMBER : LOC_SKU_NUMBER ,
    LOC_START : LOC_START ,
    LOC_START_DAY : LOC_START_DAY ,
    LOC_STOP : LOC_STOP ,
    LOC_TRUCK_INSPECTION : LOC_TRUCK_INSPECTION ,
    LOC_UNIT_INSPECTION : LOC_UNIT_INSPECTION ,
    LOC_YES : LOC_YES ,
    LOC_WRONG_ITEM : LOC_WRONG_ITEM ,
};

// english/us version...
export const en_US = {
    LOC_BACK : "BACK" ,
    LOC_BARCODE : "BARCODE" ,
    LOC_INSTRUCTIONS : "INSTRUCTIONS" ,
    LOC_CANCEL : "CANCEL" ,
    LOC_CHECKLIST : "Checklist" ,
    LOC_CLEAR : "CLEAR" ,
    LOC_CLOSE : "CLOSE" ,
    LOC_CONFIRM : "CONFIRM" ,
    LOC_CONFIRMATION_TEXT : "Finish route?" ,
    LOC_CONFIRMATION_TITLE : "CONFIRMATION" ,
    LOC_CONNECT : "CONNECT" ,
    LOC_CONTINUE_DAY : "Continue Route" ,
    LOC_CUSTOMER_REJECTED : "Customer Rejected" ,
    LOC_DAMAGE : "Damage" ,
    LOC_DELIVERY_SETUP : "Delivery Setup" ,
    LOC_DOES_NOT_FIT : "Does Not Fit" ,
    LOC_DRIVER_ID : "Driver ID" ,
    LOC_EDIT : "COMPLETED" ,
    LOC_END_DAY : "End Day" ,
    LOC_INSTRUCTIONS_TITLE : "Delivery Instructions" ,
    LOC_KEY_RELEASE : "Key Release" ,
    LOC_KEY_RETURN : "Key Return" ,
    LOC_MISSING : "Missing" ,
    LOC_NO : "NO" ,
    LOC_OK : "OK" ,
    LOC_PROPERTY_INSPECTION : "Property Inspection" ,
    LOC_SAVE : "SAVE" ,
    LOC_SIGNATURE : "Signature" ,
    LOC_SKU_EXCEPTION : "SKU Exception" ,
    LOC_SKU_NUMBER : "SKU#" ,
    LOC_START : "START" ,
    LOC_START_DAY : "Start Day" ,
    LOC_STOP : "Stop" ,
    LOC_TRUCK_INSPECTION : "Truck Inspection" ,
    LOC_UNIT_INSPECTION : "Unit Inspection" ,
    LOC_YES : "YES" ,
    LOC_WRONG_ITEM : "Wrong Item" ,
};

// spanish/mexico version...
export const es_MX = {
    LOC_BACK : "ESPALADA" ,
    LOC_BARCODE : "BARCODE" ,
    LOC_INSTRUCTIONS : "INSTRUCCIONES" ,
    LOC_CANCEL : "CANCELAR" ,
    LOC_CHECKLIST : "~Checklist" ,
    LOC_CLEAR : "~CLEAR" ,
    LOC_CLOSE : "~CLOSE" ,
    LOC_CONFIRM : "CONFIRMAR" ,
    LOC_CONFIRMATION_TEXT : "Finalizar la ruta?" ,
    LOC_CONFIRMATION_TITLE : "CONFIRMACIÓN" ,
    LOC_CUSTOMER_REJECTED : "~Customer Rejected" ,
    LOC_DAMAGE : "~Damage" ,
    LOC_DELIVERY_SETUP : "~Delivery Setup" ,
    LOC_DOES_NOT_FIT : "~Does Not Fit" ,
    LOC_EDIT : "TERMINADO" ,
    LOC_INSTRUCTIONS_TITLE : "Instrucciones de entrega" ,
    LOC_CONNECT : "CONECTAR" ,
    LOC_CONTINUE_DAY : "Continuar la ruta" ,
    LOC_END_DAY : "Día final" ,
    LOC_DRIVER_ID : "Driver ID" ,
    LOC_KEY_RELEASE : "~Key Release" ,
    LOC_KEY_RETURN : "~Key Return" ,
    LOC_MISSING : "~Missing" ,
    LOC_NO : "NO" ,
    LOC_OK : "DE ACUERDO" ,
    LOC_PROPERTY_INSPECTION : "~Property Inspection" ,
    LOC_SAVE : "~SAVE" ,
    LOC_SIGNATURE : "~Signature" ,
    LOC_SKU_EXCEPTION : "SKU Excepción" ,
    LOC_SKU_NUMBER : "SKU#" ,
    LOC_START : "COMIENZO" ,
    LOC_START_DAY : "Día de inicio" ,
    LOC_STOP : "Detener" ,
    LOC_TRUCK_INSPECTION : "~Truck Inspection" ,
    LOC_UNIT_INSPECTION : "~Unit Inspection" ,
    LOC_YES : "SI" ,
    LOC_WRONG_ITEM : "~Wrong Item" ,
};

// export the final locale object...
export const locale = {
    en_US : en_US ,
    es_MX , es_MX ,
    keys : keys ,
};

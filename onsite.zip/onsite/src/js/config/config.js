/* config.js */

import {
    DAYS_FORWARD ,
    DEFAULT_TIER ,
    EMULATOR_ENABLED ,
    IS_TIER_EXTERNAL ,
    TIER_PROD ,
    TIER_QA ,
    TIER_DEV ,
    WEBSERVICE_TOKEN ,
} from './constants.js';

// default to prod tier...
var SERVICE_URL = "https://ws.cort.com"; // outside cort vpn...
if ( ( DEFAULT_TIER == TIER_PROD ) && ! IS_TIER_EXTERNAL ) {
    SERVICE_URL = "https://ws-prod-ext.cort.com"; // inside cort vpn...
} else if ( DEFAULT_TIER == TIER_QA ) {
    SERVICE_URL = "https://ws-qa-ext.cort.com"; // inside cort vpn...
} else if ( DEFAULT_TIER == TIER_DEV ) {
    SERVICE_URL = "https://ws-dev.cort.com"; // inside cort vpn...
}
SERVICE_URL = SERVICE_URL + "/OnsiteWebservices/OnsiteDataService.svc";

// karega's override method for testing with local data...
var local = false;
var localPshysicalDevice = false;
if ( local ) {
    if ( localPshysicalDevice ) {
        SERVICE_URL = "http://localhost:3000";
    } else {
        SERVICE_URL = "http://192.168.57.110:3000";
    }
}

const config = {
    appTitle : "Onsite" ,
    companyName : "CORT" ,
    serviceURL : SERVICE_URL ,
    getParams( id : string ) : string {
        // correct the timestamp to be in central time...
        //  ~ ( CST == ( GMT - ( 6 * 60 ) ) )
        //  ~ 360 minute difference...
        var currentTimestamp = new Date();
        var currentTimezoneOffset = currentTimestamp.getTimezoneOffset();
        var tzDelta = ( ( currentTimezoneOffset - 360 ) / 60 ); // 360 is central time...
        // debug control to adjust the timestamp forward...
        //  ~  webservices contains 3 days of data...
        var debugDelta = 0;
        if ( ( DAYS_FORWARD > 0 ) && ( DAYS_FORWARD < 3 ) ) {
            debugDelta = ( DAYS_FORWARD * 24 );
        }
        currentTimestamp.setHours( currentTimestamp.getHours() + tzDelta + debugDelta );
        // build the date string for the webservice...
        //  ~ e.g. 01-01-2016
        var timestampString =
            ( currentTimestamp.getMonth() + 1 ) + "-" + // getMonth is 0-indexed for some reason in javascript...
            currentTimestamp.getDate() + "-" +
            currentTimestamp.getFullYear();
        //// build the common params for both web services...
        var results = "DriverID=%27" + id + "%27&$format=json";
        if ( debugDelta > 0 ) {
            results = results + "&date=%27" + timestampString + "%27";
        }
        if ( WEBSERVICE_TOKEN ) {
            results = results + "&token=%27" + WEBSERVICE_TOKEN + "%27";
        }
        return results;
    } ,
    getStops( id : string ) : string {
        return this.serviceURL + "/GetStops?" + this.getParams( id );
    } ,
    getItems( id : string ) : string {
        return this.serviceURL + "/GetItems?" + this.getParams( id );
    } ,
};

export default config;

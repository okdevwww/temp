/* data.js */

const DATA_888_JOB_00 = {
    STOP_KEY : "00" ,
    STOP_NUMBER : "0" ,
    CUSTOMER_NAME : "Austin" ,
    CUSTOMER_ID : "88" ,
    Transaction_Type : "" ,
    LEASE_ID : "" ,
    TRANSACTION_ID : "" ,
    CUSTOMER_ADDRESS : "8TH ST" ,
    CUSTOMER_CITY : "Austin" ,
    CUSTOMER_ZIP : "88880" ,
    CUSTOMER_PHONE : "" ,
    DELIVERY_INSTRUCTIONS : "" ,
    DRIVER_NAME : "X0X" ,
    Delivery : [ ] ,
    Pickup : [ ] ,
};

const DATA_888_JOB_01 = {
    STOP_KEY : "888881-1" ,
    STOP_NUMBER : "1" ,
    CUSTOMER_NAME : "818 ~ 81ST AVE" ,
    CUSTOMER_ID : "888881" ,
    Transaction_Type : "Exchange" ,
    LEASE_ID : "888881" ,
    TRANSACTION_ID : "1" ,
    CUSTOMER_ADDRESS : "818 81ST AVE" ,
    CUSTOMER_CITY : "AUSTIN" ,
    CUSTOMER_ZIP : "88881" ,
    CUSTOMER_PHONE : "8888888881" ,
    DELIVERY_INSTRUCTIONS : null , // "81 steps for 81st avenue" ,
    DRIVER_NAME : "X1X" ,
    Delivery : [
        {
            "r_lease_id" : "888881" ,
            "STOP_ID" : "1" ,
            "DESCR50" : "888881-1 SOFA DELIVERY" ,
            "sku_id" : "D-888881" ,
            "Barcode_id" : "888881-D" ,
            "type" : "Delivery" ,
            "transaction_id" : "1" ,
        } ,
    ] ,
    Pickup : [
        {
            "r_lease_id" : "888881" ,
            "STOP_ID" : "1" ,
            "DESCR50" : "888881-1 SOFA Pickup" ,
            "sku_id" : "P-888881" ,
            "Barcode_id" : "888881-P" ,
            "type" : "Pickup" ,
            "transaction_id" : "1" ,
        } ,
    ] ,
};

const DATA_888_JOB_02_01 = {
    STOP_KEY : "888882-1" ,
    STOP_NUMBER : "2" ,
    CUSTOMER_NAME : "828 ~ 82ND AVE #1" ,
    CUSTOMER_ID : "888821" ,
    Transaction_Type : "Delivery" ,
    LEASE_ID : "888882" ,
    TRANSACTION_ID : "1" ,
    CUSTOMER_ADDRESS : "828 82TH AVE #1" ,
    CUSTOMER_CITY : "AUSTIN" ,
    CUSTOMER_ZIP : "88882" ,
    CUSTOMER_PHONE : "8888888821" ,
    DELIVERY_INSTRUCTIONS : "821 steps for 82nd avenue" ,
    DRIVER_NAME : "X2X" ,
    Delivery : [
        {
            "r_lease_id" : "888882" ,
            "STOP_ID" : "2" ,
            "DESCR50" : "888882-1 SOFA DELIVERY" ,
            "sku_id" : "D-888882" ,
            "Barcode_id" : "888882-D" ,
            "type" : "Delivery" ,
            "transaction_id" : "1" ,
        } ,
    ] ,
    Pickup : [
        {
            "r_lease_id" : "888882" ,
            "STOP_ID" : "2" ,
            "DESCR50" : "888882-1 SOFA Pickup" ,
            "sku_id" : "P-888882" ,
            "Barcode_id" : "888882-P" ,
            "type" : "Pickup" ,
            "transaction_id" : "1" ,
        } ,
    ] ,
};

const DATA_888_JOB_02_02 = {
    STOP_KEY : "888882-2" ,
    STOP_NUMBER : "2" ,
    CUSTOMER_NAME : "828 ~ 82ND AVE #2" ,
    CUSTOMER_ID : "888822" ,
    Transaction_Type : "Pickup" ,
    LEASE_ID : "888882" ,
    TRANSACTION_ID : "2" ,
    CUSTOMER_ADDRESS : "828 82TH AVE #2" ,
    CUSTOMER_CITY : "AUSTIN" ,
    CUSTOMER_ZIP : "88882" ,
    CUSTOMER_PHONE : "8888888822" ,
    DELIVERY_INSTRUCTIONS : "822 steps for 82nd avenue" ,
    DRIVER_NAME : "X2X" ,
    Delivery : [
        {
            "r_lease_id" : "888882" ,
            "STOP_ID" : "2" ,
            "DESCR50" : "888882-2 SOFA DELIVERY" ,
            "sku_id" : "D-888882" ,
            "Barcode_id" : "888882-D" ,
            "type" : "Delivery" ,
            "transaction_id" : "2" ,
        } ,
    ] ,
    Pickup : [
        {
            "r_lease_id" : "888882" ,
            "STOP_ID" : "2" ,
            "DESCR50" : "888882-2 SOFA Pickup" ,
            "sku_id" : "P-888882" ,
            "Barcode_id" : "888882-P" ,
            "type" : "Pickup" ,
            "transaction_id" : "2" ,
        } ,
    ] ,
};

const DATA_888_JOB_02_03 = {
    STOP_KEY : "888882-3" ,
    STOP_NUMBER : "2" ,
    CUSTOMER_NAME : "828 ~ 82ND AVE #3" ,
    CUSTOMER_ID : "888823" ,
    Transaction_Type : "AddOn" ,
    LEASE_ID : "888882" ,
    TRANSACTION_ID : "3" ,
    CUSTOMER_ADDRESS : "828 82TH AVE #3" ,
    CUSTOMER_CITY : "AUSTIN" ,
    CUSTOMER_ZIP : "88882" ,
    CUSTOMER_PHONE : "8888888823" ,
    DELIVERY_INSTRUCTIONS : "823 steps for 82nd avenue" ,
    DRIVER_NAME : "X2X" ,
    Delivery : [
        {
            "r_lease_id" : "888882" ,
            "STOP_ID" : "2" ,
            "DESCR50" : "888882-3 SOFA DELIVERY" ,
            "sku_id" : "D-888882" ,
            "Barcode_id" : "888882-D" ,
            "type" : "Delivery" ,
            "transaction_id" : "3" ,
        } ,
    ] ,
    Pickup : [
        {
            "r_lease_id" : "888882" ,
            "STOP_ID" : "2" ,
            "DESCR50" : "888882-3 SOFA Pickup" ,
            "sku_id" : "P-888882" ,
            "Barcode_id" : "888882-P" ,
            "type" : "Pickup" ,
            "transaction_id" : "3" ,
        } ,
    ] ,
};

const DATA_888_JOB_03 = {
    STOP_KEY : "03" ,
    STOP_NUMBER : "3" ,
    CUSTOMER_NAME : "Break Stop" ,
    CUSTOMER_ID : "888883" ,
    Transaction_Type : "" ,
    LEASE_ID : "" ,
    TRANSACTION_ID : "" ,
    CUSTOMER_ADDRESS : "8TH ST" ,
    CUSTOMER_CITY : "Austin" ,
    CUSTOMER_ZIP : "88883" ,
    CUSTOMER_PHONE : "" ,
    DELIVERY_INSTRUCTIONS : "" ,
    DRIVER_NAME : "X3X" ,
    Delivery : [ ] ,
    Pickup : [ ] ,
};

const DATA_888_JOB_04 = {
    STOP_KEY : "888884-4" ,
    STOP_NUMBER : "4" ,
    CUSTOMER_NAME : "848 ~ 84TH AVE" ,
    CUSTOMER_ID : "888884" ,
    Transaction_Type : "Move" ,
    LEASE_ID : "888884" ,
    TRANSACTION_ID : "4" ,
    CUSTOMER_ADDRESS : "848 84TH AVE" ,
    CUSTOMER_CITY : "AUSTIN" ,
    CUSTOMER_ZIP : "88884" ,
    CUSTOMER_PHONE : "8888888884" ,
    DELIVERY_INSTRUCTIONS : "84 steps for 84th avenue" ,
    DRIVER_NAME : "X4X" ,
    Delivery : [
        {
            "r_lease_id" : "888884" ,
            "STOP_ID" : "4" ,
            "DESCR50" : "888884-4 SOFA DELIVERY" ,
            "sku_id" : "D-888884" ,
            "Barcode_id" : "888884-D" ,
            "type" : "Delivery" ,
            "transaction_id" : "4" ,
        } ,
    ] ,
    Pickup : [
        {
            "r_lease_id" : "888884" ,
            "STOP_ID" : "4" ,
            "DESCR50" : "888884-4 SOFA Pickup" ,
            "sku_id" : "P-888884" ,
            "Barcode_id" : "888884-P" ,
            "type" : "Pickup" ,
            "transaction_id" : "4" ,
        } ,
    ] ,
};

const DATA_888_JOB_05 = {
    STOP_KEY : "888885-5" ,
    STOP_NUMBER : "5" ,
    CUSTOMER_NAME : "858 ~ 85TH AVE" ,
    CUSTOMER_ID : "888885" ,
    Transaction_Type : "Pickup" ,
    LEASE_ID : "888885" ,
    TRANSACTION_ID : "5" ,
    CUSTOMER_ADDRESS : "858 85TH AVE" ,
    CUSTOMER_CITY : "AUSTIN" ,
    CUSTOMER_ZIP : "88885" ,
    CUSTOMER_PHONE : "8888888885" ,
    DELIVERY_INSTRUCTIONS : "85 steps for 85th avenue" ,
    DRIVER_NAME : "X5X" ,
    Delivery : [
        {
            "r_lease_id" : "888885" ,
            "STOP_ID" : "5" ,
            "DESCR50" : "888885-5 SOFA DELIVERY" ,
            "sku_id" : "D-888885" ,
            "Barcode_id" : "888885-D" ,
            "type" : "Delivery" ,
            "transaction_id" : "5" ,
        } ,
    ] ,
    Pickup : [
        {
            "r_lease_id" : "888885" ,
            "STOP_ID" : "5" ,
            "DESCR50" : "888885-5 SOFA Pickup" ,
            "sku_id" : "P-888885" ,
            "Barcode_id" : "888885-P" ,
            "type" : "Pickup" ,
            "transaction_id" : "5" ,
        } ,
    ] ,
};

const DATA_888_JOB_06 = {
    STOP_KEY : "888886-6" ,
    STOP_NUMBER : "6" ,
    CUSTOMER_NAME : "868 ~ 86TH AVE" ,
    CUSTOMER_ID : "888886" ,
    Transaction_Type : "Repair" ,
    LEASE_ID : "888886" ,
    TRANSACTION_ID : "6" ,
    CUSTOMER_ADDRESS : "868 86TH AVE" ,
    CUSTOMER_CITY : "AUSTIN" ,
    CUSTOMER_ZIP : "88886" ,
    CUSTOMER_PHONE : "8888888886" ,
    DELIVERY_INSTRUCTIONS : "86 steps for 86th avenue" ,
    DRIVER_NAME : "X6X" ,
    Delivery : [
        {
            "r_lease_id" : "888886" ,
            "STOP_ID" : "6" ,
            "DESCR50" : "888886-6 SOFA DELIVERY" ,
            "sku_id" : "D-888886" ,
            "Barcode_id" : "888886-D" ,
            "type" : "Delivery" ,
            "transaction_id" : "6" ,
        } ,
    ] ,
    Pickup : [
        {
            "r_lease_id" : "888886" ,
            "STOP_ID" : "6" ,
            "DESCR50" : "888886-6 SOFA Pickup" ,
            "sku_id" : "P-888886" ,
            "Barcode_id" : "888886-P" ,
            "type" : "Pickup" ,
            "transaction_id" : "6" ,
        } ,
    ] ,
};

const DATA_888_JOB_07 = {
    STOP_KEY : "888887-7" ,
    STOP_NUMBER : "7" ,
    CUSTOMER_NAME : "878 ~ 87TH AVE" ,
    CUSTOMER_ID : "888887" ,
    Transaction_Type : "Repo" ,
    LEASE_ID : "888887" ,
    TRANSACTION_ID : "7" ,
    CUSTOMER_ADDRESS : "878 87TH AVE" ,
    CUSTOMER_CITY : "AUSTIN" ,
    CUSTOMER_ZIP : "88887" ,
    CUSTOMER_PHONE : "8888888887" ,
    DELIVERY_INSTRUCTIONS : "87 steps for 87th avenue" ,
    DRIVER_NAME : "X7X" ,
    Delivery : [
        {
            "r_lease_id" : "888887" ,
            "STOP_ID" : "7" ,
            "DESCR50" : "888887-7 SOFA DELIVERY" ,
            "sku_id" : "D-888887" ,
            "Barcode_id" : "888887-D" ,
            "type" : "Delivery" ,
            "transaction_id" : "7" ,
        } ,
    ] ,
    Pickup : [
        {
            "r_lease_id" : "888887" ,
            "STOP_ID" : "7" ,
            "DESCR50" : "888887-7 SOFA Pickup" ,
            "sku_id" : "P-888887" ,
            "Barcode_id" : "888887-P" ,
            "type" : "Pickup" ,
            "transaction_id" : "7" ,
        } ,
    ] ,
};

const DATA_888_JOB_08 = {
    STOP_KEY : "08" ,
    STOP_NUMBER : "8" ,
    CUSTOMER_NAME : "Austin" ,
    CUSTOMER_ID : "88" ,
    Transaction_Type : "" ,
    LEASE_ID : "" ,
    TRANSACTION_ID : "" ,
    CUSTOMER_ADDRESS : "8TH ST" ,
    CUSTOMER_CITY : "Austin" ,
    CUSTOMER_ZIP : "88888" ,
    CUSTOMER_PHONE : "" ,
    DELIVERY_INSTRUCTIONS : "" ,
    DRIVER_NAME : "X8X" ,
    Delivery : [ ] ,
    Pickup : [ ] ,
};

const DATA_555_JOB_00 = DATA_888_JOB_00;
const DATA_555_JOB_01 = DATA_888_JOB_01;
const DATA_555_JOB_02_01 = DATA_888_JOB_02_01;
const DATA_555_JOB_02_02 = DATA_888_JOB_02_02;
const DATA_555_JOB_02_03 = DATA_888_JOB_02_03;
const DATA_555_JOB_03 = DATA_888_JOB_03;
const DATA_555_JOB_04 = DATA_888_JOB_04;
const DATA_555_JOB_05 = DATA_888_JOB_05;
const DATA_555_JOB_06 = DATA_888_JOB_06;
const DATA_555_JOB_07 = DATA_888_JOB_07;
const DATA_555_JOB_08 = DATA_888_JOB_08;

export const DATA_555_JOBS = [
    DATA_555_JOB_00 ,
    DATA_555_JOB_01 ,
    DATA_555_JOB_02_01 ,
    DATA_555_JOB_02_02 ,
    DATA_555_JOB_02_03 ,
    DATA_555_JOB_03 ,
    DATA_555_JOB_04 ,
    DATA_555_JOB_05 ,
    DATA_555_JOB_06 ,
    DATA_555_JOB_07 ,
    DATA_555_JOB_08 ,
];

export const DATA_888_JOBS = [
    DATA_888_JOB_00 ,
    DATA_888_JOB_01 ,
    DATA_888_JOB_02_01 ,
    DATA_888_JOB_02_02 ,
    DATA_888_JOB_02_03 ,
    DATA_888_JOB_03 ,
    DATA_888_JOB_04 ,
    DATA_888_JOB_05 ,
    DATA_888_JOB_06 ,
    DATA_888_JOB_07 ,
    DATA_888_JOB_08 ,
];

/* error-report.js */

import { CRASH_BUSTERS_ENABLED } from './config/constants';

const FORCE_UNCAUGHT_EXCEPTION = false;
const HANDLE_UNCAUGHT_EXCEPTIONS_ENABLED = true;
const LOG_UNCAUGHT_EXCEPTIONS_ENABLED = true;

function buildCrashReportBody( error ) {
    var result = "";
    var sendEmail = false;
    if ( HANDLE_UNCAUGHT_EXCEPTIONS_ENABLED ) {
	if ( error ) {
            result = "\n----- ----- ----- ----- ----- ----- ----- ----- ----- -----\n"
                + error
                + result;
        }
        var timestamp = new Date();
        if ( timestamp ) {
            result = result
                + "\n----- ----- ----- ----- ----- ----- ----- ----- ----- -----\n"
                + timestamp;
        }
	if ( error ) {
            const parseErrorStack = require( "parseErrorStack" );
            const stack = parseErrorStack( error );
            if ( stack ) {
                result = result
                    + "\n----- ----- ----- ----- ----- ----- ----- ----- ----- -----\n";
                for ( var line in stack ) {
                    sendEmail = ( line > 3 );
                    var lineData = stack[ line ];
                    var lineOutput = lineData.methodName + ":" + lineData.lineNumber;
                    result = result
                        + lineOutput + "\n";
                }
            }
        }
    }
    if ( ! sendEmail ) {
        result = "";
    }
    return result;
}

function buildCrashReportSubject( error ) {
    var result = "";
    if ( HANDLE_UNCAUGHT_EXCEPTIONS_ENABLED && error ) {
        var cryptoJS = require( "crypto-js" );
        if ( cryptoJS ) {
            var cryptoKey = "onsite-crash-busters";
            result = cryptoJS.HmacSHA1( error , cryptoKey ) + " ~ " + error;
        }
    }
    return result;
}

// log error to console and send error report via email...
function sendOnsiteCrashReport( error : string , isFatal : boolean ) : string {
    if ( HANDLE_UNCAUGHT_EXCEPTIONS_ENABLED && error && isFatal ) {
        var crashReport = buildCrashReportBody( error );
        if ( crashReport ) {
            var address = "paul.mccluskey@cort.com";
            var subject = "[ONSITE-CRASH-REPORT] " + buildCrashReportSubject( error );
            var body = "\n\n~!~ DO NOT EDIT CRASH REPORT ~!~\n" + crashReport;
            if ( LOG_UNCAUGHT_EXCEPTIONS_ENABLED ) {
                console.log( "EEEEEEEEEE EEEEEEEEEE EEEEEEEEEE ~ PMCC DBG ~ sendCrashReport ~ address == " + address );
                console.log( "EEEEEEEEEE EEEEEEEEEE EEEEEEEEEE ~ PMCC DBG ~ sendCrashReport ~ subject == " + subject );
                console.log( "EEEEEEEEEE EEEEEEEEEE EEEEEEEEEE ~ PMCC DBG ~ sendCrashReport ~ body == " + body );
            }
            // PMCC TODO ~ we need to package up the contents of this email in JSON to prepare to send to a webservice call...
            if ( CRASH_BUSTERS_ENABLED ) {
                var SendIntentAndroid = require( "react-native-send-intent" );
                SendIntentAndroid.sendMail( address , subject , body );
            }
        }
    }
}

// capture unhandled exceptions and report the callstack back to development...
function handleOnsiteException( e , isFatal ) {
    try {
        sendOnsiteCrashReport( e , isFatal );
        // continue to report standard react native redbox exception handler in development...
        require( "ExceptionsManager" ).handleException( e , isFatal );
    } catch( ee ) {
        console.log( "handleOnsiteException ~ failed to print error ~ " , ee.message );
    }
}

import { ErrorUtils } from 'react-native';
export function setupOnsiteExceptionHandler() {
    if ( HANDLE_UNCAUGHT_EXCEPTIONS_ENABLED ) {
        global.ErrorUtils.setGlobalHandler( handleOnsiteException );
        if ( FORCE_UNCAUGHT_EXCEPTION ) {
            throw new Error( "forced onsite exception" );
        }
    }
}


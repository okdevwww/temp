/* StorageManager.js */

'use strict';

import {
    CHECKLIST_DETECTION_ENABLED ,
    NOTIFICATION_LIST ,
    RESPONSE_IMAGE_ENABLED ,
} from './../config/constants.js';

import {
    QUERYSPEC_LIMIT ,
    SOUP_CHECKLIST_INSTANCE__C ,
    SOUP_CHECKLIST_QUESTION__C ,
    SOUP_RESPONSE__C ,
    SOUP_RESPONSE_IMAGE__C ,
    SOUP_CONTENTDOCUMENT ,
    SOUP_CONTENTVERSION ,
    SOUP_PARAMS ,
} from './onsite.constants.js';

////////////////////////////////////////////////////////////////////////////////

var onsitesmartstore = require( './onsite.smartstore.js' );
var oauth = require( './react.force.oauth.js' );

////////////////////////////////////////////////////////////////////////////////

// remove and then register only the currently needed soups...  recursively...  in series...
//  ~ we need to query or modify each of these record types...
// ContentDocument
// ContentVersion
// Checklist_Instance__c
// Checklist_Question__c
// Response__c
function initSoups( flush , stops , successCallback , errorCallback ) {
    // define the list of soupKeys needed...
    var soupKeys = [
        SOUP_CHECKLIST_INSTANCE__C ,
        SOUP_CHECKLIST_QUESTION__C ,
        SOUP_RESPONSE__C ,
        SOUP_RESPONSE_IMAGE__C ,
        SOUP_CONTENTVERSION ,
        SOUP_CONTENTDOCUMENT ,
    ];
    var initSoupsStartTime = Date.now();
    console.log( "PMCC DBG ~ @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" );
    console.log( "PMCC DBG ~ .initSoups ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ " );
    oauth.getAuthCredentials(
        ( credentials ) => {
            // need to filter Checklist_Instance__c, Checklist_Question__c, and Response__c by the needed transactions...
            var transactionNames = [];
            for ( var stopId in stops ) {
                if ( stops[ stopId ].LEASE_ID && stops[ stopId ].TRANSACTION_ID ) {
                    var transactionName = stops[ stopId ].LEASE_ID + "-" + stops[ stopId ].TRANSACTION_ID;
                    if ( transactionNames.indexOf( transactionName ) < 0 ) {
                        transactionNames.push( transactionName );
                    }
                }
            }
            // start with first soupKey and recurse the soup initialization in series...
            onsitesmartstore.recursiveInitSoup(
                flush ,
                credentials ,
                transactionNames ,
                null ,
                null ,
                SOUP_PARAMS ,
                soupKeys ,
                0 ,
                () => {
                    if ( CHECKLIST_DETECTION_ENABLED ) {
                        // figure out which Transaction__c records have a Checklist_Instance__c record...  this will control the visibilty of the START button on the route screen...
                        var hasChecklistQuerySpec = onsitesmartstore.buildAllQuerySpec( "TransactionName__c" , null , QUERYSPEC_LIMIT );
                        onsitesmartstore.searchSoup(
                            SOUP_CHECKLIST_INSTANCE__C ,
                            hasChecklistQuerySpec ,
                            null ,
                            ( rows , currentStoreQuery , soupKey ) => {
                                // find the transactions with a checklist object...
                                var transactionsWithChecklist = [];
                                // find the checklists that have a completed timestamp...
                                var completedStops = [];
                                // iterate the returned rows to fill both responses...
                                for ( var checklistIndex in rows ) {
                                    if ( ( rows[ checklistIndex ].Checklist_Complete_Timestamp__c !== null ) && ( rows[ checklistIndex ].TransactionName__c ) ) {
                                        completedStops.push( rows[ checklistIndex ].TransactionName__c );
                                    }
                                    if ( transactionNames.indexOf( rows[ checklistIndex ].TransactionName__c ) >= 0 ) {
                                        transactionsWithChecklist.push( rows[ checklistIndex ].TransactionName__c );
                                    }
                                }
                                if ( successCallback ) {
                                    console.log("PMCC DBG ~ all soups ( " + soupKeys.length + " : " + JSON.stringify( soupKeys ) + " ) initialized ~ " + ( ( Date.now() - initSoupsStartTime ) / 1000 ) + " ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ " );
                                    console.log( "PMCC DBG ~ @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" );
                                    successCallback( transactionsWithChecklist , completedStops );
                                }
                            } ,
                            ( error ) => {
                                console.log( "PMCC DBG ~ @$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$ ~ " + JSON.stringify( error ) );
                                if ( errorCallback ) {
                                    errorCallback( NOTIFICATION_LIST.SALESFORCE_INIT_ERROR_CHECKLIST_INSTANCE );
                                }
                            }
                        );
                    } else {
                        successCallback( [ ] ); // skip...
                    }
                } ,
                ( error ) => {
                    console.log( "PMCC DBG ~ @$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$ ~ " + JSON.stringify( error ) );
                    if ( errorCallback ) {
                        errorCallback( NOTIFICATION_LIST.SALESFORCE_INIT_ERROR_SMARTSTORE );
                    }
                }
            );
        } ,
        ( error ) => {
            console.log( "PMCC DBG ~ @$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$ ~ " + JSON.stringify( error ) );
            if ( errorCallback ) {
                errorCallback( NOTIFICATION_LIST.SALESFORCE_INIT_ERROR_AUTH );
            }
        }
    );
}

////////////////////////////////////////////////////////////////////////////////

function syncResponseImageSoup( pictures , successCallback , errorCallback ) {
    onsitesmartstore.syncSoups(
        [ SOUP_RESPONSE_IMAGE__C ] ,
        [ SOUP_PARAMS[ SOUP_RESPONSE_IMAGE__C ].SyncUpFieldList ] ,
        () => {
            if ( successCallback ) {
                successCallback( pictures );
            }
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
            throw new Error( "StoreManager.syncResponseImageSoup: " + error );
        }
    );
}

// sync only the soups we are modifying...  in series...
// Checklist_Instance__c
// Response__c
function syncSoups( successCallback , errorCallback ) {
    // define the list of soupKeys needed...
    var soupKeys = [
        SOUP_CHECKLIST_INSTANCE__C ,
        SOUP_RESPONSE__C ,
        SOUP_RESPONSE_IMAGE__C ,
        SOUP_CONTENTVERSION ,
    ];
    var soupFields = [
        SOUP_PARAMS[ SOUP_CHECKLIST_INSTANCE__C ].SyncUpFieldList ,
        SOUP_PARAMS[ SOUP_RESPONSE__C ].SyncUpFieldList ,
        SOUP_PARAMS[ SOUP_RESPONSE_IMAGE__C ].SyncUpFieldList ,
        SOUP_PARAMS[ SOUP_CONTENTVERSION ].SyncUpFieldList ,
    ];

    // find the ContentVersion records with matching titles for all Response__c records...
    var responseQuerySpec = onsitesmartstore.buildAllQuerySpec( "Id" , null , QUERYSPEC_LIMIT );
    onsitesmartstore.searchSoup(
        SOUP_RESPONSE__C ,
        responseQuerySpec ,
        null ,
        ( rows , currentStoreQuery , soupKey ) => {
            var responseTitles = [];
            for ( var rowIndex in rows ) {
                var titleToUpdate = "Onsite-" + rows[ rowIndex ].Checklist_Instance__c + "-" + rows[ rowIndex ].Checklist_Question__c;
                responseTitles.push( titleToUpdate );
            }
            console.log( " ~!~!~!~ " + responseTitles.length + " ~ responseTitles == " + responseTitles );
            // start with first soupKey and recurse the soup sync's in series...
            var syncSoupsStartTime = Date.now();
            console.log("PMCC DBG ~ .syncSoups ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ " );
            onsitesmartstore.syncSoups(
                soupKeys ,
                soupFields ,
                () => {
                    if ( RESPONSE_IMAGE_ENABLED ) {
                        // now that ContentDocument Id values have been sync'ed with SalesForce we can create the Response_Image__c records to match...
                        onsitesmartstore.storeResponseImageRecords(
                            responseTitles ,
                            ( pictures ) => {
                                // needs to sync the Response_Image__c to pick up the newly created records...
                                syncResponseImageSoup(
                                    pictures ,
                                    ( pictures ) => {
                                        if ( successCallback ) {
                                            successCallback( pictures );
                                        }
                                    } ,
                                    ( error ) => {
                                        if ( errorCallback ) {
                                            errorCallback( error );
                                            throw new Error( "StoreManager.syncSoups failed to sync Response_Image__c records with the following error: " + error );
                                        }
                                    }
                                );
                            } ,
                            ( error ) => {
                                if ( errorCallback ) {
                                    errorCallback( error );
                                    throw new Error( "StoreManager.syncSoups failed to store Response_Image__c records with the following error: " + error );
                                }
                            }
                        );
                    } else if ( successCallback ) {
                        successCallback( { } );
                    }
                } ,
                ( error ) => {
                    if ( errorCallback ) {
                        errorCallback( error );
                    }
                    throw new Error( "StoreManager.syncSoups failed to sync one or more records with the following error: " + error );
                }
            );
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
            throw new Error( "StoreManager.syncSoups failed to search Response__c records with the following error: " + error );
        }
    );
}

////////////////////////////////////////////////////////////////////////////////

function getChecklistQuestionsByTransactionName( stopId , transactionName , successCallback , errorCallback ) {
    onsitesmartstore.getChecklistInstanceByTransactionName(
        transactionName ,
        ( checklistInstance ) => {
            getChecklistQuestionsByChecklistId(
                checklistInstance.Checklist__c ,
                checklistInstance.Id ,
                ( checklistQuestions ) => {
                    if ( successCallback ) {
                        successCallback( stopId , checklistQuestions );
                    } else {
                        logQuestions( checklistQuestions );
                    }
                } ,
                ( error ) => {
                    if ( errorCallback ) {
                        errorCallback( error );
                    }
                }
            );
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
        }
    );
}

function logQuestions( checklistQuestions ) {
    var outputStr = "PMCC DBG ~ \n";
    for ( var row = 0 ; row < checklistQuestions.length ; row++ ) {
        outputStr = outputStr + stringQuestion( checklistQuestions[ row ] );
    }
    console.log( outputStr );
}

function stringQuestion( question ) {
    var outputStr = question.Question_Order__c;
    if ( question.Required__c == true ) {
        outputStr = outputStr + "*";
    }
    if ( question.Allow_Images__c == true ) {
        outputStr = outputStr + "^";
    }
    outputStr = outputStr + ") ";
    outputStr = outputStr + question.Process__c + " ~ ";
    outputStr = outputStr + question.Question_Text__c + "\n";
    //outputStr = outputStr + question.Question__r.Question_Choices__c + "\n";
    return outputStr;
}

// returns all Checklist_Question__c's with a given Checklist__r.Id...
function getChecklistQuestionsByChecklistId( checklistId , checklistInstanceId , successCallback , errorCallback ) {
    var querySpec = onsitesmartstore.buildLikeQuerySpec( "Checklist__r.Id" , checklistId , null , QUERYSPEC_LIMIT , "Question_Order__c" );
    onsitesmartstore.searchSoup(
        SOUP_CHECKLIST_QUESTION__C ,
        querySpec ,
        null ,
        ( rows , currentStoreQuery , soupKey ) => {
            var questions = {};
            var checklistQuestions = [];
            for ( var row = 0 ; row < rows.length ; row++ ) {
                var question = rows[ row ];
                // added to be able to upsert responses for this question from the ui...
                question[ "Checklist_Instance__c.Id" ] = checklistInstanceId;
                var processKey = question.Process__c.replace(" ", "_");
                var roomKey = null;
                if ( question.Room__c ) {
                    roomKey = question.Room__c;
                }
                if ( processKey && processKey == "Checklist" ) {
                    if ( roomKey ) {
                        // push a Checklist question...  requires a value for Room__c or skipped...
                        if ( ! questions[ processKey ] ) {
                            questions[ processKey ] = {};
                        }
                        if ( ! questions[ processKey ][ roomKey ] ) {
                            questions[ processKey ][ roomKey ] = [];
                        }
                        questions[ processKey ][ roomKey ].push( question );
                    }
                } else if ( processKey ) {
                    // push a normal question...
                    if ( ! questions[ processKey ] ) {
                        questions[ processKey ] = [];
                    }
                    questions[ processKey ].push( question );
                }
            }
            successCallback( questions );
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
        }
    );
}

////////////////////////////////////////////////////////////////////////////////

// get all ContentVersion's for all Checklist_Question__c's...
function getAllContentVersionsForChecklistQuestions( checklistQuestions , stopId , dispatchCallback , successCallback , errorCallback ) {
    // need to determine when to send success callback...  on last process/room combo for a response...
    var lastProcess = null;
    for ( var processKey in checklistQuestions ) {
        lastProcess = processKey;
    }
    var lastChecklistRoom = null;
    if ( checklistQuestions.hasOwnProperty( "Checklist" ) ) {
        for ( var roomKey in checklistQuestions[ "Checklist" ] ) {
            lastChecklistRoom = roomKey;
        }
    }
    // dispatch each content and send succuss on last content...
    for ( var process in checklistQuestions ) {
        if ( process == "Checklist" ) {
            for ( var room in checklistQuestions[ process ] ) {
                for ( var questionIndex in checklistQuestions[ process ][ room ] ) {
                    var question = checklistQuestions[ process ][ room ][ questionIndex ];
                    getContentVersionsForChecklistQuestion(
                        stopId ,
                        process ,
                        room ,
                        questionIndex ,
                        question ,
                        ( stopId , processIndex , roomIndex , questionIndex , content ) => {
                            if ( content && dispatchCallback ) {
                               dispatchCallback( stopId , processIndex , roomIndex , questionIndex , content );
                            }
                            if ( ( lastProcess && ( processIndex == lastProcess ) )
                                && ( lastChecklistRoom && ( roomIndex == lastChecklistRoom ) )
                                && successCallback
                            )
                            {
                                successCallback( stopId , checklistQuestions );
                            }
                        } ,
                        ( error ) => {
                            if ( errorCallback ) {
                                errorCallback( error );
                            }
                        }
                    );
                }
            }
        } else {
            for ( var questionIndex in checklistQuestions[ process ] ) {
                var question = checklistQuestions[ process ][ questionIndex ];
                getContentVersionsForChecklistQuestion(
                    stopId ,
                    process ,
                    null ,
                    questionIndex ,
                    question ,
                    ( stopId , processIndex , roomIndex , questionIndex , content ) => {
                        if ( content && dispatchCallback ) {
                            dispatchCallback( stopId , processIndex , roomIndex , questionIndex , content );
                        }
                        if ( ( lastProcess && ( processIndex == lastProcess ) && successCallback ) ) {
                            successCallback( stopId , processIndex , roomIndex , questionIndex , content );
                        }
                    } ,
                    ( error ) => {
                        if ( errorCallback ) {
                            errorCallback( error );
                        }
                    }
                );
            }
        }
    }
}

function getContentVersionsForChecklistQuestion( stopId , process , room , questionIndex , question , successCallback , errorCallback ) {
    var titleText = "Onsite-" + question[ "Checklist_Instance__c.Id" ] + "-" + question[ "Id" ];
    var querySpec = onsitesmartstore.buildLikeQuerySpec( "Title" , titleText , "descending" , 1 , "CreatedDate" );
    onsitesmartstore.searchSoup(
        SOUP_CONTENTVERSION ,
        querySpec ,
        null ,
        ( rows , currentStoreQuery , soupKey ) => {
            // LIMIT 1 ContentVersion record per Checklist_Question__c record...  the newest record...
            var content = null;
            for ( var i = 0 ; i < rows.length ; i++ ) {
                var checklistInstanceId = null;
                var questionId = null;
                if ( rows[ i ].Title ) {
                    var splitTitle = rows[ i ].Title.split( "-" );
                    if ( splitTitle.length > 2 ) {
                        checklistInstanceId = splitTitle[ 1 ];
                        questionId = splitTitle[ 2 ];
                    }
                }
                if ( ! content
                    && checklistInstanceId
                    && ( checklistInstanceId == question[ "Checklist_Instance__c.Id" ] )
                    && questionId
                    && ( questionId == question[ "Id" ] )
                )
                {
                    content = rows[ i ];
                }
            }
            successCallback( stopId , process , room , questionIndex , content );
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
        }
    );
}

////////////////////////////////////////////////////////////////////////////////

// get all Response__c's for all Checklist_Question__c's...
function getAllResponsesForChecklistQuestions( checklistQuestions , stopId , dispatchCallback , successCallback , errorCallback ) {
    // need to determine when to send success callback...  on last process/room combo for a response...
    var lastProcess = null;
    for ( var processKey in checklistQuestions ) {
        lastProcess = processKey;
    }
    var lastChecklistRoom = null;
    if ( checklistQuestions.hasOwnProperty( "Checklist" ) ) {
        for ( var roomKey in checklistQuestions[ "Checklist" ] ) {
            lastChecklistRoom = roomKey;
        }
    }
    // dispatch each response and send succuss on last response...
    for ( var process in checklistQuestions ) {
        if ( process == "Checklist" ) {
            for ( var room in checklistQuestions[ process ] ) {
                for ( var questionIndex in checklistQuestions[ process ][ room ] ) {
                    var question = checklistQuestions[ process ][ room ][ questionIndex ];
                    getResponseForChecklistQuestion(
                        stopId ,
                        process ,
                        room ,
                        questionIndex ,
                        question ,
                        ( stopId , processIndex , roomIndex , questionIndex , response ) => {
                            if ( response && dispatchCallback ) {
                                dispatchCallback( stopId , processIndex , roomIndex , questionIndex , response );
                            }
                            if ( ( lastProcess && ( processIndex == lastProcess ) )
                                && ( lastChecklistRoom && ( roomIndex == lastChecklistRoom ) )
                                && successCallback
                            )
                            {
                                successCallback( stopId , checklistQuestions );
                            }
                        } ,
                        ( error ) => {
                            if ( errorCallback ) {
                                errorCallback( error );
                            }
                        }
                    );
                }
            }
        } else {
            for ( var questionIndex in checklistQuestions[ process ] ) {
                var question = checklistQuestions[ process ][ questionIndex ];
                getResponseForChecklistQuestion(
                    stopId ,
                    process ,
                    null ,
                    questionIndex ,
                    question ,
                    ( stopId , processIndex , roomIndex , questionIndex , response ) => {
                        if ( response && dispatchCallback ) {
                            dispatchCallback( stopId , processIndex , roomIndex , questionIndex , response );
                        }
                        if ( lastProcess && ( processIndex == lastProcess ) && successCallback ) {
                            successCallback( stopId , checklistQuestions );
                        }
                    } ,
                    ( error ) => {
                        if ( errorCallback ) {
                            errorCallback( error );
                        }
                    }
                );
            }
        }
    }
}

// return the newest Response__c with a given Checklist_Instance__r.Id and Checklist_Question__r.Id...
function getResponseForChecklistQuestion( stopId , process , room , questionIndex , question , successCallback , errorCallback ) {
    var querySpec = onsitesmartstore.buildLikeQuerySpec( "Checklist_Question__c" , question.Id , "descending" , 1 , "Name" );
    onsitesmartstore.searchSoup(
        SOUP_RESPONSE__C ,
        querySpec ,
        null ,
        ( rows , currentStoreQuery , soupKey ) => {
            // LIMIT 1 Response__c record per Checklist_Question__c record...  the newest record...
            var response = null;
            for ( var i = 0 ; i < rows.length ; i++ ) {
                if ( ! response && ( rows[ i ].Checklist_Instance__c == question[ "Checklist_Instance__c.Id" ] ) ) {
                    response = rows[ i ];
                }
            }
            successCallback( stopId , process , room , questionIndex , response );
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
        }
    );
}

////////////////////////////////////////////////////////////////////////////////

// store a respose value in the local soup for a given question of a given checklist instance...
function storeResponseForChecklistQuestion( checklistInstanceId , questionId , choice , successCallback , errorCallback ) {
    // SELECT * FROM Response__c WHERE Checklist_Question__c LIKE question.Id ORDERBY Name DESC LIMIT 1
    var querySpec = onsitesmartstore.buildLikeQuerySpec( "Checklist_Question__c" , questionId , "descending" , 1 , "Name" );
    onsitesmartstore.searchSoup(
        SOUP_RESPONSE__C ,
        querySpec ,
        null ,
        ( rows , currentStoreQuery , soupKey ) => {
            // find which row, if any, that needs to be updated...
            var indexToUpdate = -1;
            for ( var i = 0 ; i < rows.length ; i++ ) {
                // need to validate againist checklistInstanceId to determine update vs insert...
                if ( ( indexToUpdate < 0 ) && ( rows[ i ].Checklist_Instance__c == checklistInstanceId ) ) {
                    indexToUpdate = i;
                }
            }
            if ( indexToUpdate >= 0 ) {
                // Response__c record exists for Checklist_Question__c and Checklist_Instance__c...  so update...
                var newResponse = rows[ 0 ];
                newResponse.Response_Value__c = choice;
                newResponse.__locally_updated__ = newResponse.__local__ = true;
                onsitesmartstore.saveObject(
                    SOUP_RESPONSE__C ,
                    newResponse ,
                    ( rows ) => {
                        if ( successCallback ) {
                            successCallback( rows );
                        }
                    } ,
                    ( error ) => {
                        if ( errorCallback ) {
                            errorCallback( error );
                        }
                    }
                );
            } else {
                // Response__c record missing...  so insert...
                // Images_Attached__c is false for new Response__c records without a ContentVersion record...
                onsitesmartstore.addObject(
                    buildResponseForUpsert(
                        questionId ,
                        checklistInstanceId ,
                        choice ,
                        false
                    ) ,
                    SOUP_RESPONSE__C ,
                    ( row ) => {
                        if ( successCallback ) {
                            successCallback( [ row ] );
                        }
                    } ,
                    ( error ) => {
                        if ( errorCallback ) {
                            errorCallback( error );
                        }
                    }
                );
            }
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
        }
    );
}

// build a new Response__c object for upsert...
function buildResponseForUpsert( checklistQuestionId , checklistInstanceId , responseValue , isImageAttached ) {
    var object = {
        Id : "local_" + ( new Date() ).getTime() ,
        Checklist_Question__c : checklistQuestionId ,
        Checklist_Instance__c : checklistInstanceId ,
        Images_Attached__c : isImageAttached ,
        attributes : { type : SOUP_RESPONSE__C } ,
        __locally_created__ : true ,
        __locally_updated__ : false ,
        __locally_deleted__ : false ,
        __local__ : true ,
    };
    if ( responseValue != null ) {
        object.Response_Value__c = responseValue;
    }
    return object;
}

////////////////////////////////////////////////////////////////////////////////

function searchContentDocuments( contentDocumentId , successCallback , errorCallback ) {
    var querySpec = onsitesmartstore.buildLikeQuerySpec( "Id" , contentDocumentId );
    onsitesmartstore.searchSoup(
        SOUP_CONTENTDOCUMENT ,
        querySpec ,
        null ,
        ( rows , currentStoreQuery , soupKey ) => {
            if ( successCallback ) {
                successCallback( rows , currentStoreQuery , soupKey );
            }
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
        }
    );
}

function searchContentVersions( successCallback , errorCallback ) {
    oauth.getAuthCredentials(
        ( credentials ) => {
            var querySpec = onsitesmartstore.buildLikeQuerySpec( "CreatedById" , credentials.userId );
            onsitesmartstore.searchSoup(
                SOUP_CONTENTVERSION ,
                querySpec ,
                null ,
                ( rows , currentStoreQuery , soupKey ) => {
                    if ( successCallback ) {
                        successCallback( rows , currentStoreQuery , soupKey );
                    }
                } ,
                ( error ) => {
                    if ( errorCallback ) {
                        errorCallback( error );
                    }
                }
            );
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
        }
    );
}

function storeResponseWithContentVersion( question , pathOnClient , versionData , choice , successCallback , errorCallback ) {
    if ( true ) {
        // we need to check for a Response__c record before creating the ContentVersion record...
        var querySpec = onsitesmartstore.buildLikeQuerySpec( "Checklist_Question__r.Id" , question.get( "Id" ) , "descending" , 1 , "Name" );
        onsitesmartstore.searchSoup(
            SOUP_RESPONSE__C ,
            querySpec ,
            null ,
            ( rows , currentStoreQuery , soupKey ) => {
                if ( rows && ( rows.length > 0 ) ) {
                    // Response__c record found...  update Response__c.Images_Attached__c to be true...
                    var responseWithContent = rows[ 0 ];
                    responseWithContent.Images_Attached__c = true;
                    if ( choice != null ) {
                        responseWithContent.Response_Value__c = choice;
                    }
                    responseWithContent.__locally_updated__ = responseWithContent.__local__ = true;
                    onsitesmartstore.saveObject(
                        SOUP_RESPONSE__C ,
                        responseWithContent ,
                        ( rows ) => {
                            if ( true ) {
                                addContentVersion( question , pathOnClient , versionData , successCallback , errorCallback );
                            } else {
                                successCallback();
                            }
                        } ,
                        ( error ) => {
                            if ( errorCallback ) {
                                errorCallback( error );
                            }
                        }
                    );
                } else {
                    // Response__c record missing...  created record with Response__c.Images_Attached__c set to true...
                    onsitesmartstore.saveObject(
                        SOUP_RESPONSE__C ,
                        buildResponseForUpsert(
                            question.get( "Id" ) ,
                            question.get( "Checklist_Instance__c.Id" ) ,
                            choice ,
                            true
                        ) ,
                        ( rows ) => {
                            if ( true ) {
                                addContentVersion( question , pathOnClient , versionData , successCallback , errorCallback );
                            } else {
                                successCallback();
                            }
                        } ,
                        ( error ) => {
                            if ( errorCallback ) {
                                errorCallback( error );
                            }
                        }
                    );
                }
            } ,
            ( error ) => {
                if ( errorCallback ) {
                    errorCallback( error );
                }
            }
        );
    }
}

function addContentVersion( question , pathOnClient , versionData , successCallback , errorCallback ) {
    // PMCC TODO ~ some versionData and pathOnClient checks...
    if ( true ) {
        // create a ContentVersion...
        var timestamp = ( new Date() ).getTime();
        var text = "Onsite-" + question.get( "Checklist_Instance__c.Id" ) + "-" + question.get( "Id" );
        var contentVersion = {
            Id : "local_" + timestamp ,
            Title : text ,
            Description : text ,
            PathOnClient : pathOnClient ,
            VersionData : versionData ,
            attributes : { type : SOUP_CONTENTVERSION } ,
            __locally_created__ : true ,
            __locally_updated__ : false ,
            __locally_deleted__ : false ,
            __local__ : true ,
        };
        console.log( "PMCC DBG ~ addContentVersion ~ contentVersion == " + JSON.stringify( contentVersion ) );
        if ( true ) {
            onsitesmartstore.addObject(
                contentVersion ,
                SOUP_CONTENTVERSION ,
                ( row ) => {
                    if ( successCallback ) {
                        successCallback( row );
                    }
                } ,
                ( error ) => {
                    if ( errorCallback ) {
                        errorCallback( error );
                    }
                }
            );
        } else {
            if ( errorCallback ) {
                errorCallback( "record not added" );
            }
        }
    } else {
        if ( errorCallback ) {
            errorCallback( "request ignored" );
        }
    }
}

////////////////////////////////////////////////////////////////////////////////

function storeTimeStamp( timestampId , transactionName , successCallback , errorCallback ) {
    onsitesmartstore.getChecklistInstanceByTransactionName(
        transactionName ,
        ( checklistInstance ) => {
            var currentTimestamp = new Date();
            var currentTimezoneOffset = currentTimestamp.getTimezoneOffset();
            // correct the timestamp to be in GMT...
            if ( currentTimezoneOffset !== 0 ) {
                currentTimestamp.setHours( currentTimestamp.getHours() + ( currentTimezoneOffset / 60 ) );
            }
            // build the date/time string in ISO 8601 format...
            // ~ slice( -2 ) trick used to get all values to have leading zero's...
            // ~ e.g. 2001-01-01T01:01:01Z
            var timestampString =
                currentTimestamp.getFullYear() + "-" +
                ( "0" + ( currentTimestamp.getMonth() + 1 ) ).slice( -2 ) + "-" +
                ( "0" + currentTimestamp.getDate() ).slice( -2 ) + "T" +
                ( "0" + currentTimestamp.getHours() ).slice( -2 ) + ":" +
                ( "0" + currentTimestamp.getMinutes() ).slice( -2 ) + ":00Z";
            checklistInstance[ timestampId ] = timestampString;
            checklistInstance.__locally_updated__ = checklistInstance.__local__ = true;
            onsitesmartstore.saveObject(
                SOUP_CHECKLIST_INSTANCE__C ,
                checklistInstance ,
                ( rows ) => {
                    if ( successCallback ) {
                        successCallback( rows );
                    }
                } ,
                ( error ) => {
                    if ( errorCallback ) {
                        errorCallback( error );
                    }
                }
            );
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
        }
    );
}

function updateSkuIdForChecklistInstance( check , skuId , transactionName , successCallback , errorCallback ) {
    onsitesmartstore.getChecklistInstanceByTransactionName(
        transactionName ,
        ( checklistInstance ) => {
            var installedSKUs = [];
            if ( checklistInstance.List_of_SKUs_Installed__c ) {
                installedSKUs = checklistInstance.List_of_SKUs_Installed__c.split( "," );
            }
            var missedSKUs = [];
            if ( checklistInstance.List_of_SKUs_Missed__c ) {
                missedSKUs = checklistInstance.List_of_SKUs_Missed__c.split( "," );
            }
            // check == true --> Installed...  else Missed...
            if ( check ) {
                // force to installed list...  remove from missed list...
                if ( installedSKUs.indexOf( skuId ) == -1 ) {
                    installedSKUs.push( skuId );
                }
                if ( missedSKUs.indexOf( skuId ) > -1 ) {
                    var newMissedSKUs = [];
                    for ( var missed in missedSKUs ) {
                        if ( skuId != missedSKUs[ missed ] ) {
                            newMissedSKUs.push( missedSKUs[ missed ] );
                        }
                    }
                    missedSKUs = newMissedSKUs;
                }
            } else {
                // force to misseded list...  remove from installed list...
                if ( missedSKUs.indexOf( skuId ) == -1 ) {
                    missedSKUs.push( skuId );
                }
                if ( installedSKUs.indexOf( skuId ) > -1 ) {
                    var newInstalledSKUs = [];
                    for ( var installed in installedSKUs ) {
                        if ( skuId != installedSKUs[ installed ] ) {
                            newInstalledSKUs.push( installedSKUs[ installed ] );
                        }
                    }
                    installedSKUs = newInstalledSKUs;
                }
            }
            checklistInstance.List_of_SKUs_Installed__c = installedSKUs.join();
            checklistInstance.List_of_SKUs_Missed__c = missedSKUs.join();
            checklistInstance.__locally_updated__ = checklistInstance.__local__ = true;
            onsitesmartstore.saveObject(
                SOUP_CHECKLIST_INSTANCE__C ,
                checklistInstance ,
                ( rows ) => {
                    if ( successCallback ) {
                        successCallback( rows );
                    }
                } ,
                ( error ) => {
                    if ( errorCallback ) {
                        errorCallback( error );
                    }
                }
            );
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
        }
    );
}

// return array of unitque item sku_id values...
function getItemSkus( items , deliverySkus ) {
    var skus = [];
    if ( deliverySkus ) {
        skus = deliverySkus;
    }
    if ( items ) {
        items.map(
            ( item , index ) => {
                if ( skus.indexOf( item.get( 'sku_id' ) ) == -1 ) {
                    skus.push( item.get( 'sku_id' ) );
                }
            }
        );
    }
    return skus;
}

function storeChecklistInstanceStopInfo( stop , transactionName , successCallback , errorCallback ) {
    onsitesmartstore.getChecklistInstanceByTransactionName(
        transactionName ,
        ( checklistInstance ) => {
            var deliverySkus = getItemSkus( stop.get( 'Delivery' ) );
            var missingSkus = getItemSkus( stop.get( 'Pickup' ) , deliverySkus ).join();
            checklistInstance.List_of_SKUs_Installed__c = "";
            checklistInstance.List_of_SKUs_Missed__c = missingSkus;
            checklistInstance.Street_Address__c = stop.get( "CUSTOMER_ADDRESS" );
            // PMCC TODO ~ CUSTOMER_APT is missing from webservice response...  Apt__c
            checklistInstance.City__c = stop.get( "CUSTOMER_CITY" );
            // PMCC TODO ~ CUSTOMER_STATE is missing from webservice response...  State__c
            checklistInstance.Zip__c = stop.get( "CUSTOMER_ZIP" );
            checklistInstance.Contact_Phone_Number_preferred__c = stop.get( "CUSTOMER_PHONE" );
            // PMCC TODO ~ CUSTOMER_EXT is also available in webservice response...
            checklistInstance.Delivery_Manager__c = stop.get( "DRIVER_NAME" );
            checklistInstance.Delivery_Assistant__c = stop.get( "HELPER_NAME" );
            checklistInstance.__locally_updated__ = checklistInstance.__local__ = true;
            onsitesmartstore.saveObject(
                SOUP_CHECKLIST_INSTANCE__C ,
                checklistInstance ,
                ( rows ) => {
                    if ( successCallback ) {
                        successCallback( rows );
                    }
                } ,
                ( error ) => {
                    if ( errorCallback ) {
                        errorCallback( error );
                    }
                }
            );
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
        }
    );
}

////////////////////////////////////////////////////////////////////////////////

module.exports = {
    initSoups : initSoups ,
    syncSoups : syncSoups ,
    syncResponseImageSoup : syncResponseImageSoup ,
    getChecklistQuestionsByTransactionName : getChecklistQuestionsByTransactionName ,
    getAllResponsesForChecklistQuestions : getAllResponsesForChecklistQuestions ,
    getAllContentVersionsForChecklistQuestions : getAllContentVersionsForChecklistQuestions ,
    storeResponseForChecklistQuestion : storeResponseForChecklistQuestion ,
    storeResponseWithContentVersion : storeResponseWithContentVersion ,
    updateSkuIdForChecklistInstance : updateSkuIdForChecklistInstance ,
    storeChecklistInstanceStopInfo : storeChecklistInstanceStopInfo ,
    storeTimeStamp : storeTimeStamp ,
    searchContentDocuments : searchContentDocuments ,
    searchContentVersions : searchContentVersions ,
}

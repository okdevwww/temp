/* onsite.smartstore.js */

'use strict';

import {
    REMOVE_SOUP_ENABLED ,
    RESPONSE_IMAGE_ENABLED ,
} from './../config/constants.js';

import {
    QUERYSPEC_LIMIT ,
    SOUP_CONTENTDOCUMENT ,
    SOUP_CONTENTVERSION ,
    SOUP_CHECKLIST_INSTANCE__C ,
    SOUP_CHECKLIST_QUESTION__C ,
    SOUP_RESPONSE__C ,
    SOUP_RESPONSE_IMAGE__C ,
} from './onsite.constants.js';

////////////////////////////////////////////////////////////////////////////////

var smartstore = require( './react.force.smartstore.js' );
var onsitesmartsync = require( './onsite.smartsync.js' );

// tracking query attempts...
var lastStoreQuerySent = 0;
var lastStoreResponseReceived = 0;

////////////////////////////////////////////////////////////////////////////////

function removeSoup( flush , soupKey , successCallback ) {
    if ( REMOVE_SOUP_ENABLED || flush ) {
        //console.warn( "flush" );
        smartstore.removeSoup( false , soupKey , successCallback );
    } else if ( successCallback ) {
        successCallback();
    }
}

function registerSoup( credentials , transactionNames , checklistIds , responseIds , soupKey , indexspec , objectname , fieldlist , successCallback , errorCallback ) {
    smartstore.registerSoup(
        false ,
        soupKey ,
        indexspec ,
        () => onsitesmartsync.syncDownSoup(
            credentials ,
            transactionNames ,
            checklistIds ,
            responseIds ,
            soupKey ,
            objectname ,
            fieldlist ,
            successCallback ,
            errorCallback
        )
    );
}

function buildAllQuerySpec( path , order , pagesize , selectpaths ) {
    return smartstore.buildAllQuerySpec( path , order , pagesize , selectpaths );
}

function buildLikeQuerySpec( path , likekey , order , pagesize , orderpath , selectpaths ) {
    return smartstore.buildLikeQuerySpec( path , likekey , order , pagesize , orderpath , selectpaths );
}

function searchSoup( soupKey , querySpec , contentDocumentId , successCallback , errorCallback ) {
    lastStoreQuerySent++;
    var currentStoreQuery = lastStoreQuerySent;
    smartstore.querySoup(
        false ,
        soupKey ,
        querySpec ,
        ( cursor ) => {
            if ( currentStoreQuery > lastStoreResponseReceived ) {
                lastStoreResponseReceived = currentStoreQuery;
                var rows = cursor.currentPageOrderedEntries;
                if ( successCallback ) {
                    successCallback( rows , currentStoreQuery , soupKey , contentDocumentId );
                }
            } else {
                console.log( "PMCC ERR ~ StoreManager.searchSoup ~ current query is older than last response ~ soupKey == " + soupKey
                    + " ~ currentStoreQuery == " + currentStoreQuery + " ~ lastStoreResponseReceived == " + lastStoreResponseReceived
                );
            }
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            } else {
                console.log( "PMCC ERR ~ StoreManager.searchSoup ~ error == " + JSON.stringify( error ) + " ~ soupKey == " + soupKey + " ~ currentStoreQuery == " + currentStoreQuery );
            }
        }
    );
}

function syncSoups( soupKeys , soupFields , successCallback , errorCallback ) {
    var syncSoupsStartTime = Date.now();
    console.log("PMCC DBG ~ .syncSoups ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ " );
    onsitesmartsync.recursiveSyncSoup(
        soupKeys ,
        soupFields ,
        0 ,
        () => {
            console.log("PMCC DBG ~ all soups ( " + soupKeys.length + " : " + JSON.stringify( soupKeys )  + " ) sync'ed ~ " + ( ( Date.now() - syncSoupsStartTime ) / 1000 ) + " ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ " );
            if ( successCallback ) {
                successCallback();
            }
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( "syncSoups: " + error );
	    }
        }
    );
}

// build a new Response_Image__c object for upsert...
function buildResponseImageForUpsert( responseId , contentDocumentId , imageName ) {
    var object = {
        Id : "local_" + ( new Date() ).getTime() ,
        Document_Title__c : imageName ,
        Response__c : responseId ,
        Content_document_ID__c : contentDocumentId ,
        attributes : { type : SOUP_RESPONSE_IMAGE__C } ,
        __locally_created__ : true ,
        __locally_updated__ : false ,
        __locally_deleted__ : false ,
        __local__ : true ,
    };
    return object;
}

function recursiveProcessContentDocuments( questionId , title , contentDocuments , contentDocumentIndex , successCallback , errorCallback ) {
    if ( contentDocuments && contentDocuments[ contentDocumentIndex ] ) {
        var responseQuerySpec = buildLikeQuerySpec( "Checklist_Question__r.Id" , questionId , "descending" , 1 , "Name" );
        var contentDocumentId = contentDocuments[ contentDocumentIndex ].ContentDocumentId;
        searchSoup(
            SOUP_RESPONSE__C ,
            responseQuerySpec ,
            contentDocumentId ,
            ( rows , currentStoreQuery , soupKey , contentDocumentId ) => {
                // there should only be a single Response__c record waiting before we get to this point...
                if ( rows && ( rows.length == 1 ) ) {
                    var responseId = rows[ 0 ].Id;
                    var responseImageQuerySpec = buildLikeQuerySpec( "Content_document_ID__c" , contentDocumentId , "descending" , QUERYSPEC_LIMIT );
                    searchSoup(
                        SOUP_RESPONSE_IMAGE__C ,
                        responseImageQuerySpec ,
                        contentDocumentId ,
                        ( rows , currentStoreQuery , soupKey , contentDocumentId ) => {
                            // there should be a 1:1:1:1:1 relationship between Response__c:ContentVersion:ContentDocument:Response_Image__c:ContentDocumentLink...
                            //  ~ so any missing Response_Image__c records get created here...
                            //  ~ the ContentDocumentLink records being created by salesforce trigger waiting on insert of the Response_Image__c record...
                            console.log( "CHECK-ADD ~ " + responseId + " ~ " + contentDocumentId + " ~ " + title + " ~ rows == " + JSON.stringify( rows ) );
                            if ( ! rows || ( rows && ( rows.length == 0 ) ) ) {
                                console.warn( " ~ ADD ~ recursiveProcessContentDocuments ~ " + title );
                                addObject(
                                    buildResponseImageForUpsert(
                                        responseId ,
                                        contentDocumentId ,
                                        title
                                    ) ,
                                    SOUP_RESPONSE_IMAGE__C ,
                                    ( row ) => {
                                        // Response_Image__c record created...  proceed to next ContentDocument record...
                                        recursiveProcessContentDocuments(
                                            questionId ,
                                            title ,
                                            contentDocuments ,
                                            ( contentDocumentIndex + 1 ) ,
                                            successCallback ,
                                            errorCallback
                                        );
                                    } ,
                                    ( error ) => {
                                        if ( errorCallback ) {
                                            errorCallback( error );
                                        }
                                    }
                                );
                            } else {
                                // Response_Image__c record exists...  skip creation but still proceed to next ContentDocument record...
                                recursiveProcessContentDocuments(
                                    questionId ,
                                    title ,
                                    contentDocuments ,
                                    ( contentDocumentIndex + 1 ) ,
                                    successCallback ,
                                    errorCallback
                                );
                            }
                        } ,
                        ( error ) => {
                            if ( errorCallback ) {
                                errorCallback( error );
                            }
                        }
                    );
                } else if ( errorCallback ) {
                    errorCallback( "missing response" );
                }
            } ,
            ( error ) => {
                if ( errorCallback ) {
                    errorCallback( "search response failed" );
                }
            }
        );
    } else if ( successCallback ) {
        // no more records...  succeed...
        successCallback();
    }
}

function recursiveProcessContentVersionTitles( titleIndex , contentVersionTitles , successCallback , errorCallback ) {
    if ( contentVersionTitles && contentVersionTitles[ titleIndex ] ) {
        var title = contentVersionTitles[ titleIndex ];
        var titleSplit = title.split( "-" );
        if ( titleSplit && ( titleSplit.length >= 3 ) ) {
            var checklistInstanceId = titleSplit[ 1 ];
            var questionId = titleSplit[ 2 ];
            var querySpec = buildLikeQuerySpec( "Title" , title , null , QUERYSPEC_LIMIT );
            // by this point all ContentVersions have been upserted and sync'ed and therefore all ContentDocument records now have non-local Id values...
            //  ~  we need to created Response_Image__c records to link Response__c records to ContentDocumentRecords...
            searchSoup(
                SOUP_CONTENTVERSION ,
                querySpec ,
                null ,
                ( rows , currentStoreQuery , soupKey , contentDocumentId ) => {
                    // must be recursive to make the asyncronous calls report the final successCallback to here...
                    recursiveProcessContentDocuments(
                        questionId ,
                        title ,
                        rows ,
                        0 ,
                        () => {
                            recursiveProcessContentVersionTitles(
                                ( titleIndex + 1 ) ,
                                contentVersionTitles ,
                                successCallback ,
                                errorCallback
                            );
                        } ,
                        ( error ) => {
                        } ,
                    );
                } ,
                ( error ) => {
                    if ( errorCallback ) {
                        errorCallback( error );
                    }
                }
            );
        } else if ( errorCallback ) {
            errorCallback( "title format error" );
        }
    } else {
        // nothing more to be created...
        successCallback();
    }
}

function storeResponseImageRecords( contentVersionTitles , successCallback , errorCallback ) {
    if ( RESPONSE_IMAGE_ENABLED ) {
        recursiveProcessContentVersionTitles(
            0 ,
            contentVersionTitles ,
            () => {
                // PMCC TODO ~ pictures should either be passed in or ideally computed from the existing ContentDocument records...
                var pictures = null;
                successCallback( pictures );
            } ,
            ( error ) => {
                if ( errorCallback ) {
                    errorCallback( error );
                }
            }
        );
    } else {
        // nothing to do...
        successCallback();
    }
}

function addObject( object , soupKey , successCallback , errorCallback ) {
    smartstore.upsertSoupEntries(
        false ,
        soupKey ,
        [ object ] ,
        ( rows ) => {
            if ( successCallback && rows && ( rows.length > 0 ) ) {
                successCallback( rows[ 0 ] )
            }
        } ,
        errorCallback
    );
}

function saveObject( soupKey , object , successCallback , errorCallback ) {
    smartstore.upsertSoupEntries(
        false ,
        soupKey ,
        [ object ] ,
        ( rows ) => {
            successCallback( rows );
        } ,
        errorCallback
    );
}

function deleteObject( soupKey , object , successCallback , errorCallback ) {
    console.log( "PMCC DBG ~ onsite.smartstore.deleteObject ~ object == " + JSON.stringify( object ) + " ~ soupKey == " + soupKey );
    // removeFromSoup crashes in the SalesforceReact lib SmartStoreReactBridge.java:106
    /*
    smartstore.removeFromSoup(
        false ,
        soupKey ,
        [ object._soupEntryId ] ,
        successCallback ,
        errorCallback
    );
    */
}

////////////////////////////////////////////////////////////////////////////////

// returns Checklist_Instance__c with a given TransactionName__c...
function getChecklistInstanceByTransactionName( transactionName , successCallback , errorCallback ) {
    var querySpec = smartstore.buildMatchQuerySpec( null , "{" + SOUP_CHECKLIST_INSTANCE__C + ":TransactionName__c}:\"" + transactionName + "\"" , null , 1 );
    searchSoup(
        SOUP_CHECKLIST_INSTANCE__C ,
        querySpec ,
        null ,
        ( rows , currentStoreQuery , soupKey , contentDocumentId ) => {
            if ( ( rows.length == 1 ) && successCallback ) {
                successCallback( rows[ 0 ] );
            } else if ( errorCallback ) {
                errorCallback( " ~!~ TransactionName__c == " + transactionName + " returned rows.length == " + rows.length );
            }
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
        }
    );
}

// find all Checklist__c.Id values associated with a list of Transaction__c.Name values...
function recursiveGetChecklistIds( transactionNames , transactionIndex , checklistIds , checklistInstanceIds , successCallback ) {
    if ( transactionNames && ( transactionNames.length > transactionIndex ) ) {
        getChecklistInstanceByTransactionName(
            transactionNames[ transactionIndex ] ,
            ( checklistInstance ) => {
                checklistIds.push( checklistInstance.Checklist__c );
                checklistInstanceIds.push( checklistInstance.Id );
                recursiveGetChecklistIds( transactionNames , ( transactionIndex + 1 ) , checklistIds , checklistInstanceIds , successCallback );
            } ,
            ( error ) => {
                recursiveGetChecklistIds( transactionNames , ( transactionIndex + 1 ) , checklistIds , checklistInstanceIds , successCallback );
            }
        );
    } else if ( successCallback ) {
        successCallback( checklistIds , checklistInstanceIds );
    }
}

// returns Id values of Response__c records with a given Checklist_Instance__c.Id value...
function getResponseIdsByChecklistInstanceId( checklistInstanceId , successCallback , errorCallback ) {
    var querySpec = buildLikeQuerySpec( "Checklist_Instance__r.Id" , checklistInstanceId , null , QUERYSPEC_LIMIT );
    searchSoup(
        SOUP_RESPONSE__C ,
        querySpec ,
        null ,
        ( rows , currentStoreQuery , soupKey , contentDocumentId ) => {
            var responseIds = [];
            for ( var rowIndex in rows ) {
                if ( rowIndex && rows[ rowIndex ] && rows[ rowIndex ].hasOwnProperty( "Id" ) ) {
                    responseIds.push( rows[ rowIndex ].Id );
                }
            }
            successCallback( responseIds );
        } ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( error );
            }
        }
    );
}

// find all Response__c.Id values associated with a list of Checklist_Instance__c.Id values...
function recursiveGetResponseIds( checklistInstanceIds , checklistInstanceIdIndex , responseIds , successCallback ) {
    if ( checklistInstanceIds && ( checklistInstanceIds.length > checklistInstanceIdIndex ) ) {
        getResponseIdsByChecklistInstanceId(
            checklistInstanceIds[ checklistInstanceIdIndex ] ,
            ( responseIds ) => {
                recursiveGetResponseIds( checklistInstanceIds , ( checklistInstanceIdIndex + 1 ) , responseIds , successCallback );
            } ,
            ( error ) => {
                recursiveGetResponseIds( checklistInstanceIds , ( checklistInstanceIdIndex + 1 ) , responseIds , successCallback );
            }
        );
    } else if ( successCallback ) {
        successCallback( responseIds );
    }
}

// remove and register an individual soup in smartstore...  then recurse to next soupKey if defined...
function recursiveInitSoup( flush , credentials , transactionNames , checklistIds , responseIds , soupParams , soupKeys , soupIndex , successCallback , errorCallback ) {
    var recursiveInitSoupStartTime = Date.now();
    console.log("PMCC DBG ~ .recursiveInitSoup( " + soupKeys[ soupIndex ] + " ) ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ " );
    removeSoup(
        flush ,
        soupKeys[ soupIndex ] ,
        ( removeJson ) => {
            var questionTransactionNames = null;
            if ( ( soupKeys[ soupIndex ] == SOUP_CHECKLIST_QUESTION__C )
                || ( soupKeys[ soupIndex ] == SOUP_RESPONSE_IMAGE__C )
                )
            {
                questionTransactionNames = transactionNames;
            }
            recursiveGetChecklistIds(
                questionTransactionNames ,
                0 ,
                [] ,
                [] ,
                ( checklistIds , checklistInstanceIds ) => {
                    recursiveGetResponseIds(
                        checklistInstanceIds ,
                        0 ,
                        [] ,
                        ( responseIds ) => {
                            registerSoup(
                                credentials ,
                                transactionNames ,
                                checklistIds ,
                                responseIds ,
                                soupKeys[ soupIndex ] ,
                                soupParams[ soupKeys[ soupIndex ] ].IndexSpec ,
                                soupParams[ soupKeys[ soupIndex ] ].ObjectName ,
                                soupParams[ soupKeys[ soupIndex ] ].FieldList ,
                                ( registerJson ) => {
                                    console.log("PMCC DBG ~ ( " + soupKeys[ soupIndex ] + " ) soup initialized ~ " + ( ( Date.now() - recursiveInitSoupStartTime ) / 1000 ) + " ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ " );
                                    if ( soupKeys.length > ( soupIndex + 1 ) ) {
                                        // recurse in to the next soupKey...
                                        recursiveInitSoup(
                                            flush ,
                                            credentials ,
                                            transactionNames ,
                                            checklistIds ,
                                            responseIds ,
                                            soupParams ,
                                            soupKeys ,
                                            ( soupIndex + 1 ) ,
                                            () => {
                                                 // all done...
                                                 if ( successCallback ) {
                                                     successCallback();
                                                 }
                                            } ,
                                            ( error ) => {
                                                 // recursiveInitSoup error...
                                                 if ( errorCallback ) {
                                                     errorCallback( error );
                                                 }
                                            }
                                        );
                                    } else {
                                        // all done...
                                        if ( successCallback ) {
                                            successCallback();
                                        }
                                    }
                                } ,
                                ( error ) => {
                                    // registerSoup error...
                                    if ( errorCallback ) {
                                        errorCallback( error );
                                    }
                                }
                            )
                        }
                    );
                }
            );
        }
    );
}

////////////////////////////////////////////////////////////////////////////////

module.exports = {
    syncSoups : syncSoups ,
    buildAllQuerySpec : buildAllQuerySpec ,
    buildLikeQuerySpec : buildLikeQuerySpec ,
    searchSoup : searchSoup ,
    addObject : addObject ,
    saveObject : saveObject ,
    getChecklistInstanceByTransactionName : getChecklistInstanceByTransactionName ,
    recursiveInitSoup : recursiveInitSoup ,
    storeResponseImageRecords : storeResponseImageRecords ,
}

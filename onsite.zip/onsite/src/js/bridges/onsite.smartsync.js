/* onsite.smartsync.js ~ wrapper for react.force.smartsync to be used within the onsite app */

'use strict';

import {
    LIMIT_SYNC_DOWN_SOUP ,
} from './../config/constants.js';

import {
    SOUP_CHECKLIST_INSTANCE__C ,
    SOUP_CHECKLIST_QUESTION__C ,
    SOUP_RESPONSE__C ,
    SOUP_RESPONSE_IMAGE__C ,
    SOUP_CONTENTDOCUMENT ,
    SOUP_CONTENTVERSION ,
} from './onsite.constants.js';

////////////////////////////////////////////////////////////////////////////////

var smartsync = require( "./react.force.smartsync.js" );

// semaphores to block concurrent syncs (syncDown, syncUp, or reSync) of the same soup...
var syncsInFlight = {};

// tracking soup entry ids...  shared variable between syncDownSoup and reSyncSoup...
var soupEntryIds = {};

////////////////////////////////////////////////////////////////////////////////

function buildWhereClause( soupKey , credentials , transactionNames , checklistIds , responseIds ) {
    // we only need records related to the Checklist_Instance__c records that match Transaction__c.Name OR Checklist__c.Id values for today's stops...
    var result = "";
    var createdByIdClause = "";
    var transactionNameClause = "";
    var checklistIdClause = "";
    var responseIdClause = "";
    if ( LIMIT_SYNC_DOWN_SOUP ) {
        // build clause for created by...  or make impossible clause when transactionNames is empty...
        createdByIdClause = "";
        if ( ( soupKey == SOUP_CONTENTDOCUMENT ) || ( soupKey == SOUP_CONTENTVERSION ) ) {
            createdByIdClause = "( CreatedById = '" + credentials.userId + "' )";
        } else if ( transactionNames.length <= 0 ) {
            createdByIdClause = "( Id = '' )";
        }
        // build clause for transaction names...
        transactionNameClause = "";
        for ( var index in transactionNames ) {
            var indexNameClause = "";
            if ( soupKey == SOUP_CHECKLIST_INSTANCE__C ) {
                indexNameClause = "TransactionName__c = '" + transactionNames[ index ] + "'";
            }
            if ( soupKey == SOUP_RESPONSE__C ) {
                indexNameClause = "Checklist_Instance__r.TransactionName__c = '" + transactionNames[ index ] + "'";
            }
            if ( indexNameClause ) {
                if ( transactionNameClause ) {
                    // all other transaction names...  OR'ed together with the previous...
                    transactionNameClause = transactionNameClause + " OR " + indexNameClause;
                } else {
                    // first transasction name...
                    transactionNameClause = indexNameClause;
                }
            }
        }
        if ( transactionNameClause ) {
            transactionNameClause = "( " + transactionNameClause + " )";
        }
        // build clause for checklist id values...
        checklistIdClause = "";
        for ( var index in checklistIds ) {
            var indexNameClause = "";
            if ( soupKey == SOUP_CHECKLIST_QUESTION__C ) {
                indexNameClause = "Checklist__r.Id = '" + checklistIds[ index ] + "'";
            }
            if ( indexNameClause ) {
                if ( checklistIdClause ) {
                    // all other checklist instance ids...  OR'ed together with the previous...
                    checklistIdClause = checklistIdClause + " OR " + indexNameClause;
                } else {
                    // first checklist instance id...
                    checklistIdClause = indexNameClause;
                }
            }
        }
        if ( checklistIdClause ) {
            checklistIdClause = "( " + checklistIdClause + " )";
        }
        // build clause for response id values...
        responseIdClause = "";
        for ( var index in responseIds ) {
            if ( soupKey == SOUP_RESPONSE_IMAGE__C ) {
                if ( responseIdClause ) {
                    // all other response ids...  OR'ed together with the previous...
                    responseIdClause = responseIdClause + " OR Response__r.Id = '" + responseIds[ index ] + "'";;
                } else {
                    // first response id...
                    responseIdClause = "Response__r.Id = '" + responseIds[ index ] + "'";
                }
            }
        }
        if ( responseIdClause ) {
            responseIdClause = "( " + responseIdClause + " )";
        }
    }
    // finalize where clause string...
    if ( createdByIdClause || transactionNameClause || checklistIdClause || responseIdClause ) {
        if ( createdByIdClause ) {
            // affects ContentDocument and ContentVersion
            result = createdByIdClause;
        }
        if ( transactionNameClause ) {
            // affects Checklist_Instance__c and Response__c records...
            if ( result ) {
                result = result + " AND " + transactionNameClause;
            } else {
                result = transactionNameClause;
            }
        }
        if ( checklistIdClause ) {
            // affects Checklist_Question__c records...
            if ( result ) {
                result = result + " AND " + checklistIdClause;
            } else {
                result = checklistIdClause;
            }
        }
        if ( responseIdClause ) {
            // affects Response_Image__c records...
            if ( result ) {
                result = result + " AND " + responseIdClause;
            } else {
                result = responseIdClause;
            }
        }
        if ( result ) {
            result = "WHERE ( " + result + " )";
        }
    }
    console.log( "PMCC DBG ~ @@@@@ @@@@@ @@@@@ @@@@@ @@@@@ ~ onsite.smartsync.buildWhereClause ~ result( " + soupKey + " ) == " + JSON.stringify( result ) );
    return result;
}

function syncDownSoup( credentials , transactionNames , checklistIds , responseIds , soupKey , objectname , fieldlist , successCallback , errorCallback ) {
    if ( ! syncsInFlight.hasOwnProperty( soupKey ) ) {
        syncsInFlight[ soupKey ] = true;
        var whereClause = buildWhereClause( soupKey , credentials , transactionNames , checklistIds , responseIds );
        var target = { type : "soql" , query : "SELECT " + fieldlist.join( "," ) + " FROM " + objectname + " " + whereClause + " LIMIT 10000" };
        smartsync.syncDown(
            false ,
            target ,
            soupKey ,
            { mergeMode : smartsync.MERGE_MODE.OVERWRITE } ,
            ( sync ) => {
                delete syncsInFlight[ soupKey ]; // clear semaphore for this soup...
                soupEntryIds[ soupKey ] = sync._soupEntryId; // record last successful sync soup entry id...
                console.log( "PMCC DBG ~ .................... ~ StoreManager.syncDownSoup.syncDown.SUCCESS.soupKey == " + soupKey );
                console.log( "PMCC DBG ~ sync == " + JSON.stringify( sync ) );
                if ( successCallback ) {
                    successCallback( sync );
                }
            } ,
            ( error ) => {
                delete syncsInFlight[ soupKey ];
                if ( errorCallback ) {
                    errorCallback( error );
                } else {
                    console.log( "error == " + JSON.stringify( error ) );
                }
            }
        );
    } else {
        var error = "PMCC ERR ~ .................... ~ Not starting syncDown - sync already in flight ~ soupKey == " + soupKey;
        if ( errorCallback ) {
            errorCallback( error );
        } else {
            console.log( "error == " + JSON.stringify( error ) );
        }
    }
}

////////////////////////////////////////////////////////////////////////////////

// sync and resync an individual soup in smartstore...  then recurse to next soupKey if defined...
function recursiveSyncSoup( soupKeys , soupFields , soupIndex , successCallback , errorCallback ) {
    var recursiveSyncSoupStartTime = Date.now();
    console.log("PMCC DBG ~ .recursiveSyncSoup( " + soupKeys[ soupIndex ] + " ) ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ " );
    syncUpSoup(
        soupKeys[ soupIndex ] ,
        soupFields[ soupIndex ] ,
        () => reSyncSoup(
            soupKeys[ soupIndex ] ,
            () => {
                console.log("PMCC DBG ~ ( " + soupKeys[ soupIndex ] + " ) soup sync'ed ~ " + ( ( Date.now() - recursiveSyncSoupStartTime ) / 1000 ) + " ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ ~~~~~~~~~~ " );
                if ( soupKeys.length > ( soupIndex + 1 ) ) {
                    // recurse in to the next soupKey...
                    recursiveSyncSoup(
                        soupKeys ,
                        soupFields,
                        ( soupIndex + 1 ) ,
                        () => {
                            if ( successCallback ) {
                                successCallback();
                            }
                        } ,
                        ( error ) => {
                            if ( errorCallback ) {
                                errorCallback( error );
                            }
                        }
                    );
                } else {
                    // all done...
                    if ( successCallback ) {
                        successCallback();
                    }
                }
            } ,
            ( error ) => {
                if ( errorCallback ) {
                    errorCallback( "reSyncSoup: " + error );
                }
            }
        ) ,
        ( error ) => {
            if ( errorCallback ) {
                errorCallback( "syncUpSoup: " + error );
            }
        }
    );
}

function syncUpSoup( soupKey , syncUpFieldList , successCallback , errorCallback ) {
    if ( ! syncsInFlight.hasOwnProperty( soupKey ) ) {
        console.log( "PMCC DBG ~ ........................................Starting syncUp ~ soupKey == " + soupKey );
        syncsInFlight[ soupKey ] = true;
        smartsync.syncUp(
            false ,
            {} ,
            soupKey ,
            { mergeMode : smartsync.MERGE_MODE.OVERWRITE , fieldlist : syncUpFieldList } ,
            ( sync ) => {
                delete syncsInFlight[ soupKey ]; // clear semaphore for this soup...
                console.log( "PMCC DBG ~ .................... ~ StoreManager.syncUpSoup.syncUp.SUCCESS.soupKey == " + soupKey );
                console.log( "PMCC DBG ~ sync == " + JSON.stringify( sync ) );
                if ( successCallback ) {
                    successCallback( sync );
                }
            } ,
            ( error ) => {
                delete syncsInFlight[ soupKey ]; // clear semaphore for this soup...
                if ( errorCallback ) {
                    errorCallback( error );
                } else {
                    console.log( "error == " + JSON.stringify( error ) );
                }
            }
        );
    } else {
        var error = "PMCC ERR ~ .................... ~ Not starting syncUp - sync already in flight ~ soupKey == " + soupKey;
        if ( errorCallback ) {
            errorCallback( error );
        } else {
            console.log( "error == " + JSON.stringify( error ) );
        }
    }
}

function reSyncSoup( soupKey , successCallback , errorCallback ) {
    if ( ! syncsInFlight.hasOwnProperty( soupKey ) ) {
        console.log( "PMCC DBG ~ ........................................Starting reSync ~ soupKey == " + soupKey );
        syncsInFlight[ soupKey ] = true;
        smartsync.reSync(
            false ,
            soupEntryIds[ soupKey ] ,
            ( sync ) => {
                delete syncsInFlight[ soupKey ]; // clear semaphore for this soup...
                soupEntryIds[ soupKey ] = sync._soupEntryId; // record last successful sync soup entry id...
                console.log( "PMCC DBG ~ .................... ~ StoreManager.reSyncSoup.reSync.SUCCESS.soupKey == " + soupKey );
                console.log( "PMCC DBG ~ sync == " + JSON.stringify( sync ) );
                if ( successCallback ) {
                    successCallback( sync );
                }
            } ,
            ( error ) => {
                delete syncsInFlight[ soupKey ]; // clear semaphore for this soup...
                if ( errorCallback ) {
                    errorCallback( error );
                } else {
                    console.log( "error == " + JSON.stringify( error ) );
                }
            }
        );
    } else {
        var error = "PMCC ERR ~ .................... ~ Not starting reSync - sync already in flight ~ soupKey == " + soupKey;
        if ( errorCallback ) {
            errorCallback( error );
        } else {
            console.log( "error == " + JSON.stringify( error ) );
        }
    }
}

module.exports = {
    syncDownSoup : syncDownSoup ,
    recursiveSyncSoup : recursiveSyncSoup ,
}

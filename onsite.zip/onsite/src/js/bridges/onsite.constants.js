/* onsite.constants.js */

"use strict";

export const QUERYSPEC_LIMIT = 5000;
export const SOUP_CHECKLIST_INSTANCE__C = "Checklist_Instance__c";
export const SOUP_CHECKLIST_QUESTION__C = "Checklist_Question__c";
export const SOUP_RESPONSE__C = "Response__c";
export const SOUP_RESPONSE_IMAGE__C = "Response_Image__c";
export const SOUP_CONTENTDOCUMENT = "ContentDocument";
export const SOUP_CONTENTVERSION = "ContentVersion";
export const SOUP_CONTENTDOCUMENTLINK = "ContentDocumentLink";

const INDEXSPEC_LOCAL = { path : "__local__" , type : "string" };
const INDEXSPEC_ID = { path : "Id" , type : "string" };
const INDEXSPEC_NAME = { path : "Name" , type : "full_text" };
const INDEXSPEC_TITLE = { path : "Title" , type : "full_text" };
const INDEXSPEC_CREATEDDATE = { path : "CreatedDate" , type : "full_text" };
const INDEXSPEC_CREATEDBYID = { path : "CreatedById" , type : "string" };

const SPEC_CHECKLIST_INSTANCE__C = {
    ObjectName : "Checklist_Instance__c" ,
    FieldList : [
        "Id" ,
        "Name" ,
        "TransactionName__c" ,
        "Checklist__c" ,
        "List_of_SKUs_Installed__c" ,
        "List_of_SKUs_Missed__c" ,
        "Street_Address__c" ,
        "City__c" ,
        "Zip__c" ,
        "Contact_Phone_Number_preferred__c" ,
        "Delivery_Manager__c" ,
        "Delivery_Assistant__c" ,
        "Key_Release_Time_Stamp__c" ,
        "CORT_Signature_Timestamp__c" ,
        "Customer_Signature_Timestamp__c" ,
        "Checklist_Complete_Timestamp__c" ,
        "CreatedDate" ,
        "CreatedById" ,
    ] ,
    IndexSpec : [
        INDEXSPEC_LOCAL ,
        INDEXSPEC_ID ,
        { path : "TransactionName__c" , type : "full_text" } ,
    ] ,
    SyncUpFieldList : [
        "Id" ,
        "List_of_SKUs_Installed__c" ,
        "List_of_SKUs_Missed__c" ,
        "Street_Address__c" ,
        "City__c" ,
        "Zip__c" ,
        "Contact_Phone_Number_preferred__c" ,
        "Delivery_Manager__c" ,
        "Delivery_Assistant__c" ,
        "Key_Release_Time_Stamp__c" ,
        "CORT_Signature_Timestamp__c" ,
        "Customer_Signature_Timestamp__c" ,
        "Checklist_Complete_Timestamp__c" ,
    ] ,
};

const SPEC_CHECKLIST_QUESTION__C = {
    ObjectName : "Checklist_Question__c" ,
    FieldList : [
        "Id" ,
        "Name" ,
        "Checklist__r.Id" ,
        "Question_Order__c" ,
        "Required__c" ,
        "Allow_Images__c" ,
        "Question_Text__c" ,
        "Question__r.Id" ,
        "Question__r.Question_Choices__c" ,
        "Question__r.Sync__c" ,
        "Process__c" ,
        "Room__c" ,
        "CreatedDate" ,
    ] ,
    IndexSpec : [
        INDEXSPEC_LOCAL ,
        INDEXSPEC_ID ,
        { path : "Checklist__r.Id" , type : "string" } ,
        { path : "Question_Order__c" , type : "integer" } ,
    ] ,
    SyncUpFieldList : [
        "Id"
    ] ,
};

const SPEC_RESPONSE__C = {
    ObjectName : "Response__c" ,
    FieldList : [
        "Id" ,
        "Name" ,
        "Contact_Name__c" ,
        "Question_Text__c" ,
        "Checklist_Instance__c" ,
        "Checklist_Instance__r.Id" ,
        "Checklist_Question__c" ,
        "Checklist_Question__r.Id" ,
        "Response_Value__c" ,
        "Images_Attached__c" ,
        "CreatedDate" ,
    ] ,
    IndexSpec : [
        INDEXSPEC_LOCAL ,
        INDEXSPEC_ID ,
        INDEXSPEC_NAME ,
        { path : "Checklist_Instance__r.Id" , type : "string" } ,
        { path : "Checklist_Instance__c" , type : "string" } ,
        { path : "Checklist_Question__r.Id" , type : "string" } ,
        { path : "Checklist_Question__c" , type : "string" } ,
    ] ,
    SyncUpFieldList : [
        "Id" ,
        "Checklist_Instance__c" ,
        "Checklist_Question__c" ,
        "Response_Value__c" ,
        "Images_Attached__c" ,
    ] ,
};

const SPEC_RESPONSE_IMAGE__C = {
    ObjectName : "Response_Image__c" ,
    FieldList : [
        "Id" ,
        "Content_document_ID__c" ,
        "Document_Title__c" ,
        "Response__r.Id" ,
        "Response__c" ,
        "CreatedDate" ,
    ] ,
    IndexSpec : [
        INDEXSPEC_LOCAL ,
        INDEXSPEC_ID ,
        { path : "Response__r.Id" , type : "string" } ,
        { path : "Response__c" , type : "string" } ,
        { path : "Content_document_ID__c" , type : "string" } ,
    ] ,
    SyncUpFieldList : [
        "Id" ,
        "Content_document_ID__c" ,
        "Document_Title__c" ,
        "Response__c" ,
    ] ,
};

const SPEC_CONTENTDOCUMENT = {
    ObjectName : "ContentDocument" ,
    FieldList : [
        "Id" ,
        "Title" ,
        "Description" ,
        // new fields...
        "CreatedDate" ,
        "PublishStatus" ,
        "FileType" ,
        "FileExtension" ,
        "SharingOption" ,
    ] ,
    IndexSpec : [
        INDEXSPEC_LOCAL ,
        INDEXSPEC_ID ,
        INDEXSPEC_TITLE ,
    ] ,
    SyncUpFieldList : [
        "Id" ,
    ] ,
};

const SPEC_CONTENTVERSION = {
    ObjectName : "ContentVersion" ,
    FieldList : [
        "Id" ,
        "Title" ,
        "ContentUrl" ,
        "PathOnClient" ,
        "ContentDocumentId" ,
        // new fields...
        "IsLatest" ,
        "VersionNumber" ,
        "Description" ,
        "ReasonForChange" ,
        "SharingOption" ,
        "RatingCount" ,
        "IsDeleted" ,
        "ContentModifiedDate" ,
        "ContentModifiedById" ,
        "PositiveRatingCount" ,
        "NegativeRatingCount" ,
        "FeaturedContentBoost" ,
        "FeaturedContentDate" ,
        "CurrencyIsoCode" ,
        "OwnerId" ,
        "CreatedById" ,
        "CreatedDate" ,
        "LastModifiedById" ,
        "LastModifiedDate" ,
        "SystemModstamp" ,
        "TagCsv" ,
        "FileType" ,
        "PublishStatus" ,
        "VersionData" ,
        "ContentSize" ,
        "FileExtension" ,
        "FirstPublishLocationId" ,
        "Origin" ,
        "NetworkId" ,
        "ContentLocation" ,
        "TextPreview" ,
        "ExternalDocumentInfo1" ,
        "ExternalDocumentInfo2" ,
        "Checksum" ,
        "IsMajorVersion" ,
    ] ,
    IndexSpec : [
        INDEXSPEC_LOCAL ,
        INDEXSPEC_ID ,
        INDEXSPEC_TITLE ,
        INDEXSPEC_CREATEDBYID ,
        INDEXSPEC_CREATEDDATE ,
    ] ,
    SyncUpFieldList : [
        "Id" ,
        "Title" ,
        "Description" ,
        "ContentUrl" ,
        "PathOnClient" ,
        "VersionData" ,
    ] ,
};

const SPEC_CONTENTDOCUMENTLINK = {
    ObjectName : "ContentDocumentLink" ,
    FieldList : [
        "Id" ,
        "CreatedDate" ,
    ] ,
    IndexSpec : [
        INDEXSPEC_ID ,
        INDEXSPEC_CREATEDDATE ,
    ] ,
    SyncUpFieldList : [
        "Id" ,
    ] ,
};

export const SOUP_PARAMS = {
    Checklist_Instance__c : SPEC_CHECKLIST_INSTANCE__C ,
    Checklist_Question__c : SPEC_CHECKLIST_QUESTION__C ,
    Response__c : SPEC_RESPONSE__C ,
    Response_Image__c : SPEC_RESPONSE_IMAGE__C ,
    ContentDocument : SPEC_CONTENTDOCUMENT ,
    ContentVersion : SPEC_CONTENTVERSION ,
    ContentDocumentLink : SPEC_CONTENTDOCUMENTLINK ,
};


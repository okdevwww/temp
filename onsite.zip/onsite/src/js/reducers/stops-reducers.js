/* stops-reducers.js */

import Immutable from 'immutable';
import {
    CHECK_DELIVERY_ITEM ,
    RECEIVE_STOPS ,
    RECEIVE_QUESTIONS ,
    RECEIVE_RESPONSE ,
    RECEIVE_CONTENT ,
    RECEIVE_CHECKLISTS ,
    SET_STOP_ACTIVE ,
    SET_PROCESS_OPEN ,
    SET_TAB_STARTED ,
    SET_TAB_COMPLETED ,
    STORE_RESPONSE ,
    STORE_TIMESTAMP ,
} from './../actions/actions';
import {
    SOUP_RESPONSE__C ,
    SOUP_CHECKLIST_INSTANCE__C ,
    SOUP_CHECKLIST_QUESTION__C ,
} from './../bridges/onsite.constants.js';
import {
    CHECKLIST_DETECTION_ENABLED ,
    CHECKLIST_KEY ,
    COMPLETED_STOP_KEY ,
    DELIVERY_CHECKLIST ,
    GET_ITEMS_WEBSERVICE_ENABLED ,
    PAYLOAD_KEY ,
    SKU_EXCEPTIONS_ENABLED ,
    STOP_TYPES ,
    TIMESTAMP_KEY_RETURN ,
} from './../config/constants';
import{ locale } from './../config/locale.js';

var storeManager = require( './../bridges/StoreManager.js' );

const getStopType = function getStopType( stopDetails : Object ) : string {
    return STOP_TYPES.NEW;
};

const getStopTabsByType = function getStopTabsByType( stopDetails : Object ) : Object {
    return DELIVERY_CHECKLIST;
};

export function getActiveStop( stops : Immutable.OrderedMap<string , any> ) : string {
    return stops.findKey(
        ( stop ) => {
            return ( stop.get( "active" ) === true );
        }
    );
}

// can update the checked status of a Delivery or Pickup item...
const handleInstallItems = function handleInstallItems( items : Immutable.OrderedMap<string , any> , action : Object ) : Immutable.OrderedMap<string , any> {
    //console.warn( "handleInstallItem ~ action == " + JSON.stringify( action ) );
    // determine the validation for the action.item...
    //  ~ Barcode_id should be null for all Pickup items...
    //  ~ Barcode_id can be 0 for some Delivery items...
    // therefore...
    //  ~ use Barcode_id if non-null and non-zero...
    //  ~ else use sku_id...  using sku_id can cause multiple items to be selected...
    if ( items ) {
        items = items.map(
            ( item ) => {
                if ( ( item.get( "sku_id" ) === action.item.get( "sku_id" ) )
                    && ( item.get( "Barcode_id" ) == action.item.get( "Barcode_id" ) )
                )
                {
                    // mark this item as installed or skipped...
                    if ( action.value ) {
                        item = item.set( "checked" , ( action.value.toUpperCase() == locale.en_US.LOC_YES.toUpperCase() ) );
                    }
                    // set or clear the exception on this item...
                    var exception = "";
                    if ( action.exceptionId ) {
                        exception = action.exceptionId;
                    }
                    if ( SKU_EXCEPTIONS_ENABLED ) {
                        item = item.set( "selected_sku_exception" , exception );
                    }
                    // flag this item to have been answered once by a driver...
                    if ( ! item.get( "hasUserInput" ) ) {
                        item = item.set( "hasUserInput" , true );
                    }
                }
                return item;
            }
        );
    }
    return items;
};

const getStopKey = function getStopKey( details : Array<Object> ) : string {
    //console.warn( "getStopKey ~ details == " + JSON.stringify( details ) );
    var result = null;
    if ( details ) {
        if ( details.LEASE_ID && details.TRANSACTION_ID ) {
            result = details.LEASE_ID + "-" + details.TRANSACTION_ID;
        } else if ( details.r_lease_id && details.transaction_id ) {
            result = details.r_lease_id + "-" + details.transaction_id;
        }
        // 2 digit customer id implies a warehouse stop...
        if ( details.CUSTOMER_ID
            && ( details.CUSTOMER_ID > 0 )
            && ( details.CUSTOMER_ID <= 999 )
            )
        {
            result = null; // reset for warehouse stops...
        }
    }
    return result;
}

const processStops = function processStops( stopsJSON : Array<Object> , itemsJSON : Array<Object> ) : Object {
    var stops = {};
    // build the stops data from the route response
    stopsJSON[ PAYLOAD_KEY ].map(
        ( stopDetails ) => {
            // setup the defualts stop details...
            stopDetails.ICON_NUMBER = "X";
            if ( stopDetails.STOP_NUMBER ) {
                stopDetails.ICON_NUMBER = ( ( +stopDetails.STOP_NUMBER < 10 ) ? "0" + stopDetails.STOP_NUMBER : stopDetails.STOP_NUMBER );
            }
            stopDetails.STOP_NUMBER = stopDetails.ICON_NUMBER;
            stopDetails.type = getStopType( stopDetails );
            stopDetails.tabs = getStopTabsByType( stopDetails );
            // determine the correct key...
            var stopKey = getStopKey( stopDetails );
            if ( stopKey === null ) {
                // handle break and warehouse stops...
                stopKey = stopDetails.ICON_NUMBER;
                stopDetails.Transaction_Type = null;
            }
            // insert the stop details with the correct key...
            stopDetails.STOP_KEY = stopKey;
            stops[ stopKey ] = stopDetails;
        }
    );
    if ( GET_ITEMS_WEBSERVICE_ENABLED ) {
        // append the item data to the stop data
        itemsJSON[ PAYLOAD_KEY ].map(
            ( itemDetails ) => {
                var stopKey = getStopKey( itemDetails );
                if ( ( stopKey !== null ) && itemDetails.hasOwnProperty( "type" ) && ( typeof stops[ stopKey ] !== "undefined" ) ) {
                    if ( typeof stops[ stopKey ][ itemDetails.type ] == "undefined" ) {
                        stops[ stopKey ][ itemDetails.type ] = [];
                    }
                    stops[ stopKey ][ itemDetails.type ].push( itemDetails );
                }
            }
        );
    }
    return stops;
};

const compareStops = function( A : object , B : object ) : int {
    // localeCompare returns a negitive value when A should occur before B... i.e. "01" before "02"...
    var result = 0;
    // first compare icon number...
    var iconNumberCheck = ( A.get( "ICON_NUMBER" ).localeCompare( B.get( "ICON_NUMBER" ) ) );
    if ( iconNumberCheck == 0 ) {
        // if result has not changed...  then compare the lease id to sort multi-job stops...
        var leaseIdCheck = ( A.get( "LEASE_ID" ).localeCompare( B.get( "LEASE_ID" ) ) );
        if ( leaseIdCheck == 0 ) {
            // if result has not changed...  then compare the transaction id to sort multi-job stops...
            result = ( A.get( "TRANSACTION_ID" ).localeCompare( B.get( "TRANSACTION_ID" ) ) );
        } else {
            // lease id check is the result...
            result = leaseIdCheck;
        }
    } else {
        // icon number check is the result...
        result = iconNumberCheck;
    }
    return result;
}

const stops = function (stops : Immutable.OrderedMap<string , any> , action : Object ) : Immutable.OrderedMap<string , any> {

    switch ( action.type ) {

        case SET_STOP_ACTIVE :
            return stops.map(
                ( stop ) => {
                    if ( stop.get( "STOP_KEY" ) === action.stopKey ) {
                        stop = stop.set( "active" , true );
                    } else {
                        stop = stop.set( "active" , false );
                    }
                    return stop;
                }
            );

        case RECEIVE_STOPS :
            //console.warn( "RECEIVE_STOPS ~ action == " + JSON.stringify( action ) );
            // store the list of completed stops before processing the new set of stop data...
            var completedStops = {};
            stops.map(
                ( stopCheck , index ) => {
                    if ( stopCheck.get( COMPLETED_STOP_KEY ) ) {
                        var stopCheckKey = getStopKey( stopCheck.toJS() );
                        if ( stopCheckKey !== null ) {
                            completedStops[ stopCheckKey ] = stopCheckKey;
                        }
                    }
                }
            );
            // process the new stop data and then sort by the stop number...
            var processedStops = Immutable.OrderedMap( Immutable.fromJS( processStops( action.stops , action.items ) ) );
            if ( false ) { // debug...
                processedStops.map(
                    ( processedStop , index ) => {
                        console.warn( "processedStops[ " + index + " ].LEASE_ID == " + JSON.stringify( processedStop.get( "LEASE_ID" ) )
                            + "\n ~ processedStop.typeof == " + JSON.stringify( typeof processedStop )
                            + "\n ~ processedStop.TRANSACTION_ID == " + JSON.stringify( processedStop.get( "TRANSACTION_ID" ) )
                            + "\n ~ processedStop.ICON_NUMBER == " + JSON.stringify( processedStop.get( "ICON_NUMBER" ) )
                            + "\n ~ processedStop.STOP_NUMBER == " + JSON.stringify( processedStop.get( "STOP_NUMBER" ) )
                            + "\n ~ processedStop.CUSTOMER_ID == " + JSON.stringify( processedStop.get( "CUSTOMER_ID" ) )
                            + "\n ~ processedStop == " + JSON.stringify( processedStop )
                        );
                    }
                );
            }
            // sort stop by stop number, then lease id, then transaction id...
            var sortedStops = processedStops.sort( ( a , b ) => ( compareStops( a , b ) ) );
            if ( false ) { // debug...
                sortedStops.map(
                    ( sortedStop , index ) => {
                        console.warn( "index == " + JSON.stringify( index )
                            + "\n ~ sortedStop.LEASE_ID == " + JSON.stringify( sortedStop.get( "LEASE_ID" ) )
                            + "\n ~ sortedStop.TRANSACTION_ID == " + JSON.stringify( sortedStop.get( "TRANSACTION_ID" ) )
                            + "\n ~ sortedStop.ICON_NUMBER == " + JSON.stringify( sortedStop.get( "ICON_NUMBER" ) )
                            + "\n ~ sortedStop.STOP_NUMBER == " + JSON.stringify( sortedStop.get( "STOP_NUMBER" ) )
                            + "\n ~ sortedStop == " + JSON.stringify( sortedStop )
                        );
                    }
                );
            }
            // reset the complete flag for stops that were previously completed...
            sortedStops.map(
                ( stopSorted , index ) => {
                    var stopSortedKey = getStopKey( stopSorted.toJS() );
                    if ( ( stopSortedKey !== null ) && completedStops[ stopSortedKey ] ) {
                        sortedStops = sortedStops.setIn( [ index , COMPLETED_STOP_KEY ] , true );
                    }
                }
            );
            return sortedStops;

        case RECEIVE_QUESTIONS :
            //console.warn( "PMCC DBG ~ RECEIVE_QUESTIONS ~ action == " + JSON.stringify( action ) );
            return stops.setIn( [ action.stopId , SOUP_CHECKLIST_QUESTION__C ] , Immutable.fromJS( action.questions ) );

        case RECEIVE_RESPONSE :
            //console.warn( "PMCC DBG ~ RECEIVE_RESPONSE ~ action == " + JSON.stringify( action ) );
            if ( action.room ) {
                // only used when the Process__c value is "Checklist"...
                return stops.setIn( [ action.stopId , SOUP_CHECKLIST_QUESTION__C , action.process , action.room , action.index , "Choice" ] , action.response );
            } else {
                return stops.setIn( [ action.stopId , SOUP_CHECKLIST_QUESTION__C , action.process , action.index , "Choice" ] , action.response );
            }

        case RECEIVE_CONTENT :
            //console.warn( "PMCC DBG ~ RECEIVE_CONTENT ~ action == " + JSON.stringify( action ) );
            if ( action.room ) {
                // only used when the Process__c value is "Checklist"...
                return stops.setIn( [ action.stopId , SOUP_CHECKLIST_QUESTION__C , action.process , action.room , action.index , "VersionData" ] , action.content );
            } else {
                return stops.setIn( [ action.stopId , SOUP_CHECKLIST_QUESTION__C , action.process , action.index , "VersionData" ] , action.content );
            }

        case RECEIVE_CHECKLISTS :
            //console.warn( "PMCC DBG ~ RECEIVE_CHECKLISTS ~ action == " + JSON.stringify( action ) );
            if ( CHECKLIST_DETECTION_ENABLED ) {
                stops = stops.map(
                    ( stopInfo , index ) => {
                        if ( stopInfo
                            && stopInfo.has( "LEASE_ID" )
                            && ( stopInfo.get( "LEASE_ID" ) !== undefined )
                            && ( stopInfo.get( "LEASE_ID" ) !== null )
                            && ( stopInfo.get( "LEASE_ID" ) !== "" )
                            && stopInfo.has( "TRANSACTION_ID" )
                            && ( stopInfo.get( "TRANSACTION_ID" ) !== undefined )
                            && ( stopInfo.get( "TRANSACTION_ID" ) !== null )
                            && ( stopInfo.get( "TRANSACTION_ID" ) !== "" )
                        )
                        {
                            if ( action.transactions.indexOf( stopInfo.get( "LEASE_ID" ) + "-" + stopInfo.get( "TRANSACTION_ID" ) ) >= 0 ) {
                                stopInfo = stopInfo.set( "hasChecklistInstance" , true );
                            }
                        }
                        return stopInfo;
                    }
                );
            }
            return stops;

        case STORE_TIMESTAMP:
            //console.warn( "PMCC DBG ~ STORE_TIMESTAMP ~ action == " + JSON.stringify( action ) );
            // smartstore soup update...
            var stop = stops.get( action.stopKey );
            var transactionName = stop.get( "LEASE_ID" ) + "-" + stop.get( "TRANSACTION_ID" );
            storeManager.storeTimeStamp(
                action.timestampId ,
                transactionName ,
            );
            var newStops = stops;
            if ( action.timestampId == TIMESTAMP_KEY_RETURN ) {
                newStops = newStops.setIn( [ action.stopKey , COMPLETED_STOP_KEY ] , true );
            }
            return newStops;

        case STORE_RESPONSE:
            //console.warn( "PMCC DBG ~ STORE_RESPONSE ~ action == " + JSON.stringify( action ) );
            // smartstore soup update...
            storeManager.storeResponseForChecklistQuestion(
                action.checklistInstanceId ,
                action.question.get( "Id" ) ,
                action.choice ,
            );
            // stops state object update...
            var newStops = stops;
            var processKey = action.question.get( "Process__c" ).replace( " " , "_" );
            var questionsMap = stops.getIn( [ action.stopId , SOUP_CHECKLIST_QUESTION__C , processKey ] );
            if ( processKey == "Checklist" ) {
                questionsMap = stops.getIn( [ action.stopId , SOUP_CHECKLIST_QUESTION__C , processKey , action.question.get( "Room__c" ) ] );
            }
            if ( questionsMap ) {
                questionsMap.map(
                    ( searchQuestion , index ) => {
                        if ( searchQuestion.get( "Question_Order__c" ) == action.question.get( "Question_Order__c" ) ) {
                            if ( processKey == "Checklist" ) {
                                newStops = newStops.setIn( [ action.stopId , SOUP_CHECKLIST_QUESTION__C , processKey , action.question.get( "Room__c" ) , index , "Choice" ] , action.choice );
                            } else {
                                newStops = newStops.setIn( [ action.stopId , SOUP_CHECKLIST_QUESTION__C , processKey , index , "Choice" ] , action.choice );
                            }
                        }
                    }
                );
            }
            return newStops;

        case CHECK_DELIVERY_ITEM :
            //console.warn( "CHECK_DELIVERY_ITEM ~ action == " + JSON.stringify( action ) );
            var stopKey = getStopKey( action.item.toJS() );
            var items = handleInstallItems( stops.getIn( [ stopKey , "Delivery" ] ) , action );
            var newStops = stops.setIn( [ stopKey , "Delivery" ] , items );
            items = handleInstallItems( stops.getIn( [ stopKey , "Pickup" ] ) , action );
            return newStops.setIn( [ stopKey , "Pickup" ] , items );

        case SET_PROCESS_OPEN :
            //console.warn( "SET_PROCESS_OPEN ~ action == " + JSON.stringify( action ) );
            tabs = stops.getIn( [ action.stopId , CHECKLIST_KEY ] );
            if ( action.active === false ) {
                newTabs = tabs.setIn( [ action.processId , "active" ] , false );
            } else {
                newTabs = tabs.map(
                    ( tab , id ) => {
                        if ( id === action.processId ) {
                            tab = tab.set( "active" , true );
                        } else {
                            tab = tab.set( "active" , false );
                        }
                        return tab;
                    }
                );
            }
            if ( action.completed !== undefined ) {
                newTabs = newTabs.setIn( [ action.processId , "completed" ] , action.completed );
            }
            return stops.setIn( [ action.stopId , CHECKLIST_KEY ] , newTabs );

        case SET_TAB_STARTED :
            //console.warn( "SET_TAB_STARTED ~ action == " + JSON.stringify( action ) );
            tabs = stops.getIn( [ action.stopId , CHECKLIST_KEY ] );
            newTabs = tabs.setIn( [ action.id , "started" ] , true );
            return stops.setIn( [ action.stopId , CHECKLIST_KEY ] , newTabs );

        case SET_TAB_COMPLETED :
            //console.warn( "SET_TAB_COMPLETE ~ action == " + JSON.stringify( action ) );
            tabs = stops.getIn( [ action.stopId , CHECKLIST_KEY ] );
            newTabs = tabs.setIn( [ action.id , "completed" ] , true );
            return stops.setIn( [ action.stopId , CHECKLIST_KEY ] , newTabs );

        default :
            return stops;
    }
};

export default stops;

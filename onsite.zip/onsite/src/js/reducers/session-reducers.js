/* session-reducers.js */

import Immutable from 'immutable';

import {
    CONFIRM_CLOSE ,
    CONFIRM_OPEN ,
    CONTINUE_ROUTE ,
    END_ROUTE ,
    RECEIVE_CONNECT ,
    RECEIVE_DISCONNECT ,
    RECONNECT_ROUTE ,
    SET_LOCALE ,
    SET_PROCESS_OPEN ,
    SET_STOP_ACTIVE ,
    SET_STOP_COMPLETE ,
    START_ROUTE ,
    STORE_TIMESTAMP ,
} from './../actions/actions';
import {
    CURRENT_STOP_KEY ,
    COMPLETED_STOPS_KEY ,
    LOCALE_ENABLED ,
    SESSION_KEY ,
} from './../config/constants';
import { locale } from './../config/locale';

export function getLocalizedString( session : Immutable.Map<string , any> , localeKey ) : string {
    // default to static "X"...
    var result = "X";
    // update to english if available...
    if ( locale && locale.en_US && locale.en_US[ localeKey ] ) {
        result = locale.en_US[ localeKey ];
    }
    // update to the current locale if available...
    if ( LOCALE_ENABLED && locale && locale[ session.get( "locale" ) ] && locale [ session.get( "locale" ) ][ localeKey ] ) {
        result = locale[ session.get( "locale" ) ][ localeKey ];
    }
    return result;
}

const session = function( session : Immutable.Map<string , any> , action : Object ) : Immutable.Map<string , any> {

    switch ( action.type ) {

        case CONFIRM_CLOSE :
            //console.warn( "CONFIRM_CLOSE == " + JSON.stringify( action ) + " ~ session == " + JSON.stringify( session.get( "confirmationActive" ) ) );
            return session.set( "confirmationActive" , false ); // hide the "confirm/cancel" dialog...
        case CONFIRM_OPEN :
            //console.warn( "CONFIRM_OPEN == " + JSON.stringify( action ) + " ~ session == " + JSON.stringify( session.get( "confirmationActive" ) ) );
            return session.set( "confirmationActive" , true ); // show the "confirm/cancel" dialog...

        case SET_LOCALE :
            //console.warn( "SET_LOCALE ~ action == " + JSON.stringify( action ) + " ~ " + session.get( "locale" ) );
            return session.set( "locale" , action.locale );
        case STORE_TIMESTAMP :
            //console.warn( "STORE_TIMESTAMP ~ action == " + JSON.stringify( action ) );
            return session;
        case SET_STOP_COMPLETE :
            //console.warn( "SET_STOP_COMPLETE ~ action == " + JSON.stringify( action ) );
            var completedStops = session.get( COMPLETED_STOPS_KEY );
            if ( ! completedStops ) {
                completedStops = [];
            }
            if ( action && action.stopKey && ( completedStops.indexOf( action.stopKey ) < 0 ) ) {
                completedStops.push( action.stopKey );
            }
            //console.warn( "SET_STOP_COMPLETE ~ completedStops == " + JSON.stringify( completedStops ) + " ~ stopKey " + JSON.stringify( action.stopKey ) );
            if ( completedStops ) {
                session = session.set( COMPLETED_STOPS_KEY , completedStops ); // set the completed stops...
            }
            //console.warn( "SET_STOP_COMPLETE ~ session == " + JSON.stringify( session ) + " ~ stopKey " + JSON.stringify( action.stopKey ) );
            return session;
        case SET_PROCESS_OPEN :
            var signatureActive = false;
            if ( action.processId == "Signature" ) {
                signatureActive = action.active;
            }
            return session.set( "subHeaderEnabled" , ( ! signatureActive ) ) // e.g. "Jesus Lopez ~ Stop #2" sub-header visiblity...
                .set( "footerEnabled" , ( ! signatureActive ) ) // e.g. "Back" and "Instructions" visibility...
                .set( "scrollEnabled" , ( ! signatureActive ) ); // e.g. scroll ability...
        case RECONNECT_ROUTE :
            //console.warn( "RECONNECT_ROUTE" );
            return session.set( "menuActive" , true ) // show the "start/continue/end" menu...  hide the route...
                .set( "subHeaderEnabled" , true ) // show the sub-header...
                .set( "footerEnabled" , false ) // hide the footer...
                .set( "confirmationActive" , false ); // hide the "confirm/cancel" dialog...  on reload app...
        case END_ROUTE :
            //console.warn( "END_ROUTE ~ action == " + JSON.stringify( action ) );
            return session.set( "menuActive" , true ) // show the "start/continue/end" menu...  hide the route...
                .set( SESSION_KEY , "" ) // clear the driver id...
                .set( COMPLETED_STOPS_KEY , null ); // reset the completed stops...
        case RECEIVE_CONNECT :
            console.log( "RECEIVE_CONNECT"
                + " ~ session.completed_stops == " + JSON.stringify( session.get( COMPLETED_STOPS_KEY ) )
                + " ~ action.completed_stops == " + JSON.stringify( action.completed_stops ) );
            return session.set( "menuActive" , false ) // hide the "start/continue/end" menu...  show the route...
                .set( SESSION_KEY , action.id ) // set the current driver id...
                .set( "footerEnabled" , true ) // show the footer...
                .set( "scrollEnabled" , true ) // e.g. scroll enabled...
                .set( COMPLETED_STOPS_KEY , action.completed_stops ) // correct the completed stops...
                .set( "confirmationActive" , false ); // hide the "confirm/cancel" dialog...  on start route or continue route...
        case RECEIVE_DISCONNECT :
            return session.set( SESSION_KEY , "" ); // clear the driver id...
        case SET_STOP_ACTIVE :
            return session.set( CURRENT_STOP_KEY , action.stopKey ); // set the active stop...
        case START_ROUTE :
        case CONTINUE_ROUTE :
        default :
            //console.warn( "default ~ action.type == " + JSON.stringify( action.type ) );
            return session;
    }
};

export default session;

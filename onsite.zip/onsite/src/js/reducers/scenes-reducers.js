/* scenes-reducers.js */

import { ActionConst } from 'react-native-router-flux';

const scenes = function( scene , action ) : Object {
    switch ( action.type ) {
        case ActionConst.FOCUS :
            return action.scene;

        default :
            return scene;
    }
};

export default scenes;

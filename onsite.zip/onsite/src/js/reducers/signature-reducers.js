/* signature-reducers.js */

import Immutable from 'immutable';

import {
    STORE_SIGNATURES ,
    CLEAR_SIGNATURES ,
} from './../actions/actions';
import { RESPONSE_SIGNATURE_ENABLED } from './../config/constants';

var storeManager = require( './../bridges/StoreManager.js' );

const signatures = function( signature : Immutable.Map<string , any> , action : Object ) : Immutable.Map<string , any> {
    var newSignature;
    var driverId = action.driverId;
    var stopId = action.stopId;
    switch ( action.type ) {
        case STORE_SIGNATURES :
            // update the salesforce soups...
            if ( RESPONSE_SIGNATURE_ENABLED ) {
                console.warn( "PMCC DBG ~ STORE_SIGNATURES ~ action == " + JSON.stringify( action ) );
                //console.warn( "PMCC DBG ~ STORE_SIGNATURES ~ action.question == " + JSON.stringify( action.question ) );
                //console.warn( "PMCC DBG ~ STORE_SIGNATURES ~ action.signature == " + JSON.stringify( action.signature ) );
                // upsert a ContentVersion record for the new picture...
                if ( false ) {
                    storeManager.storeResponseForChecklistQuestion(
                        action.checklistInstanceId ,
                        action.question.get( "Id" ) ,
                        action.choice ,
                    );
                }
                storeManager.storeResponseWithContentVersion(
                    action.question ,
                    action.signature.pathOnClient ,
                    action.signature.versionData ,
                    action.choice ,
                    ( row ) => {
                        console.log( "PMCC DBG ~ .storeResponseWithContentVersion.SUCCESS ~ row == " + JSON.stringify( row ) );
                    } ,
                    ( error ) => {
                        console.log( "PMCC DBG ~ .storeResponseWithContentVersion.ERROR ~ error == " + JSON.stringify( error ) );
                    }
                );
            }
            // update the app signature state data..
            var newSignature = Immutable.Map( { driverSignature : null , customerSignature : null } );
            if ( signature.hasIn( [ driverId , stopId ] ) ) {
                newSignature = signature.getIn( [ driverId , stopId ] );
            }
            if ( action.choice && action.signature ) {
                if ( action.choice == "Driver" ) {
                    newSignature = newSignature.setIn( [ "driverSignature" ] , action.signature );
                } else if ( action.choice == "Customer" ) {
                    newSignature = newSignature.setIn( [ "customerSignature" ] , action.signature );
                }
            }
            return signature.setIn( [ driverId , stopId ] , newSignature );

        case CLEAR_SIGNATURES :
            return signature.setIn( [ driverId , stopId , "driverSignature" ] , null ).setIn( [ driverId , stopId , "customerSignature" ] , null );

        default :
            return signature;
    }
};

export default signatures;
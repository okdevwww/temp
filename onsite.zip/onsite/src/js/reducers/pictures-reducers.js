/* pictures-reducers.js */

import Immutable from 'immutable';
import {
    ADD_PICTURE_ENABLED ,
    RESPONSE_IMAGE_ENABLED ,
} from './../config/constants.js';
import {
    ADD_PICTURE ,
    END_ROUTE ,
    DELETE_PICTURE ,
    RECEIVE_CONNECT ,
    RECONNECT_ROUTE ,
} from './../actions/actions';

var storeManager = require( './../bridges/StoreManager.js' );

const pictures = function( pictures : Immutable.Map<string , any> , action : Object ) : Immutable.Map<string , any> {
    var newPictures = pictures;
    var section;
    var sectionAnswer;
    switch ( action.type ) {
        case ADD_PICTURE:
            if ( RESPONSE_IMAGE_ENABLED ) {
                // upsert a ContentVersion record for the new picture...
                storeManager.storeResponseWithContentVersion(
                    action.question ,
                    action.picture.pathOnClient ,
                    action.picture.versionData ,
                    "ImageAttached" ,
                    ( row ) => {
                        console.log( "PMCC DBG ~ .addResponseWithContentVersion.SUCCESS ~ row == " + JSON.stringify( row ) );
                    } ,
                    ( error ) => {
                        console.log( "PMCC DBG ~ .addResponseWithContentVersion.ERROR ~ error == " + JSON.stringify( error ) );
                    }
                );
            }
            var questionId = action.question.get( "Name" ) + "-" + action.stopId;
            if ( pictures.hasIn( [ action.stopId , action.process ] ) ) {
                section = pictures.getIn( [ action.stopId , action.process ] );
                if ( Immutable.List.isList( section ) ) {
                    var index = section.findIndex( function( answer ) {
                        return answer.hasIn( [ questionId ] );
                    } );
                    index = ( ( index != undefined ) && ( index > -1 ) ) ? index : section.size;
                    sectionAnswer = Immutable.Map().set( questionId , action.picture );
                    if ( ADD_PICTURE_ENABLED ) {
                        section = section.push( sectionAnswer ); // PMCC DBG ~ this line causes the tab to close when another photo is saved...
                    }
                }
            } else {
                section = Immutable.List();
                sectionAnswer = Immutable.Map().set( questionId , action.picture );
                if ( ADD_PICTURE_ENABLED ) {
                    section = section.set( 0 , sectionAnswer ); // PMCC DBG ~ this line causes the tab to close when the first photo is saved...
                }
            }
            newPictures = pictures.setIn( [ action.stopId , action.process ] , section );
            return newPictures;


        case DELETE_PICTURE:
            if ( pictures.hasIn( [ action.stopId , action.process ] ) ) {
                section = pictures.getIn( [ action.stopId , action.process ] );
                if ( Immutable.List.isList( section ) ) {
                    var pIndex = -1;
                    section.map(
                        ( question , index ) => {
                            if ( ( question.getIn( [ action.questionId ] ) !== undefined ) && ( question.getIn( [ action.questionId ] ) === action.picture ) ) {
                                pIndex = index;
                            }
                        }
                    );
                    section = section.delete( pIndex );
                }
            }
            newPictures = pictures.setIn( [ action.stopId , action.process ] , section );
            return newPictures;

        case END_ROUTE : // clear all pictures on end route confirmation...
        case RECEIVE_CONNECT : // clear all pictures on reconnection to the route screen...
        case RECONNECT_ROUTE : // clear all pictures on re-load of the app...
            //console.warn( "FLUSH ~ pictures == " + JSON.stringify( pictures ) );
            return Immutable.fromJS( { } );

        default :
            return pictures;
    }
};

export default pictures;

/* reducer.js */

import appInitialState from './../app-state/app-initial-state';
import modals from './modal-reducers';
import notification from './notification-reducers';
import pictures from './pictures-reducers';
import scenes from './scenes-reducers';
import session from './session-reducers';
import stops from './stops-reducers';
import signatures from './signature-reducers';

export default function reducer( state : Object = appInitialState , action : Object ) : Object {
    var items = state.stops.getIn( [ action.stopId , "Delivery" ] );
    return {
        scene : scenes( state.scene , action ) ,
        session : session( state.session , action ) ,
        pictures : pictures( state.pictures , action ) ,
        signature : signatures( state.signature, action ) ,
        stops : stops( state.stops , action ) ,
        buttons : state.buttons ,
        notification : notification( state.notification , action ) ,
        modal : modals( state.modal , action ) ,
    };
}
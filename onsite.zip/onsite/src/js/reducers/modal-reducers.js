/* modal-reducers.js */

import {
    CLOSE_MODAL ,
    OPEN_MODAL ,
} from './../actions/actions';

const modals = function( modal : Object , action : Object ) : Object {
    switch ( action.type ) {
        case CLOSE_MODAL :
            return modal.set( "modalType" , "" ).set( "modalProps" , {} );
        case OPEN_MODAL :
            return modal.set( "modalType" , action.modalType ).set( "modalProps" , action.modalProps );
        default :
            return modal;
    }
};

export default modals;

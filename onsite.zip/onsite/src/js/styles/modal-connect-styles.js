/* modal-connect-styles.js */

import { StyleSheet } from 'react-native';

const ModalStyles = StyleSheet.create(
    {
        modalConnect : {
            alignItems : "stretch" ,
            backgroundColor : "#FFFFFF" ,
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            marginBottom : 4 ,
            marginLeft : 20 ,
            marginRight : 20 ,
            marginTop : 4 ,
            paddingBottom : 16 ,
            paddingLeft : 32 ,
            paddingRight : 32 ,
            paddingTop : 0 ,
            zIndex : 1 ,
        } ,
        modalConnectAlt : {
            alignItems : "stretch" ,
            backgroundColor : "#FFFFFF" ,
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            marginBottom : 16 ,
            marginLeft : 16 ,
            marginRight : 16 ,
            marginTop : 16 ,
            paddingBottom : 32 ,
            paddingLeft : 32 ,
            paddingRight : 32 ,
            paddingTop : 32 ,
            zIndex : 1 ,
        } ,
        body : {
        } ,
        buttonContainer : {
            flexDirection : "column" ,
            justifyContent : "flex-end" ,
        } ,
        pictureContainer : {
            alignItems : "center" ,
            justifyContent : "center" ,
            padding : 8 ,
        } ,
        appLogo : {
            height : 56 ,
            width : 56 ,
        } ,
        formContainer : {
            alignItems : "stretch" ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            paddingLeft : 28 ,
            paddingRight : 28 ,
        } ,
        formFields : {
            alignItems : "stretch" ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
        } ,
        formCaption : {
            fontSize : 16 ,
            fontWeight : "bold" ,
            lineHeight : 18 ,
            paddingLeft : 4 ,
        } ,
        formCaptionAlt : {
            fontSize : 24 ,
            fontWeight : "bold" ,
            lineHeight : 28 ,
            paddingBottom : 0 ,
            paddingLeft : 4 ,
            paddingRight : 4 ,
            paddingTop : 0 ,
        } ,
        textInput : {
            fontSize : 16 ,
            height : 48 ,
            lineHeight : 20 ,
        } ,
        textInputAlt : {
            fontSize : 28 ,
            lineHeight : 32 ,
            paddingBottom : 0 ,
            paddingLeft : 4 ,
            paddingRight : 4 ,
            paddingTop : 0 ,
        } ,
        notif : {
        } ,
    }
);

export default ModalStyles;

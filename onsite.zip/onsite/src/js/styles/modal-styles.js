/* @flow */

import { StyleSheet } from 'react-native';

const ModalStyles = StyleSheet.create(
    {
        button : {
            flex : 1 ,
            justifyContent : "flex-end" ,
        } ,
        choicesContainer : {
            flexDirection : "column" ,
            margin : 0 ,
            padding : 0 ,
        } ,
        spacer : {
            height : 12 ,
        } ,
        buttonContainer : {
            flexDirection : "row" ,
            justifyContent : "center" ,
            margin : 0 ,
            padding : 0 ,
        } ,
        modal : {
            alignItems : "stretch" ,
            backgroundColor : "#FFFFFF" ,
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            marginBottom : 20 ,
            marginLeft : 20 ,
            marginRight : 20 ,
            marginTop : 20 ,
            paddingBottom : 20 ,
            paddingLeft : 20 ,
            paddingRight : 20 ,
            paddingTop : 20 ,
            zIndex : 1 ,
        } ,
        modalAlt : {
            alignItems : "stretch" ,
            backgroundColor : "#FFFFFF" ,
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            marginBottom : 16 ,
            marginLeft : 16 ,
            marginRight : 16 ,
            marginTop : 16 ,
            paddingBottom : 32 ,
            paddingLeft : 32 ,
            paddingRight : 32 ,
            paddingTop : 32 ,
            zIndex : 1 ,
        } ,

        titleView : {
        } ,
        titleViewAlt : {
            paddingBottom : 0 ,
            paddingLeft : 8 ,
            paddingRight : 8 ,
            paddingTop : 0 ,
        } ,
        titleFont : {
            fontSize : 18 ,
            fontWeight : "bold" ,
            lineHeight : 22 ,
        } ,
        titleFontAlt : {
            fontSize : 24 ,
            fontWeight : "bold" ,
            lineHeight : 28 ,
        } ,

        textView : {
            marginBottom : 0 ,
            marginTop : 8 ,
        } ,
        textViewAlt : {
            marginBottom : 0 ,
            marginTop : 8 ,
            paddingBottom : 0 ,
            paddingLeft : 8 ,
            paddingRight : 8 ,
            paddingTop : 0 ,
        } ,
        textFont : {
            fontSize : 16 ,
            lineHeight : 20 ,
        } ,
        textFontAlt : {
            fontSize : 24 ,
            lineHeight : 28 ,
        } ,

    page: {
        alignItems: 'center',
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center'
    },
    overlay: {
        backgroundColor: 'rgba(0, 0, 0, 0.4)',
        flex: 1,
        zIndex: 0,
        position: 'absolute',
        top: 0,
        bottom: 0,
        left: 0,
        right: 0
    },
    content: {
        marginTop: 15
    },
    itemName: {
        color: '#000000'
    },
    itemSku: {
        color: '#555555'
    },

        textHeight : {
            fontSize : 16 ,
            lineHeight : 20 ,
        } ,
        textView : {
            margin : 0 ,
            paddingBottom : 0 ,
            paddingLeft : 4 ,
            paddingRight : 4 ,
            paddingTop : 0 ,
        } ,
        title : {
            flexWrap : "wrap" ,
            fontSize : 16 ,
            fontWeight : "bold" ,
        } ,
        radioButtonContainer : {
        } ,
        radioGroup : {
            flex : 1 ,
            flexDirection : "row" ,
            margin : 0 ,
            padding : 0 ,
        } ,
        scrollContainer : {
            backgroundColor : "white" ,
        } ,
        scrollView : {
            backgroundColor : "#EBEBEB" ,
            margin : 0 ,
            padding : 2 ,
            height : 256 ,
        } ,
        scrollViewInner : {
            backgroundColor : "white" ,
            margin : 0 ,
            padding : 0 ,
            height : 252 ,
        } ,
    }
);

export default ModalStyles;

/* header-styles.js */

import { StyleSheet } from 'react-native';

const HeaderStyles = StyleSheet.create(
    {
        header : {
            backgroundColor : "#404040" ,
            flexDirection : "row" ,
            height : 63 ,
        } ,
        headerText : {
            color : "#FFFFFF" ,
            fontSize : 16 ,
        } ,
        logo : {
            marginLeft : 8 ,
        } ,
        buttonView : {
            margin : 0 ,
            padding : 8 ,
        } ,
        app : {
            alignItems : "flex-end" ,
            flexDirection : "row" ,
            justifyContent : "flex-start" ,
            paddingBottom : 8 ,
            paddingLeft : 4 ,
        } ,
    } ,
);

export default HeaderStyles;

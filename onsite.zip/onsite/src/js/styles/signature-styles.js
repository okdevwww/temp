/* signature-styles.js */

import { StyleSheet } from 'react-native';

const SignatureStyles = StyleSheet.create(
    {
        container : {
            flexDirection : "column" ,
            margin : 0 ,
            padding : 0 ,
        } ,
        signaturesContainer : {
            flexDirection : "row" ,
            height : 400 ,
            margin : 0 ,
            padding : 0 ,
        } ,
        captureContainer : {
            flexDirection : "column" ,
        } ,
        spacer : {
            padding : 8 ,
        } ,

        titleView : {
            backgroundColor : "#404040" ,
            padding : 4 ,
        } ,
        titleText : {
            color : "#FFFFFF" ,
            fontSize : 20 ,
            fontWeight : "bold" ,
            lineHeight : 24 ,
            textAlign : "center" ,
        } ,

        buttonsContainer : {
            flexDirection : "row" ,
            justifyContent : "space-between" ,
            margin : 0 ,
            padding : 0 ,
        } ,
        signatureTitle : {
            fontWeight : "bold" ,
            textAlign : "center" ,
        } ,
        signatureCapture : {
            width : 156 ,
            height : 368 ,
            padding : 1 ,
            borderWidth : 1 ,
            borderColor : "#999999" ,
        } ,
        signatureImage : {
            width : 156 ,
            height : 360 ,
            borderWidth : 1 ,
            borderColor : "#999999" ,
        } ,
    }
);

export default SignatureStyles;

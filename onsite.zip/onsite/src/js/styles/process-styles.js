/* process-styles.js */

import { StyleSheet } from 'react-native';

const ProcessStyles = StyleSheet.create(
    {
        container : {
            alignItems : "stretch" ,
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            margin : 8 ,
            padding : 8 ,
        } ,
        spacer_Key_Release : {
            padding : 1 ,
        } ,
        spacer_Truck_Inspection : {
            padding : 2 ,
        } ,
        spacer_Property_Inspection : {
            padding : 3 ,
        } ,
        spacer_Unit_Inspection : {
            padding : 4 ,
        } ,
        spacer_Delivery_Setup : {
            padding : 0 ,
        } ,
        spacer_Checklist : {
            padding : 0 ,
        } ,
        spacer_Signature : {
            padding : 0 ,
        } ,
        spacer_Key_Return : {
            padding : 0 ,
        } ,
    } ,
);

export default ProcessStyles;

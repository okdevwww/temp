/* footer-styles.js */

import { StyleSheet } from 'react-native';

const FooterStyles = StyleSheet.create(
    {
        container : {
            backgroundColor : "#BEBEBE" ,
            flexDirection : "row" ,
            height : 52 ,
            justifyContent : "space-around" ,
            paddingBottom : 4 ,
            paddingTop : 4 ,
        } ,
        buttonActive : {
            backgroundColor : "#EBEBEB" ,
            borderColor : "#F8F8F8" ,
            borderRadius : 2 ,
            borderWidth : 2 ,
        } ,
        buttonContainer : {
            width : 88 ,
        } ,
        button : {
            alignItems : "center" ,
            flexDirection : "column" ,
            justifyContent : "center" ,
            margin : 0 ,
            padding : 0 ,
        } ,
        buttonIcon : {
            color : "#444444" ,
            opacity : 0.64 ,
        } ,
        buttonText : {
            color : "#000000" ,
            lineHeight : 12 ,
            fontSize : 12 ,
            opacity : 0.64 ,
            paddingTop : 1 ,
        } ,
    } ,
);

export default FooterStyles;

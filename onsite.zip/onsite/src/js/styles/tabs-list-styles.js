/* tabs-list-styles.js */

import { StyleSheet } from 'react-native';

const tabsListStyles = StyleSheet.create(
    {
        container : {
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            backgroundColor : "#EBEBEB" ,
        } ,
        scrollContainer : {
            marginTop : 8 ,
        } ,
    } ,
);

export default tabsListStyles;

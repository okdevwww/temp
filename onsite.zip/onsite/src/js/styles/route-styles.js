/* route-styles.js */

import { StyleSheet } from 'react-native';

const RouteStyles = StyleSheet.create(
    {
        container : {
            backgroundColor : "#EBEBEB" ,
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            margin : 0 ,
            paddingTop : 8 ,
        } ,
        menuContainer : {
            backgroundColor : "#EBEBEB" ,
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "center" ,
            margin : 0 ,
            padding : 0 ,
        } ,
        scrollContainer : {
        } ,
        buttonContainer : {
            margin : 0 ,
            padding : 0 ,
        } ,
        spacer : {
            height : 44 ,
        } ,
    } ,
);

export default RouteStyles;

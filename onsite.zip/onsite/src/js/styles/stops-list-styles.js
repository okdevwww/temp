/* @flow */

import { StyleSheet } from 'react-native';

const stopsListStyles = StyleSheet.create(
    {
        container : {
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            paddingTop : 8 ,
        } ,
        scrollContainer : {} ,
        statusComplete: {
            backgroundColor : "#C7D1D6" ,
        } ,
        statusIncomplete: {
        } ,
        stopCard : {
            marginBottom : 8 ,
            marginLeft : 8 ,
            marginRight : 8 ,
            marginTop : 0 ,
            paddingBottom : 0 ,
            paddingLeft : 0 ,
            paddingRight : 0 ,
            paddingTop : 0 ,
        },
        stopContainer : {
        } ,
        containerBordered : {
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            borderLeftWidth : 6 ,
            borderTopWidth : 0 ,
            borderRightWidth : 0 ,
            borderBottomWidth : 0 ,
            padding : 10 ,
            margin : 0 ,
        } ,
        typeComplete : {
            borderColor : "#607D8D" ,
        } ,
        typeCompleteBg : {
            backgroundColor : "#607D8D" ,
        } ,

    typeEMPTY: {
        borderColor: '#000000'
    },
    typeRepair : {
        borderColor : "#800000" ,
    } ,
    typeRepo : {
        borderColor : "#888888" ,
    } ,
    typeDelivery: {
        borderColor: '#6ece0a'
    },
    typeNewDelivery: {
        borderColor: '#6ece0a'
    },
    typePickup: {
        borderColor: '#3e8dd2'
    },
    typeExchange: {
        borderColor: '#ffc000'
    },
    typePartialPickup: {
        borderColor: '#f04ab8'
    },
    typeAddOn: {
        borderColor: '#f05627'
    },
    typeAddons: {
        borderColor: '#f05627'
    },
    typeMove: {
        borderColor: '#a833e3'
    },
    stopBody : {
        alignItems : "flex-start" ,
        flexDirection : "row" ,
        justifyContent : "flex-start" ,
    } ,
    stopIconContainer: {
        flex: 0,
        alignItems: 'center',
        borderRadius: 40,
        flexDirection: 'column',
        justifyContent: 'center',
        height: 40,
        width: 40
    },
    typeEMPTYBg: {
        backgroundColor: '#000000'
    },
    typeRepairBg : {
	    backgroundColor : "#800000" ,
    } ,
    typeRepoBg : {
        backgroundColor : "#888888" ,
    } ,
    typeDeliveryBg: {
        backgroundColor: '#6ece0a'
    },
    typeNewDeliveryBg: {
        backgroundColor: '#6ece0a'
    },
    typePickupBg: {
        backgroundColor: '#3e8dd2'
    },
    typeExchangeBg: {
        backgroundColor: '#ffc000'
    },
    typePartialPickupBg: {
        backgroundColor: '#f04ab8'
    },
    typeAddOnBg: {
        backgroundColor: '#f05627'
    },
    typeAddonsBg: {
        backgroundColor: '#f05627'
    },
    typeMoveBg: {
        backgroundColor: '#a833e3'
    },
    stopIcon: {
        color: '#ffffff',
        fontWeight: 'bold'
    },
    stopDetails : {
        flex : 1 ,
        alignItems : "flex-start" ,
        flexDirection : "column" ,
        justifyContent : "flex-start" ,
        marginLeft : 10 ,
    } ,
    stopName : {
        flex : 1 ,
        alignItems : "flex-start" ,
        flexDirection : "column" ,
        flexWrap : "wrap" ,
        justifyContent : "flex-start" ,
        marginBottom : 15 ,
    } ,
    stopType : {
        flex : 1 ,
        alignItems : "flex-start" ,
        flexDirection : "column" ,
        justifyContent : "flex-start" ,
    } ,
    stopText: {
        fontSize: 13
    },
    stopDetailContentNoIcon: {
        marginLeft: 30
    },
	stopDetailContentText: {
		alignItems: 'flex-start',
		flexDirection: 'column',
		justifyContent: 'flex-start',
		flexWrap: 'wrap',
		flex: 1
	},

        stopDetail : {
            alignItems : "flex-start" ,
            flex : 1 ,
            flexDirection : "row" ,
            justifyContent : "flex-start" ,
            marginBottom : 12 ,
            padding : 4 ,
        } ,
        stopDetailContent : {
            alignItems : "flex-start" ,
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            marginLeft : 10 ,
        } ,
        stopCustomerName : {
            fontWeight : "bold" ,
            fontSize : 16 ,
            lineHeight : 18 ,
        } ,
        stopDetailIcon : {
            margin : 0 ,
            padding : 1 ,
        } ,
        stopDetailTitleComplete: {
            color : "#888888" ,
        } ,
        stopDetailTitle: {
            color : "#63C0b8" ,
        } ,
        stopDetailText : {
            fontSize : 13 ,
        } ,
        stopActions : {
            flexDirection : "row" ,
            justifyContent : "flex-end" ,
            marginBottom : 5 ,
        } ,
        stopActionsLess : {
            marginBottom : 0 ,
        } ,
    }
);

export default stopsListStyles;

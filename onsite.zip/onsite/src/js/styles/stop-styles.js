/* stop-styles.js */

import { StyleSheet } from 'react-native';

const stopStyles = StyleSheet.create(
    {
        container : {
            backgroundColor : "#EBEBEB" ,
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            margin : 0 ,
            padding : 0 ,
        } ,
        scrollContainer : {
            marginTop : 8 ,
        } ,
    } ,
);

export default stopStyles;

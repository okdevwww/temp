/* button-styles.js */

import { StyleSheet } from 'react-native';

// BASE

const defaultStyle = StyleSheet.create(
    {
        container : {
            alignItems : "center" ,
            borderRadius : 4 ,
            borderWidth : 1 ,
            justifyContent : "center" ,
            paddingVertical : 12 ,
        } ,
        font : {
            fontWeight : "bold" ,
        } ,
    }
);

// SIZE

const sizeExtraSmall = StyleSheet.create(
    {
        container : {
            width : 48 ,
        } ,
        font : {
            fontSize : 20 ,
            lineHeight : 24 ,
        } ,
    }
);
const sizeSmall = StyleSheet.create(
    {
        container : {
            width : 96 ,
        } ,
        font : {
            fontSize : 18 ,
            lineHeight : 22 ,
        } ,
    }
);
const sizeSmallFont = StyleSheet.create(
    {
        container : {
            width : 134 ,
        } ,
        font : {
            fontSize : 14 ,
            lineHeight : 16 ,
        } ,
    }
);
const sizeMedium = StyleSheet.create(
    {
        container : {
            width : 116 ,
        } ,
        font : {
            fontSize : 18 ,
            lineHeight : 22 ,
        } ,
    }
);
const sizeLarge = StyleSheet.create(
    {
        container : {
            width : 144 ,
        } ,
        font : {
            fontSize : 18 ,
            lineHeight : 22 ,
        } ,
    }
);

// to be exported...
const confirmationType = sizeLarge;
const cancelType = sizeLarge;
const headerType = sizeMedium;
const footerType = sizeSmallFont;
const modalType = sizeLarge;
const stopType = sizeLarge;
const signatureType = sizeSmall;

// COLOR

const transparent = StyleSheet.create(
    {
        text : {
            color : "transparent" ,
        } ,
        button : {
            backgroundColor : "transparent" ,
            borderColor : "transparent" ,
        } ,
    }
);

const lightTheme = StyleSheet.create(
    {
        text : {
            color : "#707070" ,
        } ,
        button : {
            backgroundColor : "#EBEBEB" ,
            borderColor : "#CCCCCC" ,
        } ,
    }
);

const pinkTheme = StyleSheet.create(
    {
        text : {
            color : "black" ,
        } ,
        button : {
            backgroundColor : "pink" ,
            borderColor : "pink" ,
        } ,
    }
);

const redTheme = StyleSheet.create(
    {
        text : {
            color : "#EEEEEE" ,
        } ,
        button : {
            backgroundColor : "#EE0034" ,
            borderColor : "#EE0034" ,
        } ,
    }
);

const greyTheme = StyleSheet.create(
    {
        text : {
            color : "#FFFFFF" ,
        } ,
        button : {
            backgroundColor : "#607D8D" ,
            borderColor : "#607D8D" ,
        } ,
    }
);

const whiteTheme = StyleSheet.create(
    {
        text : {
            color : "#EE0034" ,
        } ,
        button : {
            backgroundColor : "#FFFFFF" ,
            borderColor : "#EE0034" ,
        } ,
    }
);

export default {
    cancelType : cancelType ,
    confirmationType : confirmationType ,
    defaultStyle : defaultStyle ,
    headerType : headerType ,
    footerType : footerType ,
    modalType : modalType ,
    signatureType : signatureType ,
    stopType : stopType ,
    pinkTheme : pinkTheme ,
    redTheme : redTheme ,
    greyTheme : greyTheme ,
    lightTheme : lightTheme ,
    transparent : transparent ,
    whiteTheme : whiteTheme ,
};

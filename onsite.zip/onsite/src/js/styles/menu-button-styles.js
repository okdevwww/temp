/* @flow */

import { StyleSheet } from 'react-native';

const menuButtonStyles = StyleSheet.create(
    {
        menuButton : {
            margin : 8 ,
            paddingLeft : 0 ,
            paddingRight : 0 ,
        } ,
        menuButtonContainer : {
        } ,
        menuButtonEnabled : {
            backgroundColor : "white" ,
        } ,
        menuButtonDisabled : {
            backgroundColor : "#C7D1D6" ,
        } ,
        menuButtonBorder : {
            alignItems : "flex-start" ,
            borderBottomWidth : 0 ,
            borderLeftWidth : 6 ,
            borderRightWidth : 0 ,
            borderTopWidth : 0 ,
            flexDirection : "row" ,
            justifyContent : "flex-start" ,
            padding : 8 ,
            margin : 0 ,
        } ,
        nullBorderTheme : {
            borderColor : "#607D8B" ,
        } ,
        redBorderTheme : {
            borderColor : "#D8411C" ,
        } ,
        greenBorderTheme : {
            borderColor : "#77CC33" ,
        } ,
        blueBorderTheme : {
            borderColor : "#607D8B" ,
        } ,
        menuButtonIconContainer : {
            alignItems : "center" ,
            borderRadius : 48 ,
            flex : 0 ,
            flexDirection : "column" ,
            justifyContent : "center" ,
            height : 48 ,
            width : 48 ,
        } ,
        menuButtonIcon : {
            color : "white" ,
            fontWeight : "bold" ,
        } ,
        menuButtonTextContainer : {
            flex : 1 ,
            flexDirection : "column" ,
            marginLeft : 16 ,
            marginTop : 0 ,
        } ,
        menuButtonText : {
            fontSize : 22 ,
            fontWeight : "bold" ,
            lineHeight : 38 ,
        } ,
        icon : {
            color : "white" ,
        } ,
        nullTheme : {
        } ,
        redTheme : {
            backgroundColor : "#D8411C" ,
        } ,
        greenTheme : {
            backgroundColor : "#77CC33" ,
        } ,
        blueTheme : {
            backgroundColor : "#607D8B" ,
        } ,
    }
);

export default menuButtonStyles;

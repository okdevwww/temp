/* question-styles.js */

import { StyleSheet } from 'react-native';

const QuestionStyles = StyleSheet.create(
    {
        answers : {
            alignItems : "flex-start" ,
            flexDirection : "row" ,
            justifyContent : "flex-start" ,
            marginBottom : 8 ,
        } ,
        checkbox : {
            marginRight : 24 ,
        } ,
        checklistImage : {
            height : 40 ,
            width : 40 ,
        } ,
        imageContainer : {
            marginBottom : 24 ,
        } ,
        itemImage : {
            height : 80 ,
            width : 80 ,
        } ,
        images : {
            alignItems : "flex-start" ,
            flex : 1 ,
            flexDirection : "row" ,
            flexWrap : "wrap" ,
            justifyContent : "flex-start" ,
            marginBottom : 8 ,
        } ,
        questionText : {
            alignItems : "flex-start" ,
            justifyContent : "flex-start" ,
            flex : 1 ,
            flexDirection : "column" ,
            flexWrap : "wrap" ,
            paddingRight: 4,
            marginBottom : 8 ,
        } ,
    } ,
);

export default QuestionStyles;

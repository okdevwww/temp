/* sub-header-styles.js */

import { StyleSheet } from 'react-native';

const SubHeaderStyles = StyleSheet.create(
    {
        container : {
            alignItems : "flex-end" ,
            backgroundColor : "#EBEBEB" ,
            flexDirection : "row" ,
            justifyContent : "flex-start" ,
            height : 36 ,
            paddingLeft : 16 ,
        } ,
        text : {
            color : "#333333" ,
            fontSize : 16 ,
            lineHeight : 24 ,
            fontWeight : "bold" ,
        } ,
    } ,
);

export default SubHeaderStyles;

/* process-cotent-styles.js */

import { StyleSheet } from 'react-native';

const ProcessContentStyles = StyleSheet.create(
    {
        container : {
            alignItems : "stretch" ,
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            marginBottom : 8 ,
            marginLeft : 24 ,
            marginRight : 24 ,
            marginTop : 0 ,
        } ,
        card : {
            alignItems : "center" ,
            flexDirection : "row" ,
            justifyContent : "space-between" ,
            height : 66 ,
            marginBottom : 10 ,
            marginLeft : 8 ,
            marginRight : 8 ,
            marginTop : 0 ,
        } ,
        cardEditing : {
            backgroundColor : "#C7d1D6" ,
        } ,
        left : {
            flexDirection : "row" ,
            justifyContent : "flex-start" ,
        } ,
        iconContainer : {
            alignItems : "center" ,
            backgroundColor : "#63C0b8" ,
            borderColor : "#CC0000" ,
            borderRadius : 40 ,
            justifyContent : "center" ,
            height : 40 ,
            width : 40 ,
        } ,
        icon : {
            color : "#FFFFFF" ,
        } ,
        captionContainer : {
            alignItems : "center" ,
            flexDirection : "row" ,
            justifyContent : "flex-start" ,
            marginLeft : 12 ,
        } ,
        caption : {
            color : "#000000" ,
            fontSize : 20 ,
            fontWeight : "bold" ,
            lineHeight : 24 ,
            opacity : 0.59 ,
        } ,
        right : {
            flexDirection : "row" ,
            justifyContent : "flex-end" ,
        } ,
        iconEditContainer : {
            alignSelf : "flex-end" ,
        } ,
    } ,
);

export default ProcessContentStyles;

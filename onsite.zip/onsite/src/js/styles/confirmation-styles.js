/* confirmation-styles.js */

import { StyleSheet } from 'react-native';

const confirmationStyles = StyleSheet.create(
    {
        overlayView : {
            backgroundColor : "grey" ,
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            margin : 0 ,
            padding : 16 ,
        } ,
        confirmationView : {
            backgroundColor : "white" ,
            flex : 1 ,
            flexDirection : "column" ,
            justifyContent : "flex-start" ,
            margin : 0 ,
            padding : 32 ,
        } ,
        logoView : {
            alignItems : "center" ,
            justifyContent : "center" ,
            margin : 0 ,
            padding : 8 ,
        } ,
        logoImage : {
            height : 80 ,
            width : 80 ,
            margin : 0 ,
            padding : 0 ,
        } ,
        notificationView : {
            margin : 0 ,
            padding : 0 ,
        } ,
        choiceView : {
            flexDirection : "column" ,
            margin : 0 ,
            padding : 0 ,
        } ,
        buttonView : {
            flexDirection : "row" ,
            justifyContent : "center" ,
            margin : 0 ,
            padding : 0 ,
        } ,
        spacer : {
            height : 12 ,
        } ,
        titleView : {
        } ,
        titleText : {
            fontSize : 18 ,
            fontWeight : "bold" ,
            lineHeight : 22 ,
        } ,
        messageView : {
        } ,
        messageText : {
            fontSize : 16 ,
            lineHeight : 22 ,
        } ,
    } ,
);

export default confirmationStyles;

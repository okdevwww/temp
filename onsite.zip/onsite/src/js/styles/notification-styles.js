/* notification-styles.js */

import { StyleSheet } from 'react-native';

const notificationStyles = StyleSheet.create(
    {
        container : {
            alignItems : "flex-start" ,
            flexDirection : "row" ,
            justifyContent : "space-between" ,
            height : 24 ,
            paddingLeft : 32 ,
            paddingRight : 32 ,
        } ,
        text : {
            color : "#FF0000" ,
        } ,
        icon : {
            color : "#FF0000" ,
        } ,
    }
);

export default notificationStyles;

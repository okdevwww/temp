var express = require('express');
var router = express.Router();

var data = require('./items-data');

router.get('/', function(req, res) {
    res.status(200);
    res.json(data);
});

module.exports = router;

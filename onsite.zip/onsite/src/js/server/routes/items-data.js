
var data = {
    odata: {
        metadata: "http://10.131.190.55/OnsiteDataDev/OnsiteDataService.svc/$metadata#Collection(OnsiteWebservices.GetItemsbyDriver_Result)"
    },
    value: [
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "1115741",
            Barcode_id: "1004295443",
            DESCR50: "TABLE LAMP STEEL AND WHITE 27H",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "3035303",
            Barcode_id: "1007516563",
            DESCR50: "HEADBOARD BLACK KING",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "3324568",
            Barcode_id: "1006888647",
            DESCR50: "KING UNIVERSAL BOXSPRING",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "3004655",
            Barcode_id: "1007557838",
            DESCR50: "DRESSER GREY",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "3014603",
            Barcode_id: "1006770201",
            DESCR50: "MIRROR GREY",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "2014754",
            Barcode_id: "1005292168",
            DESCR50: "END TABLE GLASS ON GLASS",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "1115741",
            Barcode_id: "1004295467",
            DESCR50: "TABLE LAMP STEEL AND WHITE 27H",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "1006547",
            Barcode_id: "1005240625",
            DESCR50: "SOFA BLACK 85W",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "3324568",
            Barcode_id: "1006993593",
            DESCR50: "KING UNIVERSAL BOXSPRING",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "2004782",
            Barcode_id: "1005309174",
            DESCR50: "COCKTAIL TABLE GLASS ON GLASS SQUARE",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "4034590",
            Barcode_id: "1006618175",
            DESCR50: "DINING CHAIR",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "4025073",
            Barcode_id: "1006266216",
            DESCR50: "DINING TABLE SQUARE GLASS ON GLASS",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "3316016",
            Barcode_id: "1007059132",
            DESCR50: "4 LEG TWIN/FULL/QU",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "4034590",
            Barcode_id: "1006183519",
            DESCR50: "DINING CHAIR",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "4034590",
            Barcode_id: "1007395987",
            DESCR50: "DINING CHAIR",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "3024708",
            Barcode_id: "1007077273",
            DESCR50: "NIGHTSTAND GREY",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "3334810",
            Barcode_id: "1007111193",
            DESCR50: "KING MATTRESS",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "3024708",
            Barcode_id: "1006262472",
            DESCR50: "NIGHTSTAND GREY",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "1115785",
            Barcode_id: "1006779529",
            DESCR50: "TABLE LAMP SILVER GLASS AND METAL 25H",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "4034590",
            Barcode_id: "1005822242",
            DESCR50: "DINING CHAIR",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "3",
            r_lease_id: "925728",
            transaction_id: "1",
            type: "Delivery",
            sku_id: "3316016",
            Barcode_id: "1007009310",
            DESCR50: "4 LEG TWIN/FULL/QU",
            ROOM_CD: " ",
            R_ROOM_DESCR: " "
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "3334806",
            Barcode_id: null,
            DESCR50: "TWIN MATTRESS",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "3034569",
            Barcode_id: null,
            DESCR50: "HEADBOARD BROWN TWIN",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "5002312",
            Barcode_id: null,
            DESCR50: "ESSENTIAL BATH PACKAGE",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "5002316",
            Barcode_id: null,
            DESCR50: "CLEANING PACKAGE W/ LAUNDRY BASKET",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "1504177",
            Barcode_id: null,
            DESCR50: "DVD COMPACT DISK PLAYER",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "1504250",
            Barcode_id: null,
            DESCR50: "42 LED 1080p - HDTV",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "3324564",
            Barcode_id: null,
            DESCR50: "TWIN BOXSPRING UNIVERSAL",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "5001116",
            Barcode_id: null,
            DESCR50: "IRON BD LARGE",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "3316016",
            Barcode_id: null,
            DESCR50: "4 LEG TWIN/FULL/QU",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "3324566",
            Barcode_id: null,
            DESCR50: "QUEEN UNIVERSAL BOXSPRING",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "3034579",
            Barcode_id: null,
            DESCR50: "HEADBOARD BROWN QUEEN",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "5002119",
            Barcode_id: null,
            DESCR50: "MATELASSE QUEEN SPREAD PACKAGE",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "3334792",
            Barcode_id: null,
            DESCR50: "QUEEN MATTRESS",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "5001111",
            Barcode_id: null,
            DESCR50: "IRON STEAM/DRY",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "4",
            r_lease_id: "882036",
            transaction_id: "3",
            type: "Pickup",
            sku_id: "5002117",
            Barcode_id: null,
            DESCR50: "MATELASSE TWIN (2) SPREAD PACKAGE",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "5",
            r_lease_id: "905864",
            transaction_id: "8",
            type: "Pickup",
            sku_id: "5501030",
            Barcode_id: null,
            DESCR50: "WASHER/DRYER 3RD PARTY",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "5",
            r_lease_id: "905864",
            transaction_id: "8",
            type: "Pickup",
            sku_id: "6604564",
            Barcode_id: null,
            DESCR50: "TRAINING TABLE TOP SILVER MESH 24X48",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "5",
            r_lease_id: "905864",
            transaction_id: "8",
            type: "Pickup",
            sku_id: "6604507",
            Barcode_id: null,
            DESCR50: "FOLDING TBL 30X72 GRAY GRANITE PLASTIC",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "5",
            r_lease_id: "905864",
            transaction_id: "8",
            type: "Pickup",
            sku_id: "6014307",
            Barcode_id: null,
            DESCR50: "JR EXEC DESK 60W TIGER FRUITWOOD",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        },
        {
            STOP_ID: "5",
            r_lease_id: "905864",
            transaction_id: "8",
            type: "Pickup",
            sku_id: "6604568",
            Barcode_id: null,
            DESCR50: "TRAINING TABLE T-LEG BASE CHARCOAL",
            ROOM_CD: "",
            R_ROOM_DESCR: ""
        }
    ]
};

module.exports = data;

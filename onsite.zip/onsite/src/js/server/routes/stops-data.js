
var data = {
    value: [
        {
            STOP_ID: "3",
            SHIPTO_NAME1: "Paul Magillicutty",
            SHIPTO_ADDRESS1: "1234 this st.",
            SHIPTO_ADDRESS2: "",
            SHIPTO_CITY: 'Austin',
            SHIPTO_STATE: 'TX',
            SHIPTO_ZIP: "78759",
            SHIPTO_PHONE_NBR: "(512) 888-8888",
            DELIVERY_QTY: "22",
            PICKUP_QTY: "21" //"Pieces"
        },
        {
            STOP_ID: "4",
            SHIPTO_NAME1: "Thomas Petty",
            SHIPTO_ADDRESS1: "2233 this st.",
            SHIPTO_ADDRESS2: "4455 this. st",
            SHIPTO_CITY: 'Austin',
            SHIPTO_STATE: 'TX',
            SHIPTO_ZIP: "85743",
            SHIPTO_PHONE_NBR: "(512) 888-9999",
            DELIVERY_QTY: "23",
            PICKUP_QTY: "42" //"Boxes"
        },
        {
            STOP_ID: "5",
            SHIPTO_NAME1: "Thomas Petty",
            SHIPTO_ADDRESS1: "5544 this st.",
            SHIPTO_ADDRESS2: "8877 this. st",
            SHIPTO_CITY: 'Austin',
            SHIPTO_STATE: 'TX',
            SHIPTO_ZIP: "90057",
            SHIPTO_PHONE_NBR: "(512) 888-0000",
            DELIVERY_QTY: "12",
            PICKUP_QTY: "10" //"Pieces"
        }
    ]
};

module.exports = data;

/* scenes.js */

import React from 'react';
import {
    Scene ,
    Actions ,
} from 'react-native-router-flux';

import RouteProvider from './../components/containers/route-provider';
import TabsProvider from './../components/containers/tabs-provider';
import {
    CHECKLIST_KEY ,
    ROUTE_KEY ,
} from './../config/constants';

VariableScenes = Actions.create(
    <Scene key="root" hideNavBar={ true } >
        <Scene key={ ROUTE_KEY } component={ RouteProvider } title={ "Stops" } initial={ true } />
        <Scene key={ CHECKLIST_KEY } component={ TabsProvider } title={ "Tabs" } panHandlers={ null } />
    </Scene>
);

// --- Create it via Actions.create(), or it will be re-created for each render of your Router
const Scenes = VariableScenes;

export default Scenes;

/* header.js */

import Immutable from 'immutable';
import React , { PropTypes } from 'react';
import {
    Image ,
    Text ,
    View ,
} from 'react-native';

import Button from './../../components/shared/button';
import config from './../../config/config';
import {
    CHECKLIST_KEY ,
    DRIVER_KEY ,
    LOCALE_ENABLED ,
    SESSION_KEY ,
    SF_LOGOUT_ENABLED ,
    ROUTE_KEY ,
} from './../../config/constants.js';
import hStyles from './../../styles/header-styles';

type HeaderPropTypes = {
    onLogoutPress : () => void;
};

type HeaderStateTypes = { };

class Header extends React.Component<any , HeaderPropTypes , HeaderStateTypes> {
    props : HeaderPropTypes;

    constructor( props : HeaderPropTypes ): void {
        super( props );
        this.handleLocalePress = this.handleLocalePress.bind( this );
    }

    componentDidMount() : void {
        if ( this.props.session.get( "locale" ) == undefined ) {
            this.props.onLocalePress( "en_US" );
        }
    }

    handleLocalePress() : void {
        var newLocale = "en_US";
        switch ( this.props.session.get( "locale" ) ) {
            case "en_US" :
                newLocale = "es_MX";
                break;
            case "es_MX" :
                newLocale = "keys";
                break;
            case "keys" :
                newLocale = "en_US";
                break;
            default :
                newLocale = "en_US";
                break;
        }
        this.props.onLocalePress( newLocale );
    }

    getLocaleButton() : void {
        if ( LOCALE_ENABLED ) {
            if ( ! this.props.session.get( "locale" ) ) {
                return null; // no button when locale is null...
            }
            return (
                <View style={ hStyles.buttonView } >
                    <Button
                        theme="red"
                        raised={ true }
                        onPress={ this.handleLocalePress }
                        text={ ( this.props.session.get( "locale" ) ? this.props.session.get( "locale" ) : "X" ) }
                        type="header"
                        />
                </View>
            );
        }
    }

    getLogoutButton() : void {
        if ( SF_LOGOUT_ENABLED ) {
            return (
                <View style={ hStyles.buttonView } >
                    <Button
                        theme="red"
                        raised={ true }
                        onPress={ this.props.onLogoutPress }
                        text="L"
                        type="header"
                        />
                </View>
            );
        }
    }

    render() : ? React.Element {
        return (
            <View style={ hStyles.header } >
                <View style={ hStyles.logo } >
                    <Image style={ hStyles.logoImage } source={ require( './logo.png' ) } />
                </View>
                <View style={ hStyles.app } >
                    <Text style={ hStyles.headerText } >{ config.appTitle }</Text>
                </View>
                { this.getLogoutButton() }
                { this.getLocaleButton() }
            </View>
        );
    }
}

Header.propTypes = {
    onLogoutPress : PropTypes.func.isRequired ,
};

export default Header;

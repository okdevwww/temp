/* tabs-list.js */

import Immutable from 'immutable';
import React , { PropTypes } from 'react';
import {
    Image ,
    RefreshControl ,
    ScrollView ,
    Text ,
    View ,
} from 'react-native';

import { locale } from '../../config/locale';
import ProcessContent from './../process/process-content';
import Button from './../shared/button';
import sStyles from './../../styles/stop-styles';
import cStyles from './../../styles/confirmation-styles';

type OnsiteStopPropTypes = {
    driverId : string;
    isConfirmationActive : boolean;
    onRefresh : ( driverId : string ) => void;
    confirmationClose : ( confirm : boolean , driverId : string ) => void;
    onProcessPressed : ( stopId : string , processId : string , active : boolean ) => void;
    scrollEnabled : boolean;
    setTabCompleted : ( stopId : string , id : string ) => void;
    setTabStarted : ( stopId : string , id : string ) => void;
    stopId : string;
    tabs : Immutable.Map<string , any>;
};

type OnsiteStopStateTypes = { };

class TabsList extends React.PureComponent<any , OnsiteStopPropTypes , OnsiteStopStateTypes> {
    props : OnsiteStopPropTypes;
    animating : boolean;
    height : number;
    scrollPos : ?number;
    handleScroll : ( e : Object ) => void;
    onContentSizeChange : ( w : number , h : number ) => void;
    handleConfirmationClose : ( confirm : string ) => void;

    constructor( props : OnsiteStopPropTypes ): void {
        super( props );
        this.animating = false;
        this.scrollPos = null;
        this.handleScroll = this.handleScroll.bind( this );
        this.onContentSizeChange = this.onContentSizeChange.bind( this );
        this.handleConfirmationClose = this.handleConfirmationClose.bind( this );
    }

    handleScroll( event : Object ): void {
        this.scrollPos = event.nativeEvent.contentOffset.y;
    }

    handleConfirmationClose( confirm : string ): void {
        //console.warn( "handleConfirmationClose" );
        this.props.confirmationClose( confirm == "confirmation" , this.props.driverId );
    }

    onContentSizeChange( width : number , height : number ): void {
        // figure out which process is the active process...
        var currentProcess = null;
        if ( this.props.tabs ) {
            currentProcess = this.props.tabs.map(
                ( process , index ) => {
                    if ( process.get( "active" ) ) {
                        return index;
                    }
                }
            ).toArray();
        }
        var newProcessIndex = -1;
        if ( currentProcess ) {
            for ( var processIndex = 0 ; processIndex < currentProcess.length ; processIndex++ ) {
                if ( currentProcess[ processIndex ] ) {
                    newProcessIndex = processIndex;
                }
            }
        }
        // check if signature process is active...
        var positionAdjustment = 36;
        if ( newProcessIndex == 6 ) {
            positionAdjustment = 76;
        }
        // when a process is selected...  scroll the current active process to the top...  each process is 76 pixels tall...
        if ( newProcessIndex >= 0 ) {
            this.refs.scrollView.scrollTo(
                {
                    x : 0 ,
                    y : ( ( 76 * newProcessIndex ) + positionAdjustment ) ,
                    animated : true ,
                }
            );
        }
    }

    render(): React.Element {
        if ( this.props.isConfirmationActive ) {
            // PMCC TODO ~ this should be a unique component...
            return (
                <View style={ cStyles.overlayView } >
                    <View style={ cStyles.confirmationView } >
                        <View style={ cStyles.logoView } >
                            <Image style={ cStyles.logoImage } source={ require( './app_logo.png' ) } />
                        </View>
                        <View style={ cStyles.spacer } />
                        <View style={ cStyles.titleView } >
                            <Text style={ cStyles.titleText } >Stop Completed?</Text>
                        </View>
                        <View style={ cStyles.spacer } />
                        <View style={ cStyles.messageView } >
                            <Text style={ cStyles.messageText } >Please confirm that the stop has been completed and the key has been returned.</Text>
                        </View>
                        <View style={ cStyles.spacer } />
                        <View style={ cStyles.spacer } />
                        <View style={ cStyles.choiceView } >
                            <View style={ cStyles.buttonView } >
                                <Button
                                    theme="red"
                                    raised={ true }
                                    text={ locale.en_US.LOC_CONFIRM }
                                    onPress={ this.handleConfirmationClose }
                                    type="confirmation"
                                    />
                            </View>
                            <View style={ cStyles.spacer } />
                            <View style={ cStyles.buttonView } >
                                <Button
                                    theme="grey"
                                    raised={ true }
                                    text={ locale.en_US.LOC_CANCEL }
                                    onPress={ this.handleConfirmationClose }
                                    type="cancel"
                                    />
                            </View>
                        </View>
                    </View>
                </View>
            );
        }
        var processList = [];
        if ( this.props.tabs ) {
            processList = this.props.tabs.map(
                ( process ) => {
                    return (
                        <ProcessContent
                            processId={ process.get( "id" ) }
                            process={ process }
                            stopId={ this.props.stopId }
                            onPress={ this.props.onProcessPressed }
                            setTabCompleted={ this.props.setTabCompleted }
                            setTabStarted={ this.props.setTabStarted }
                            key={ "process-content-" + process.get( "id" ) }
                            ref={ process.get( "id" ) }
                            />
                    );
                }
            ).toArray()
        }
        return (
            <View style={ sStyles.container } >
                <ScrollView
                    scrollEnabled={ this.props.scrollEnabled }
                    ref="scrollView"
                    refreshControl={
                        <RefreshControl
                            refreshing={ this.animating }
                            onRefresh={
                                () => {
                                    this.props.onRefresh( this.props.driverId );
                                }
                            }
                            tintColor="#000000"
                            title="Loading..."
                            titleColor="#00ff00"
                            colors={ [ "#ff0000" , "#00ff00" , "#0000ff" ] }
                            progressBackgroundColor="#ebebeb"
                            />
                    }
                    contentContainerStyle={ sStyles.scrollContainer }
                    onContentSizeChange={ this.onContentSizeChange }
                    onScroll={ this.handleScroll } >
                    { processList }
                </ScrollView>
            </View>
        );
    }
}

TabsList.propTypes = {
    driverId : PropTypes.string.isRequired ,
    isConfirmationActive : PropTypes.bool.isRequired ,
    confirmationClose : PropTypes.func.isRequired ,
    onProcessPressed : PropTypes.func.isRequired ,
    onRefresh : PropTypes.func.isRequired ,
    scrollEnabled : PropTypes.bool.isRequired ,
    setTabCompleted : PropTypes.func.isRequired ,
    setTabStarted : PropTypes.func.isRequired ,
    stopId : PropTypes.string.isRequired ,
    tabs : PropTypes.object.isRequired ,
};

export default TabsList;

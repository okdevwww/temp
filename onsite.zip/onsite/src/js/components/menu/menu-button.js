/* menu-button.js */

import Immutable from 'immutable';
import React , { PropTypes } from 'react';
import {
    Text ,
    TouchableNativeFeedback ,
    View ,
} from 'react-native';
import Communications from 'react-native-communications';
import { Card } from 'react-native-material-design';
import Icon from 'react-native-vector-icons/MaterialIcons';
//import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import { STOP_TYPES } from './../../config/constants';
import Button from './../shared/button';
import mbStyles from './../../styles/menu-button-styles';

type MenuButtonDefaultPropTypes = {
    enabled : boolean;
    iconName : string;
    text : string;
    theme : string;
};

type MenuButtonPropTypes = {
    enabled : boolean;
    iconName : string;
    onPress : () => void;
    text : string;
    theme : string;
};

type MenuButtonStateTypes = { };

class MenuButton extends React.PureComponent <MenuButtonDefaultPropTypes , MenuButtonPropTypes , MenuButtonStateTypes> {
    static defaultProps : MenuButtonDefaultPropTypes;
    props : MenuButtonPropTypes;
    state : MenuButtonStateTypes;

    constructor( props : MenuButtonPropTypes ) : void {
        super( props );
    }

    render() : ? React.Element {
        var statusStyle = mbStyles.menuButtonDisabled;
        if ( this.props.enabled ) {
            statusStyle = mbStyles.menuButtonEnabled;
        }
        var iconThemeName = "nullTheme";
        var borderThemeName = "nullBorderTheme";
        if ( mbStyles[ this.props.theme + "Theme" ] ) {
            iconThemeName = this.props.theme + "Theme";
            borderThemeName = this.props.theme + "BorderTheme";
        }
        if ( ! this.props.enabled ) {
            return null;
        }
        return (
            <Card style={ [ mbStyles.menuButton , statusStyle ] } >
                <TouchableNativeFeedback
                    disabled={ ! this.props.enabled  }
                    onPress={ this.props.onPress }
                    >
                    <View style={ [ mbStyles.menuButtonContainer , mbStyles.menuButtonBorder , mbStyles[ borderThemeName ] ] } >
                        <View style={ [ mbStyles.menuButtonIconContainer , mbStyles[ iconThemeName ] ] } >
                            <Icon name={ this.props.iconName } size={ 32 } color={ "white" } style={ mbStyles.icon } />
                        </View>
                        <View style={ mbStyles.menuButtonTextContainer } >
                            <Text style={ mbStyles.menuButtonText } >
                                { this.props.text }
                            </Text>
                        </View>
                    </View>
                </TouchableNativeFeedback>
            </Card>
        );
    }
}

MenuButton.propTypes = {
    enabled : PropTypes.bool ,
    iconName : PropTypes.string.isRequired ,
    onPress : React.PropTypes.func.isRequired ,
    text : PropTypes.string.isRequired ,
    theme : PropTypes.string.isRequired ,
};

MenuButton.defaultProps = {
    enabled : false ,
    iconName : "check" ,
    text : "" ,
    theme : "red" ,
};

export default MenuButton;

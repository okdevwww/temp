/* stop.js */

import Immutable from 'immutable';
import React , { PropTypes } from 'react';
import {
    Text ,
    TouchableNativeFeedback ,
    View ,
} from 'react-native';
import Communications from 'react-native-communications';
import { Card } from 'react-native-material-design';
import Icon from 'react-native-vector-icons/MaterialIcons';

import {
    COMPLETED_STOPS_KEY ,
    STOP_ICON_SIZE ,
    STOP_TYPES ,
} from './../../config/constants';
import { locale } from './../../config/locale';
import { getLocalizedString } from './../../reducers/session-reducers';
import Button from './../shared/button';
import slStyles from './../../styles/stops-list-styles';

type StopPropTypes = {
    iconNumber : string;
    onPress : ( stop : Immutable.OrderedMap<string , any> ) => void;
    session : Immutable.Map<string , any>;
    stop : Immutable.OrderedMap<string , any>;
};

class Stop extends React.PureComponent <any , StopPropTypes , void> {

    formatPhoneNumber( phoneNumber : string ) : string {
        var regexObj = /^(?:\+?1[-. ]?)?(?:\(?([0-9]{3})\)?[-. ]?)?([0-9]{3})[-. ]?([0-9]{4})$/;
        if ( regexObj.test( phoneNumber ) ) {
            var parts = phoneNumber.match( regexObj );
            var formattedPhoneNumber = "";
            if ( parts[ 1 ] ) {
                formattedPhoneNumber += "+1 (" + parts[ 1 ] + ") ";
            }
            formattedPhoneNumber += parts[ 2 ] + "-" + parts[ 3 ];
            return formattedPhoneNumber;
        }
        else {
            // invalid phone number
            return phoneNumber;
        }
    }

    isBreakStop() : boolean {
        var result = false;
        // nuke stops missing lease and transaction id values...
        if ( ! this.props.stop.get( "LEASE_ID" )
            && ! this.props.stop.get( "TRANSACTION_ID" )
            )
        {
            result = true;
        }
        // nuke stops with 2-digit customer id values...
        if ( this.props.stop.get( "CUSTOMER_ID" )
            && ( this.props.stop.get( "CUSTOMER_ID" ) > 0 )
            && ( this.props.stop.get( "CUSTOMER_ID" ) <= 999 )
            )
        {
            result = true;
        }
        return result;
    }

    getAddressBody() : React.Element {
        if ( this.isBreakStop() ) {
            return null;
        }
        var titleStyle = "stopDetailTitle";
        var completedStops = this.props.session.get( COMPLETED_STOPS_KEY );
        var stopKey = this.props.stop.get( "STOP_KEY" );
        if ( completedStops && ( completedStops.indexOf( stopKey ) >= 0 ) ) {
            titleStyle = titleStyle + "Complete";
        }
        return (
            <View style={ slStyles.stopDetail } >
                <Icon name="location-on" size={ STOP_ICON_SIZE } style={ slStyles.stopDetailIcon } />
                <View style={ slStyles.stopDetailContent } >
                    <Text style={ slStyles[ titleStyle ] } >Address</Text>
                    <Text style={ slStyles.stopDetailText } >{ this.props.stop.get( "CUSTOMER_ADDRESS" ) }</Text>
                    <Text style={ slStyles.stopDetailText } >{ this.props.stop.get( "CUSTOMER_CITY" ) }, { this.props.stop.get( "CUSTOMER_STATE" ) } { this.props.stop.get( "CUSTOMER_ZIP" ) }</Text>
                </View>
            </View>
        );
    }

    getPhoneBody() : React.Element {
        if ( this.isBreakStop() ) {
            return null;
        }
        var titleStyle = "stopDetailTitle";
        var completedStops = this.props.session.get( COMPLETED_STOPS_KEY );
        var stopKey = this.props.stop.get( "STOP_KEY" );
        if ( completedStops && ( completedStops.indexOf( stopKey ) >= 0 ) ) {
            titleStyle = titleStyle + "Complete";
        }
        var customerPhone = this.formatPhoneNumber( this.props.stop.get( "CUSTOMER_PHONE" ) );
        return(
            <TouchableNativeFeedback
                onPress={ () => Communications.phonecall( customerPhone , true ) }
                onLongPress={ () => Communications.text( customerPhone ) } >
                <View style={ slStyles.stopDetail } >
                    <Icon name="phone" size={ STOP_ICON_SIZE } style={slStyles.stopDetailIcon } />
                    <View style={ slStyles.stopDetailContent } >
                        <Text style={ slStyles[ titleStyle ] } >Contact Number</Text>
                        <Text style={ slStyles.stopDetailText } >{ customerPhone }</Text>
                    </View>
                </View>
            </TouchableNativeFeedback>
        );
    }

    getStopBody( stopType : string ) : React.Element {
        // all unknow transaction types style will default to the empty black circle and highlight style...
        var slType = stopType.replace( /\s/g , "" ).replace( /-/g , "" );
        var typeStyleBg = "typeEMPTYBg";
        if ( slStyles[ "type" + slType + "Bg" ] ) {
            typeStyleBg = "type" + slType + "Bg";
        }
        var completedStops = this.props.session.get( COMPLETED_STOPS_KEY );
        var stopKey = this.props.stop.get( "STOP_KEY" );
        if ( completedStops && ( completedStops.indexOf( stopKey ) >= 0 ) ) {
            typeStyleBg = "typeCompleteBg";
        }
        // build stop info details...
        var leaseId = "000000";
        if ( ( this.props.stop.has( "LEASE_ID" ) )
            && ( this.props.stop.get( "LEASE_ID" ) !== undefined )
            && ( this.props.stop.get( "LEASE_ID" ) !== null )
            && ( this.props.stop.get( "LEASE_ID" ) !== "" )
        )
        {
            leaseId = this.props.stop.get( "LEASE_ID" );
        }
        var transactionId = "0";
        if ( ( this.props.stop.has( "TRANSACTION_ID" ) )
            && ( this.props.stop.get( "TRANSACTION_ID" ) !== undefined )
            && ( this.props.stop.get( "TRANSACTION_ID" ) !== null )
            && ( this.props.stop.get( "TRANSACTION_ID" ) !== "" )
        )
        {
            transactionId = this.props.stop.get( "TRANSACTION_ID" );
        }
        var typeText = stopType + " - (" + leaseId + "-" + transactionId + ")";
        // build address body...
        var addressBody = null;
        if ( this.props.stop.has( "CUSTOMER_ADDRESS" )
            && this.props.stop.has( "CUSTOMER_CITY" )
            && this.props.stop.has( "CUSTOMER_ZIP" )
            && ( this.props.stop.get( "hasChecklistInstance" )
                || this.props.stop.has( "Delivery" )
                || this.props.stop.has( "Pickup" )
            )
        )
        {
            addressBody = this.getAddressBody();
        }
        // don't show empty or almost empty phone numbers...
        var phoneBody = null;
        if ( this.props.stop.has( "CUSTOMER_PHONE" )
            && ( this.props.stop.get( "CUSTOMER_PHONE" ) )
            && ( this.props.stop.get( "CUSTOMER_PHONE" ) != "" )
            && ( this.props.stop.get( "CUSTOMER_PHONE" ) != " " )
            && ( this.props.stop.get( "CUSTOMER_PHONE" ) != "0000000000" )
            && ( this.props.stop.get( "CUSTOMER_PHONE" ) != "000000000" )
            && ( this.props.stop.get( "CUSTOMER_PHONE" ) != "00000000" )
            && ( this.props.stop.get( "CUSTOMER_PHONE" ) != "0000000" )
        )
        {
            phoneBody = this.getPhoneBody();
        }
        // combine all parts to create a full stop card..
        var iconNumberInt = parseInt( this.props.iconNumber );
        var iconNumberText = "X";
        if ( ( this.props.iconNumber != "X" )
            && ( ( iconNumberInt != 0 ) || ( this.props.iconNumber != null ) )
            )
        {
            iconNumberText = iconNumberInt.toString();
        }
        return (
            <View style={ slStyles.stopBody } >
                <View style={ [ slStyles.stopIconContainer , slStyles[ typeStyleBg ] ] } >
                    <Text style={ slStyles.stopIcon } >{ iconNumberText }</Text>
                </View>
                <View style={ slStyles.stopDetails } >
                    <View style={ slStyles.stopName } >
                        <Text
                            numberOfLines={ 1 }
                            style={ slStyles.stopCustomerName }
                            >
                            { this.props.stop.get( "CUSTOMER_NAME" ) }
                        </Text>
                        <Text style={ slStyles.stopText } >{ typeText }</Text>
                    </View>
                    { addressBody }
                    { phoneBody }
                </View>
            </View>
        );
    }

    render() : ?React.Element {
        var type = STOP_TYPES.EMPTY;
        var stopType = this.props.stop.get( "Transaction_Type" );
        if ( stopType && ( stopType !== undefined ) && ( stopType !== "" ) ) {
            type = stopType;
        }
        const slType = type.replace( /\s/g , "" ).replace( /-/g , "" );
        // determine start button visibilty...
        var completedStops = this.props.session.get( COMPLETED_STOPS_KEY );
        var stopKey = this.props.stop.get( "STOP_KEY" );
        var isComplete = ( completedStops && ( completedStops.indexOf( stopKey ) >= 0 ) );
        var startButton = null;
        if ( this.props.stop.get( "hasChecklistInstance" )
             || this.props.stop.has( "Delivery" )
             || this.props.stop.has( "Pickup" )
        )
        {
            if ( ! this.isBreakStop() ) {
                startButton = (
                    <View style={ [ slStyles.stopActions , slStyles.stopActionsLess ] } >
                        <Button
                            theme={ ( ( isComplete ) ? "grey" : "red" ) }
                            text={ (
                                ( isComplete )
                                ? getLocalizedString( this.props.session , locale.keys.LOC_EDIT )
                                : getLocalizedString( this.props.session , locale.keys.LOC_START )
                            ) }
                            onPress={ () => { this.props.onPress( this.props.stop ) } }
                            type="stop"
                            />
                    </View>
                );
            }
        }
        // all unknow transaction types style will default to the empty black style...
        var typeStyle = "typeEMPTY";
        if ( slStyles[ "type" + slType ] ) {
            typeStyle = "type" + slType;
        }
        // determine stop status...
        var stopStatus = "statusIncomplete";
        if ( isComplete ) {
            stopStatus = "statusComplete";
            typeStyle = "typeComplete";
        }
        return (
            <Card style={ slStyles.stopCard } >
                <View style={ [ slStyles.containerBordered , slStyles[ stopStatus ] , slStyles[ typeStyle ] , slStyles.stopContainer ] } >
                    { this.getStopBody( type ) }
                    { startButton }
                </View>
            </Card>
        );
    }
}

Stop.propTypes = {
    iconNumber : PropTypes.string.isRequired ,
    onPress : React.PropTypes.func.isRequired ,
    session : PropTypes.object.isRequired ,
    stop : PropTypes.object.isRequired ,
};

export default Stop;

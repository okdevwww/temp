/* modal-exception.js */

import React , { PropTypes } from 'react';
import { Text , View } from 'react-native';
import {
    RadioButton ,
    RadioButtonGroup
} from 'react-native-material-design';

import { locale } from './../../config/locale';
import Button from './../shared/button';
import mStyles from './../../styles/modal-styles';

type ModalExceptionPropTypes = {
    modalProps : Object;
    closeModal : () => void;
};

const ModalException = ( { modalProps , closeModal } : ModalExceptionPropTypes ) => {
    var items = [
        {
            label:  "Damage" ,
            value : "LOC_DAMAGE" ,
            disabled : false ,
        } , {
            label: "Missing",
            value: "LOC_MISSING",
            disabled: false
        } , {
            label: "Wrong Item",
           value: "LOC_WRONG_ITEM",
            disabled: false
        } , {
            label: "Does Not Fit",
            value: "LOC_DOES_NOT_FIT",
            disabled: false
        } , {
            label: "Customer Rejected",
            value: "LOC_CUSTOMER_REJECTED",
            disabled: false
        } ,
    ];
    return (
        <View style={ mStyles.modal } >
            <View style={ mStyles.titleView } >
                <Text style={ mStyles.titleFont } >
                    { modalProps.title }
                </Text>
            </View>
            <View style={ mStyles.spacer } />
            <View style={ mStyles.radioButtonContainer } >
                <RadioButtonGroup
                    items={ items }
                    style={ mStyles.radioGroup }
                    onSelect={ modalProps.onSelect }
                    />
            </View>
            <View style={ mStyles.spacer } />
            <View style={ mStyles.buttonContainer } >
                <Button
                    theme="red"
                    raised={ true }
                    text={ locale.en_US.LOC_OK }
                    onPress={
                        () => {
                            modalProps.onClose( modalProps.id );
                            closeModal();
                        }
                    }
                    type="modal"
                    />
            </View>
        </View>
    );

};

ModalException.propTypes = {
    modalProps : PropTypes.object.isRequired ,
    closeModal : PropTypes.func.isRequired ,
};

export default ModalException;

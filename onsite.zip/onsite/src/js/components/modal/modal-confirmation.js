/* modal-confirmation.js */

import React , { PropTypes } from 'react';
import {
    View ,
    Text ,
} from 'react-native';

import Button from './../shared/button';
import mStyles from './../../styles/modal-styles';

type ModalConfirmationPropTypes = {
    modalProps : Object;
    closeModal : () => void;
};

const ModalConfirmation = ( { modalProps , closeModal } : ModalConfirmationPropTypes ) => {
    return (
        <View style={ mStyles.modal } >
            <View style={ mStyles.titleView } >
                <Text style={ mStyles.titleFont } >
                    { modalProps.title }
                </Text>
            </View>
            <View style={ mStyles.textView } >
                <Text style={ mStyles.textFont } >
                    { modalProps.text }
                </Text>
            </View>
            <View style={ mStyles.spacer } />
            <View style={ mStyles.spacer } />
            <View style={ mStyles.choicesContainer } >
                <View style={ mStyles.buttonContainer } >
                    <Button
                        theme="red"
                        raised={ true }
                        text={ modalProps.confirmText }
                        onPress={
                            () => {
                                modalProps.onClose();
                                closeModal();
                            }
                        }
                        type="modal"
                        />
                </View>
                <View style={ mStyles.spacer } />
                <View style={ mStyles.buttonContainer } >
                    <Button
                        theme="grey"
                        raised={ true }
                        text={ modalProps.cancelText }
                        onPress={ () => { closeModal(); } }
                        type="modal"
                        />
                </View>
            </View>
        </View>
    );
};

ModalConfirmation.propTypes = {
    modalProps : PropTypes.object.isRequired ,
    closeModal : PropTypes.func.isRequired ,
};

export default ModalConfirmation;

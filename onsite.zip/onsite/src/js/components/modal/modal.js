/* modal.js */

import React , { PropTypes } from 'react';
import {
    Image ,
    Modal ,
    Text ,
    TextInput ,
    View ,
} from 'react-native';

import { locale } from '../../config/locale';
import ModalConfirmation from './modal-confirmation';
import ModalDirections from './modal-directions';
import ModalException from './modal-exception';
import ModalError from './modal-error';
import { getLocalizedString } from './../../reducers/session-reducers';
import Button from './../shared/button';
import mStyles from './../../styles/modal-styles';
import mcStyles from './../../styles/modal-connect-styles';
import NotificationProvider from './../containers/notification-provider';

const MODAL_COMPONENTS = {
    "directions" : ModalDirections ,
    "confirmation" : ModalConfirmation ,
    "deliveryException" : ModalException ,
    "error" : ModalError ,
};

type ModalCustomPropTypes = {
    modalType : string;
    modalProps : Object;
    session : Object;
    openModal : ( type : string , props : Object ) => void;
    closeModal : () => void;
}

type ModalCustomStateTypes = {
    driverId : string;
};

class ModalCustom extends React.PureComponent<any , ModalCustomPropTypes , ModalCustomStateTypes> {
    props: ModalCustomPropTypes

    constructor( props : ModalCustomPropTypes ) : void {
        super( props );
        this.state = {
            driverId : "" ,
        };
        this.handleConnect = this.handleConnect.bind( this );
        this.renderConnectionModal = this.renderConnectionModal.bind( this );
        this.renderSpecificModal = this.renderSpecificModal.bind( this );
        this.setDriverId = this.setDriverId.bind( this );
    }

    handleConnect() : void {
        this.props.modalProps.onClose( this.state.driverId );
    }

    setDriverId( value : string ) : void {
        this.setState( { driverId : value } );
    }

    renderConnectionModal() : void {
        return (
            <View style={ mStyles.page } >
                <View style={ mStyles.overlay } />
                <View style={ mcStyles.modalConnect } >
                    <View style={ mcStyles.body } >
                        <View style={ mcStyles.pictureContainer } >
                            <Image style={ mcStyles.appLogo } source={ require( './app_logo.png' ) } />
                        </View>
                        <View style={ mcStyles.formContainer } >
                            <Text style={ mcStyles.formCaption } >
                                { locale.en_US.LOC_DRIVER_ID }
                            </Text>
                            <TextInput
                                style={ mcStyles.textInput }
                                keyboardType={ "numeric" }
                                onChangeText={ this.setDriverId }
                                value={ this.state.driverId }
                                />
                        </View>
                    </View>
                    <View style={ mcStyles.notif } >
                        <NotificationProvider />
                    </View>
                    <View style={ mStyles.choicesContainer } >
                        <View style={ mStyles.buttonContainer } >
                            <Button
                                theme="red"
                                raised={ true }
                                text={ locale.en_US.LOC_CONNECT }
                                onPress={ this.handleConnect }
                                type="modal"
                                />
                        </View>
                        <View style={ mStyles.spacer } />
                        <View style={ mStyles.buttonContainer } >
                            <Button
                                theme="grey"
                                raised={ true }
                                text={ locale.en_US.LOC_CANCEL }
                                onPress={ this.props.closeModal }
                                type="modal"
                                />
                        </View>
                    </View>
                </View>
            </View>
        );
    }

    renderSpecificModal() : void {
        const SpecificModal = MODAL_COMPONENTS[ this.props.modalType ];
        return (
            <View style={ mStyles.page } >
                <View style={ mStyles.overlay } />
                <SpecificModal { ...this.props } />
            </View>
        );
    }

    render() : ? React.Element {
        if ( this.props.modalType.length === 0 ) {
            return null;
        }
        var modalContent = null;
        if ( this.props.modalType == "connect" ) {
            modalContent = this.renderConnectionModal();
        } else {
            modalContent = this.renderSpecificModal();
        }
        return (
            <Modal
                animationType={ "none" }
                transparent={ true }
                visible={ true }
                onRequestClose={
                    () => {
                        console.log( "Modal has been closed." );
                    }
                }
                >
                { modalContent }
            </Modal>
        );
    }
}

ModalCustom.propTypes = {
    modalType : PropTypes.string.isRequired ,
    modalProps : PropTypes.object.isRequired ,
    openModal : PropTypes.func.isRequired ,
    closeModal : PropTypes.func.isRequired ,
    session : PropTypes.object.isRequired ,
};

export default ModalCustom;

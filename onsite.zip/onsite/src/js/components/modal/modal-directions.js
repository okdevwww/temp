/* modal-directions.js */

import React , { PropTypes } from 'react';
import {
    ScrollView ,
    Text ,
    View
} from 'react-native';

import { locale } from './../../config/locale';
import { getLocalizedString } from './../../reducers/session-reducers';
import Button from './../shared/button';
import mStyles from './../../styles/modal-styles';

type ModalDirectionsPropTypes = {
    closeModal : () => void;
    modalProps : Object;
    session : Object;
};

const ModalDirections = ( { modalProps , closeModal , session } : ModalDirectionsPropTypes ) => {
    function getInstructions() {
        var instructions = [ "No Instructions Available" ];
        if ( ( modalProps !== undefined )
            && ( modalProps != null )
            )
        {
            if ( typeof modalProps.data === "string" ) {
                if ( ( modalProps.data !== undefined )
                    && ( modalProps.data !== null )
                    && ( modalProps.data !== "" )
                    )
                {
                    instructions = modalProps.data.split( "\n" );
                }
                var instructionRows = [];
                {
                    instructions.map(
                        ( info , key ) => {
                            instructionRows.push(
                                <View
                                    key={ "info-" + key }
                                    style={ mStyles.textView }
                                    >
                                    <Text
                                        style={ mStyles.textHeight }
                                        key={ "text-" + key }
                                        >
                                        { ( ( info != "" ) ? info : "" ) }
                                    </Text>
                                </View>
                            );
                        }
                    )
                }
                return instructionRows;
            }
            else if ( typeof modalProps.data == "object" ) {
                var instructionRows = [];
                instructionRows.push(
                    <View key={ "info-unavailable" } style={ mStyles.textView } >
                        <Text style={ mStyles.textHeight } key={ "text-unavailable" } >Instructions unavailable.</Text>
                    </View>
                );
                return instructionRows;
            }
            else {
                var instructionRows = [];
                instructionRows.push(
                    <View key={ "info-unavailable" } style={ mStyles.textView } >
                        <Text style={ mStyles.textHeight } key={ "text-unavailable" } >No Instructions Available.</Text>
                    </View>
                );
                return instructionRows;
            }
        }
        return null;
    }
    return (
        <View style={ mStyles.modal } >
            <Text style={ mStyles.title } numberOfLines={ 1 } >
                { getLocalizedString( session , locale.keys.LOC_INSTRUCTIONS_TITLE ) }
            </Text>
            <View style={ mStyles.spacer } />
            <View style={ mStyles.scrollView } >
                <View style={ mStyles.scrollViewInner } >
                    <ScrollView contentContainerStyle={ mStyles.scrollContainer } >
                        { getInstructions() }
                    </ScrollView>
                </View>
            </View>
            <View style={ mStyles.spacer } />
            <View style={ mStyles.buttonContainer } >
                <Button
                    theme="red"
                    raised={ true }
                    text={ getLocalizedString( session , locale.keys.LOC_OK ) }
                    onPress={ () => { closeModal(); } }
                    type="modal" />
            </View>
        </View>
    );

};

ModalDirections.propTypes = {
    modalProps : PropTypes.object.isRequired ,
    closeModal : PropTypes.func.isRequired ,
    session : PropTypes.object.isRequired ,
};

export default ModalDirections;

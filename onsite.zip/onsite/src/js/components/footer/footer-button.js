/* footer-button.js */

import Immutable from 'immutable';
import React, {PropTypes} from 'react';
import { View } from 'react-native';
import { Actions } from 'react-native-router-flux';
import Icon from 'react-native-vector-icons/MaterialIcons';

import Button from './../shared/button';
import fStyles from './../../styles/footer-styles';

type FooterButtonPropTypes = {
    buttonId : string;
    buttonIcon : string;
    buttonText : string;
    currentSceneKey : string;
    deliveryInstructions : string;
    enabled : boolean;
    onPress : ( buttonId : string , sceneKey : string , instructions : string ) => void;
};

class FooterButton extends React.PureComponent<any , FooterButtonPropTypes , void> {
    props : FooterButtonPropTypes;

    constructor( props : FooterButtonPropTypes ) : void {
        super( props );
        this.handlePress = this.handlePress.bind( this );
    }

    handlePress() : void {
        this.props.onPress(
            this.props.buttonId ,
            this.props.currentSceneKey ,
            this.props.deliveryInstructions ,
        );
    }

    render() : React.Element {
        if ( ! this.props.enabled ) {
            // non-visible placeholder for disabled buttons...
            return (
                <View style={ fStyles.buttonContainer } />
            );
        }
        return (
            <View style={ fStyles.button } >
                <Button
                    enabled={ this.props.enabled }
                    icon={ this.props.buttonIcon }
                    onPress={ this.handlePress }
                    text={ this.props.buttonText }
                    theme="light"
                    type="footer"
                    />
            </View>
        );
    }
}

FooterButton.propTypes = {
    buttonId : PropTypes.string.isRequired ,
    buttonText : PropTypes.string.isRequired ,
    buttonIcon : PropTypes.string.isRequired ,
    enabled : PropTypes.bool.isRequired ,
    onPress : PropTypes.func.isRequired ,
    currentSceneKey : PropTypes.string ,
    deliveryInstructions : PropTypes.string ,
};

export default FooterButton;

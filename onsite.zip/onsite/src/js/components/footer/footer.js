/* footer.js */

import Immutable from 'immutable';
import React , { PropTypes } from 'react';
import { View } from 'react-native';

import {
    DRIVER_KEY ,
    FOOTER_BACK_KEY ,
    FOOTER_DEFAULT_KEY ,
    FOOTER_INSTRUCTIONS_KEY ,
    SESSION_KEY ,
} from './../../config/constants';
import { locale } from './../../config/locale';
import FooterButton from './footer-button';
import { getLocalizedString } from './../../reducers/session-reducers';
import fStyles from './../../styles/footer-styles';

type FooterPropTypes = {
    buttons : Immutable.Map<string , any>;
    deliveryInstructions : string;
    enabled : boolean;
    onButtonPress : ( buttonId : string , sceneKey : string , instructions : string ) => void;
    scene : Object;
    session : Immutable.Map<string , any>;
};

class Footer extends React.Component<any , FooterPropTypes , void> {
    props : FooterPropTypes;

    constructor( props : FooterPropTypes ) : void {
        super( props );
        this.handlePress = this.handlePress.bind( this );
    }

    handlePress( buttonId : string , sceneKey : string , instructions : Object ) : void {
        this.props.onButtonPress(
            this.props.stopId ,
            buttonId ,
            sceneKey ,
            instructions
        );
    }

    render() : ? React.Element {
        if ( ! this.props.enabled ) {
            return null;
        }
        // track the current scene to control the behavior of the back button in the footer...
        var currentSceneKey = null;
        if ( ( this.props.scene !== null ) && this.props.scene.sceneKey ) {
            currentSceneKey = this.props.scene.sceneKey;
        }
        return (
            <View style={ fStyles.container }>
                {
                    this.props.buttons.map(
                        ( button , key ) => {
                            // disable button when no instructions are available...
                            var enabled = ( ( this.props.deliveryInstructions !== null ) ? true : false );
                            if ( this.props.stopId && ( this.props.stopId === "0" ) ) {
                                enabled = false;
                            }
                            var buttonId = FOOTER_DEFAULT_KEY;
                            switch ( button.get( "key" ) ) {
                                case locale.keys.LOC_BACK :
                                    buttonId = FOOTER_BACK_KEY;
                                    enabled = true;
                                    break;
                                case locale.keys.LOC_INSTRUCTIONS :
                                    buttonId = FOOTER_INSTRUCTIONS_KEY;
                                    if ( ( this.props.scene && ! this.props.scene.sceneKey )
                                        || ( this.props.scene && this.props.scene.sceneKey == "route" )
                                        )
                                    {
                                        // disable the instructions button on the route scene...
                                        enabled = false;
                                    }
                                    break;
                                default :
                                    break;
                            }
                            return (
                                <FooterButton
                                    key={ "button-" + key }
                                    buttonId={ buttonId }
                                    buttonText={ getLocalizedString( this.props.session , button.get( "key" ) ) }
                                    buttonIcon={ button.get( "icon" ) }
                                    currentSceneKey={ currentSceneKey }
                                    deliveryInstructions={ this.props.deliveryInstructions }
                                    enabled={ enabled }
                                    onPress={ this.handlePress }
                                    />
                            );
                        }
                    ).toArray()
                }
            </View>
        );
    }
}

Footer.propTypes = {
    buttons : PropTypes.object.isRequired ,
    deliveryInstructions : PropTypes.string ,
    enabled : PropTypes.bool.isRequired ,
    onButtonPress : PropTypes.func.isRequired ,
    scene : PropTypes.object ,
    session : PropTypes.object.isRequired ,
    stopId : PropTypes.string.isRequired ,
};

export default Footer;

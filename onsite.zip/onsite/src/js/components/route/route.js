/* route.js */

import Immutable from 'immutable';
import React , { PropTypes } from 'react';
import {
    BackAndroid ,
    RefreshControl ,
    ScrollView ,
    Text ,
    View ,
} from 'react-native';

import { NUKE_BACK_BUTTON } from './../../config/constants';
import { SESSION_KEY } from './../../config/constants';
import { locale } from './../../config/locale';
import Button from './../shared/button';
import MenuButton from './../menu/menu-button';
import { getLocalizedString } from './../../reducers/session-reducers';
import Stop from './../stops/stop';
import rStyles from './../../styles/route-styles';

type RoutePropTypes = {
    canContinue : boolean ,
    canEnd : boolean ,
    canStart : boolean ,
    driverId : string;
    isMenuActive : boolean ,
    onContinuePress :  ( driverId : string ) => void;
    onEndPress :  ( driverId : string , stops : Immutable.OrderedMap<string , any> ) => void;
    onRefresh : ( driverId : string ) => void;
    onReconnect : ( driverId : string ) => void;
    onStartPress :  ( driverId : string ) => void;
    onStopPress :  ( stop : Immutable.OrderedMap<string , any> , boolean ) => void;
    session : Immutable.Map<string , any>;
    stops : Immutable.OrderedMap<string , any>;
};

type RouteStateTypes = { };

class Route extends React.PureComponent <any , RoutePropTypes , RouteStateTypes> {
    props : RoutePropTypes;
    state : RouteStateTypes;
    animating : boolean;

    constructor( props : RoutePropTypes ) : void {
        super( props );
        this.animating = false;
        this.handleContinuePress = this.handleContinuePress.bind( this );
        this.handleEndPress = this.handleEndPress.bind( this );
        this.handleStartPress = this.handleStartPress.bind( this );
        this.handleStopPress = this.handleStopPress.bind( this );
        BackAndroid.addEventListener(
            "hardwareBackPress" ,
            () => {
                // true stops native behavior...
                // false allows native behavior to continue...
                if ( NUKE_BACK_BUTTON && ( this.props.isMenuActive === false ) ) {
                    this.props.onBack();
                }
                return NUKE_BACK_BUTTON;
            }
        );
    }

    componentDidMount() : void {
        //console.warn( "componentDidMount" );
        this.props.onReconnect( this.props.driverId );
    }

    // PMCC DBG ~ only required for debugging onReconnect...
    componentWillReceiveProps( nextProps : RoutePropTypes ) : void {
        //console.warn( "componentWillReceiveProps" );
    }

    handleStopPress( stop ) : void {
        //console.warn( "handleStopPress" );
        this.props.onStopPress( stop , ! this.props.session.get( "confirmationActive" ) );
    }

    handleStartPress() : void {
        //console.warn( "handleStartPress" );
        this.props.onStartPress( this.props.driverId );
    }

    handleContinuePress() : void {
        //console.warn( "handleContinuePress ~ session == " + JSON.stringify( this.props.session ) );
        this.props.onContinuePress( this.props.driverId );
    }

    handleEndPress() : void {
        //console.warn( "handleEndPress" );
        //console.warn( "handleEndPress ~ stops == " + JSON.stringify( this.props.stops ) );
        this.props.onEndPress( this.props.driverId , this.props.stops );
    }

    render() : React.Element {
        if ( this.props.isMenuActive ) {
            return (
                <View style={ rStyles.menuContainer } >
                    <View style={ rStyles.buttonContainer }>
                        <MenuButton
                            enabled={ this.props.canStart }
                            iconName={ "input" }
                            onPress={ this.handleStartPress }
                            text={ getLocalizedString( this.props.session , locale.keys.LOC_START_DAY ) }
                            theme={ "green" }
                            />
                    </View>
                    <View style={ rStyles.buttonContainer }>
                        <MenuButton
                            enabled={ this.props.canContinue }
                            iconName={ "vpn-key" }
                            onPress={ this.handleContinuePress }
                            text={ getLocalizedString( this.props.session , locale.keys.LOC_CONTINUE_DAY ) }
                            theme={ "blue" }
                            />
                    </View>
                    <View style={ rStyles.buttonContainer }>
                        <MenuButton
                            enabled={ this.props.canEnd }
                            iconName={ ( ( this.props.canEnd && this.props.driverId ) ? "done-all" : "launch" ) }
                            onPress={ this.handleEndPress }
                            text={ getLocalizedString( this.props.session , locale.keys.LOC_END_DAY ) }
                            theme={ "red" }
                            />
                    </View>
                    <View style={ rStyles.spacer } />
                </View>
            );
        } else {
            var stops = [];
            this.props.stops.map(
                ( stop , index ) => {
                    if ( stop.has( "ICON_NUMBER" ) && stop.get( "ICON_NUMBER" ) ) {
                        stops.push(
                            <Stop
                                stop={ stop }
                                onPress={ this.handleStopPress }
                                key={ "stop-" + index }
                                iconNumber={ stop.get( "ICON_NUMBER" ) }
                                session={ this.props.session }
                                />
                        );
                    }
                }
            );
            return (
                <View style={ rStyles.container }>
                    <ScrollView
                        contentContainerStyle={ rStyles.scrollContainer }
                        refreshControl={
                            <RefreshControl
                                refreshing={ this.animating }
                                onRefresh={
                                    () => {
                                        this.props.onRefresh( this.props.driverId );
                                    }
                                }
                                tintColor="#000000"
                                title="LOADING..."
                                titleColor="#00FF00"
                                colors={ [ "#FF0000" , "#00FF00" , "#0000FF" ] }
                                progressBackgroundColor="#EBEBEB"
                                />
                            }
                        >
                        { stops }
                    </ScrollView>
                </View>
            );
        }
    }
}

Route.propTypes = {
    canContinue : PropTypes.bool.isRequired ,
    canEnd : PropTypes.bool.isRequired ,
    canStart : PropTypes.bool.isRequired ,
    isMenuActive : PropTypes.bool.isRequired ,
    onContinuePress : PropTypes.func.isRequired ,
    onEndPress : PropTypes.func.isRequired ,
    onRefresh : PropTypes.func.isRequired ,
    onStartPress : PropTypes.func.isRequired ,
    onStopPress : PropTypes.func.isRequired ,
    onReconnect : PropTypes.func.isRequired ,
    session : PropTypes.object.isRequired ,
    stops : PropTypes.object.isRequired ,
};

export default Route;

/* sub-header.js */

import Immutable from 'immutable';
import React , { PropTypes } from 'react';
import {
    View ,
    Text ,
} from 'react-native';

import shStyles from './../../styles/sub-header-styles';

type SubHeaderPropTypes = {
    currentStopKey : string;
    enabled : boolean;
    stops : Object;
};

type SubHeaderStateTypes = { };

class SubHeader extends React.Component<any , SubHeaderPropTypes , SubHeaderStateTypes> {
    props : SubHeaderPropTypes;

    constructor( props : SubHeaderPropTypes ): void {
        super( props );
    }

    render() : ? React.Element {
        if ( ! this.props.enabled ) {
            return null;
        }
        return (
            <View style={ shStyles.container } >
                <Text style={ shStyles.text } numberOfLines={ 1 } >
                    { this.props.subHeaderText }
                </Text>
            </View>
        );
    }
}

SubHeader.propTypes = {
    enabled : PropTypes.bool.isRequired ,
    subHeaderText : PropTypes.string.isRequired ,
};

export default SubHeader;

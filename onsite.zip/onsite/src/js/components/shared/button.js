/* button.js */

import React , { PropTypes } from 'react';
import {
    Text ,
    TouchableHighlight ,
    TouchableNativeFeedback ,
    View ,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

import bStyles from './../../styles/button-styles';

type ButtonPropTypes = {
    enabled : boolean;
    onLongPress : () => void;
    onPress : () => void;
    raised : boolean;
    text : string;
    theme : string;
    type : string;
    visible : boolean;
};

type ButtonDefaultPropTypes = {
    enabled : boolean;
    raised : boolean;
    theme : string;
    type : string;
    visible : boolean;
};

type ButtonStateTypes = {
    elevation : number;
};

class Button extends React.Component<ButtonDefaultPropTypes , ButtonPropTypes , ButtonStateTypes> {
    static defaultProps : ButtonDefaultPropTypes;
    props : ButtonPropTypes;
    state : ButtonStateTypes;

    constructor( props : ButtonPropTypes ) : void {
        super( props );
        this.state = { elevation : 2 };
        this.setElevation = this.setElevation.bind( this );
        this.removeElevation = this.removeElevation.bind( this );
        this.handlePress = this.handlePress.bind( this );
    }

    shouldComponentUpdate( nextProps , nextState ) {
        return ( ( nextProps.text !== this.props.text ) || ( nextState.elevation !== this.state.elevation ) );
    }

    setElevation() {
        this.setState( { elevation: 4 } );
    };

    removeElevation() {
        this.setState( { elevation: 2 } );
    };

    handlePress() {
        this.props.onPress( this.props.type );
    };

    render() {
        // robust and error free parameter parsing...  theme...
        var styleTheme = null;
        if ( bStyles[ this.props.theme + "Theme" ] ) {
            styleTheme = bStyles[ this.props.theme + "Theme" ];
        } else {
            console.warn( "~!E!~ button theme named '" + this.props.theme + "Theme' not found (404) ~!E!~" );
        }
        var styleThemeButton = null;
        if ( styleTheme && styleTheme[ "button" ] ) {
            styleThemeButton = styleTheme[ "button" ];
        } else {
            console.warn( "~!E!~ button theme.button named '" + this.props.theme + "Theme.button' not found (404) ~!E!~" );
        }
        var styleThemeText = null;
        if ( styleTheme && styleTheme[ "text" ] ) {
            styleThemeText = styleTheme[ "text" ];
        } else {
            console.warn( "~!E!~ button theme/type named '" + this.props.theme + "Theme.text' not found (404) ~!E!~" );
        }
        // robust and error free parameter parsing...  type...
        var styleType = null;
        if ( bStyles[ this.props.type + "Type" ] ) {
            styleType = bStyles[ this.props.type + "Type" ];
        } else {
            console.warn( "~!E!~ button type named '" + this.props.type + "Type' not found (404) ~!E!~" );
        }
        var styleTypeContainer = null;
        if ( styleType && styleType[ "container" ] ) {
            styleTypeContainer = styleType[ "container" ];
        } else {
            console.warn( "~!E!~ button type.cotainer named '" + this.props.type + "Type.container' not found (404) ~!E!~" );
        }
        var styleTypeFont = null;
        if ( styleType && styleType[ "font" ] ) {
            styleTypeFont = styleType[ "font" ];
        } else {
            console.warn( "~!E!~ button type.font named '" + this.props.type + "Type.font' not found (404) ~!E!~" );
        }
        // handle button visibility...
        if ( ! this.props.visible ) {
            styleThemeButton = bStyles.transparent.button;
        }
        // handle button elevation...
        const elevationStyle = { elevation : ( ( this.props.raised && this.props.visible ) ? this.state.elevation : 0 ) }
        // final style results...
        const buttonStyle = [ bStyles.defaultStyle.container , styleThemeButton , styleTypeContainer , elevationStyle ];
        const textStyle = [ bStyles.defaultStyle.font , styleThemeText , styleTypeFont ];
        // style debugging...
        if ( false ) {
            console.warn( " ~!~ "
                + " ~ theme == " + JSON.stringify( bStyles[ this.props.theme + "Theme" ][ this.props.type + "Button" ] )
                + " ~ type == " + JSON.stringify( bStyles[ this.props.type + "Type" ][ "container" ] )
                + " ~ type == " + this.props.type
                + " ~ theme == " + this.props.theme
                + " ~ buttonStyle == " + JSON.stringify( buttonStyle )
                + " ~ textStyle == " + JSON.stringify( textStyle )
            );
        }
        // optional icon visibility...
        var buttonIcon = null;
        if ( this.props.icon && this.props.visible ) {
            buttonIcon = ( <Icon name={ this.props.icon } size={ 16 } color={ "#666666" } /> );
        }
        // determine button text...
        var propsTextStr = "X";
        if ( this.props.text ) {
            propsTextStr = this.props.text;
        }
        // handle text visibility...
        var buttonText = null;
        if ( this.props.visible ) {
            buttonText = ( <Text style={ textStyle } >{ propsTextStr }</Text> );
        }
        // final render...
        return (
            <TouchableNativeFeedback
                disabled={ ! this.props.enabled  }
                onPress={ this.handlePress }
                onLongPress={ ( this.props.onLongPress ? onLongPress : null ) }
                onPressIn={ ( this.props.raised ? this.setElevation : null ) }
                onPressOut={ ( this.props.raised ? this.removeElevation : null ) }
                background={ TouchableNativeFeedback.SelectableBackground() }
                >
                <View style={ buttonStyle } >
                    { buttonIcon }
                    { buttonText }
                </View>
            </TouchableNativeFeedback>
        );
    };
}

Button.propTypes = {
    enabled : PropTypes.bool ,
    icon : PropTypes.string ,
    onPress : PropTypes.func ,
    onLongPress : PropTypes.func ,
    raised : PropTypes.bool ,
    text : PropTypes.string ,
    theme : PropTypes.string ,
    type : PropTypes.string ,
    visible : PropTypes.bool ,
};

Button.defaultProps = {
    enabled : true ,
    icon : null ,
    raised : true ,
    theme : "red" ,
    type : "modal" ,
    visible : true ,
};

export default Button;

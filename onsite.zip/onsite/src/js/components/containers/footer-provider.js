/* footer-provider.js */

import Immutable from 'immutable';
import { Actions } from 'react-native-router-flux';
import { connect } from 'react-redux';

import { openModal } from './../../actions/modal-actions';
import { receiveDisconnectOnsite } from './../../actions/network-actions';
import { reconnectRoute } from './../../actions/route-actions';
import {
    CHECKLIST_KEY ,
    DRIVER_KEY ,
    FOOTER_BACK_KEY ,
    FOOTER_INSTRUCTIONS_KEY ,
    ROUTE_KEY ,
    SESSION_KEY ,
} from './../../config/constants';
import { locale } from './../../config/locale';
import { getActiveStop } from './../../reducers/stops-reducers';
import Footer from './../footer/footer';

const mapStateToProps = ( state ) => {
    const stopId = ( getActiveStop( state.stops ) != undefined ) ? getActiveStop( state.stops ) : "0";
    const currentStop = state.stops.get( stopId );
    var deliveryInstructions = null;
    if ( ( currentStop != undefined ) && ( typeof currentStop == "object" ) ) {
        deliveryInstructions = currentStop.get( "DELIVERY_INSTRUCTIONS" );
    }
    var enabled = ( ( state.session.has( "footerEnabled" ) ) ? state.session.get( "footerEnabled" ) : true );
    if ( ( state.session.get( "menuActive" ) === true )
        || ( state.session.get( SESSION_KEY ) === null )
        || ( state.scene && state.scene.sceneKey && ( state.scene.sceneKey === DRIVER_KEY ) )
        || ( state.session.get( "confirmationActive" ) === true )
        )
    {
        // hide the footer on the route screen (while reconnecting), and when the driver id is not set, and when on the driver screne...
        enabled = false;
    }
    var footerButtons = Immutable.fromJS(
        {
            "1" : {
                key : locale.keys.LOC_BACK ,
                icon : "history" ,
            } ,
            "2" : {
                key : locale.keys.LOC_INSTRUCTIONS ,
                icon : "announcement" ,
            } ,
        } ,
    );
    return {
        buttons : footerButtons ,
        deliveryInstructions : deliveryInstructions ,
        enabled : enabled ,
        scene : state.scene ,
        session : state.session ,
        stopId : stopId ,
    };
};

const mapDispatchToProps = ( dispatch ) => {
    return {
        onButtonPress : ( stopId , buttonId , sceneKey , instructions ) => {
            switch ( buttonId ) {
                case FOOTER_BACK_KEY :
                    if ( sceneKey == ROUTE_KEY ) {
                        dispatch( reconnectRoute( ) );
                    } else if ( sceneKey == CHECKLIST_KEY ) {
                        Actions.pop();
                    }
                    break;
                case FOOTER_INSTRUCTIONS_KEY :
                    if ( stopId != "0" ) {
                        if ( sceneKey == ROUTE_KEY ) {
                            Actions.tabs();
                        }
                        if ( instructions ) {
                            dispatch( openModal( "directions" , { data : instructions } ) );
                        }
                    }
                    break;
                default :
                    break;
            }
        } ,
    };
};

const FooterProvider = connect(
    mapStateToProps ,
    mapDispatchToProps ,
) ( Footer );

export default FooterProvider;

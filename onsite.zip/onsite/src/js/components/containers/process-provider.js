/* process-provider.js */

import Immutable from 'immutable';
import { connect } from 'react-redux';

import { openModal } from './../../actions/modal-actions';
import {
    addPicture ,
    deletePicture ,
} from './../../actions/picture-actions';
import { refreshDriver } from './../../actions/refresh-actions';
import {
    confirmClose ,
    confirmOpen ,
    storeResponse ,
    storeTimestamp ,
} from './../../actions/response-actions';
import {
    clearSignatures ,
    closeSignatureProcess ,
    completeSignatureProcess ,
    storeSignatureResponse ,
} from './../../actions/signature-actions';
import {
    checkDeliveryItem ,
    setStopComplete ,
} from './../../actions/stop-actions';
import { SOUP_CHECKLIST_QUESTION__C } from './../../bridges/onsite.constants.js';
import {
    SESSION_KEY ,
    COMPLETED_STOPS_ENABLED ,
    } from './../../config/constants';
import { locale } from './../../config/locale';
import Process from './../process/process';
import { getActiveStop } from './../../reducers/stops-reducers';

const mapStateToProps = ( state ) => {
    const driverId = state.session.get( SESSION_KEY );
    const activeStopKey = getActiveStop( state.stops );
    //console.warn( " ~ activeStopKey." + activeStopKey + ".SOUP_CHECKLIST_QUESTION__C == " + JSON.stringify( state.stops.get( activeStopKey ).get( SOUP_CHECKLIST_QUESTION__C ) ) );
    const questions = ( ( state.stops.hasIn( [ activeStopKey , SOUP_CHECKLIST_QUESTION__C ] ) )
        ? state.stops.getIn( [ activeStopKey , SOUP_CHECKLIST_QUESTION__C ] )
        : Immutable.OrderedMap() );
    //console.warn( " ~ questions == " + JSON.stringify( questions ) );
    // PMCC TODO ~ this needs to read from the soups...  not the state of the app...  or be set to the state from the soups elsewhere...
    const pictures = ( ( state.pictures.has( activeStopKey ) )
        ? state.pictures.get( activeStopKey )
        : Immutable.Map() );
    const signature = ( ( state.signature.hasIn( [ driverId , activeStopKey ] ) )
        ? state.signature.getIn( [ driverId , activeStopKey ] )
        : Immutable.Map( { driverSignature : null , customerSignature : null } ) );
    return {
        driverId : driverId ,
        stops : state.stops ,
        stopKey : activeStopKey ,
        questions : questions ,
        pictures : pictures ,
        signature : signature ,
    };
};

const mapDispatchToProps = ( dispatch ) => {
    return {
        onSync : ( driverId , syncParams , stopKey ) => {
            // PMCC STRINGS ~ these are local to this file...
            if ( syncParams
                && syncParams.hasOwnProperty( "titleText" )
                && syncParams.hasOwnProperty( "messageText" )
                && syncParams.hasOwnProperty( "refreshConnection" )
                && syncParams.hasOwnProperty( "nextAction" )
                )
            {
                dispatch(
                    refreshDriver(
                        driverId ,
                        syncParams.titleText ,
                        syncParams.messageText ,
                        syncParams.refreshConnection ,
                        syncParams.nextAction ,
                        stopKey ,
                    )
                );
            }
        } ,
        clearSignatures : ( driverId , stopId ) => {
            dispatch( clearSignatures( driverId , stopId ) );
        } ,
        closeSignatureProcess : ( driverId , stopId ) => {
            dispatch( closeSignatureProcess( driverId , stopId ) );
        } ,
        completeSignatureProcess : ( driverId , stopId ) => {
            dispatch( completeSignatureProcess( driverId , stopId ) );
        } ,
        completeStop : ( stopKey ) => {
            dispatch( setStopComplete( stopKey ) );
        } ,
        confirmAction : ( driverId , stopKey , question , responseValue ) => {
            // replace with store response function...
            if ( COMPLETED_STOPS_ENABLED && question.get( "Checklist_Instance__c.Id" ) ) {
                console.log( "confirmResponse.onClose"
                    + " ~ driverId == " + JSON.stringify( driverId )
                    + " ~ stopKey == " + JSON.stringify( stopKey )
                    + " ~ responseValue == " + JSON.stringify( responseValue )
                    + " ~ question.Checklist_Instance__c.Id == " + JSON.stringify( question.get( "Checklist_Instance__c.Id" ) )
                );
                // need to store timestamp and response at this point...
                dispatch( storeResponse( question.get( "Checklist_instance__c.Id" ) , question , responseValue , stopKey ) );
            }
            // do the confirmation activation logic that will then offer an option to sync...
            if ( true ) {
                //console.warn( "confirmation == " + JSON.stringify( driverId ) + " ~ " + JSON.stringify( stopKey ) + " ~ " + JSON.stringify( question ) + " ~ " + JSON.stringify( responseValue ) );
                dispatch( confirmOpen( driverId , stopKey , question , responseValue ) ); // show confirmation dialog...
            }
        } ,
        onAddPicture : ( stopId , question , section , picture ) => {
            dispatch( addPicture( stopId , question , section , picture ) );
        } ,
        onDeletePicture : ( stopId , process , questionId , picture ) => {
            dispatch( deletePicture( stopId , process , questionId , picture ) );
        } ,
        openModal : ( modalType , modalProps ) => {
            //console.warn( "openModal ~ modalType == " + JSON.stringify( modalType ) + " ~ modalProps == " + JSON.stringify( modalProps ) );
            dispatch( openModal( modalType , modalProps ) );
        } ,
        storeTimestamp : ( stopKey , timestampId ) => {
            //console.warn( "storeTimestamp ~ stopKey == " + stopKey + " ~ timestampId == " + timestampId );
            dispatch( storeTimestamp( stopKey , timestampId ) );
        } ,
        storeResponse : ( checklistInstanceId , question , choice , stopId ) => {
            //console.warn( "storeResponse ~ checklistInstanceId == " + checklistInstanceId + " ~ choice == " + choice + " ~ stopId == " + stopId );
            dispatch( storeResponse( checklistInstanceId , question , choice , stopId ) );
        } ,
        storeSignatureResponse : ( checklistInstanceId , question , choice , stopId , signature , driverId ) => {
            dispatch( storeSignatureResponse( checklistInstanceId , question , choice , stopId , signature , driverId ) );
        } ,
        checkDeliveryItem : ( stopId , item , value , exceptionId ) => {
            dispatch( checkDeliveryItem( stopId , item , value , exceptionId ) );
        } ,
    };
};

const ProcessProvider = connect(
    mapStateToProps ,
    mapDispatchToProps ,
) ( Process );

export default ProcessProvider;

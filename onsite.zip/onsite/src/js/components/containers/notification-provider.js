/* notification-provider.js */

import { connect } from 'react-redux';
import Notification from './../notification/notification';

import { removeNotification } from './../../actions/notification-actions';

const mapStateToProps = ( state , ownProps ) => {
    return {
        notification : state.notification ,
        ...ownProps
    };
};

const mapDispatchToProps = ( dispatch ) => {
    return {
        removeNotification : () => {
            dispatch( removeNotification() );
        }
    };
};

const NotificationProvider = connect(
    mapStateToProps ,
    mapDispatchToProps ,
) ( Notification );

export default NotificationProvider;

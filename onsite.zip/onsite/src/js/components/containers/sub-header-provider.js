/* sub-header-provider.js */

import { connect } from 'react-redux';

import {
    CHECKLIST_KEY ,
    CURRENT_STOP_KEY ,
    DRIVER_KEY ,
    SESSION_KEY ,
} from './../../config/constants.js';
import { locale } from './../../config/locale';
import SubHeader from './../sub-header/sub-header';
import { getLocalizedString } from './../../reducers/session-reducers';

const mapStateToProps = ( state ) => {
    // determine sub-header visibility...
    var sessionKey = ( ( state.session.has( SESSION_KEY ) ) ? state.session.get( SESSION_KEY ) : null );
    var validSessionKey = ( ( sessionKey !== null ) && ( sessionKey !== "" ) );
    var sceneKey = ( ( validSessionKey && ( state.scene !== null ) ) ? state.scene.sceneKey : null );
    var validSceneKey = ( sceneKey && ( sceneKey !== DRIVER_KEY ) );
    var validSubHeader = ( ( state.session.has( "subHeaderEnabled" ) ) ? state.session.get( "subHeaderEnabled" ) : null );
    const isEnabled = ( ( validSessionKey && validSceneKey && validSubHeader ) ? true : false );
    // determine base text...
    var baseText = "";
    state.stops.map(
        ( stop , index ) => {
            var driverNameKey = "DRIVER_NAME";
            if ( stop.get( driverNameKey )
                && ( stop.get( driverNameKey ) !== null )
                && ( stop.get( driverNameKey ) !== "" )
                )
            {
                baseText = stop.get( driverNameKey );
            }
        }
    );
    // determine additional text...
    var isStopScene = ( ( sceneKey && ( sceneKey === CHECKLIST_KEY ) ) ? true : false );
    const currentStopKey = ( ( isStopScene && state.session.has( CURRENT_STOP_KEY ) ) ? state.session.get( CURRENT_STOP_KEY ) : null );
    // determine final text...
    if ( currentStopKey !== null ) {
        baseText = baseText
            + " ~ " + getLocalizedString( state.session , locale.keys.LOC_STOP )
            + " " + currentStopKey;
    }
    const subHeaderText = baseText;
    // load the props...
    return {
        subHeaderText : baseText ,
        enabled : isEnabled ,
    };
};

const mapDispatchToProps = ( dispatch ) => {
    return {
    };
};

const SubHeaderProvider = connect(
    mapStateToProps ,
    mapDispatchToProps ,
) ( SubHeader );

export default SubHeaderProvider;

/* route-provider.js */

import { connect } from 'react-redux';

import { confirmClose } from './../../actions/response-actions';
import {
    continueRoute ,
    endRoute ,
    reconnectRoute ,
    startRoute ,
} from './../../actions/route-actions';
import {
    refreshDriver ,
    refreshStop ,
} from './../../actions/refresh-actions';
import {
    DEFAULT_SYNC_TITLE_TEXT ,
    DEFAULT_SYNC_MESSAGE_TEXT ,
    SESSION_KEY ,
} from './../../config/constants';
import Route from './../route/route';

var storeManager = require( './../../bridges/StoreManager.js' );

const mapStateToProps = ( state ) => {
    const driverId = state.session.get( SESSION_KEY );
    const isMenuActive = ( state.session.has( "menuActive" ) ? state.session.get( "menuActive" ) : false );
    const hasDriverId = ( ( driverId !== null ) && ( driverId !== "" ) && ( parseInt( driverId ) !== 0 ) );
    const canContinue = ( hasDriverId );
    const canEnd = ( hasDriverId );
    const canStart = ( ! hasDriverId );
    return {
        canContinue : canContinue ,
        canEnd : canEnd ,
        canStart : canStart ,
        driverId : driverId ,
        isMenuActive : isMenuActive ,
        session : state.session ,
        stops : state.stops ,
    };
};

const mapDispatchToProps = ( dispatch ) => {
    return {
        onRefresh : ( driverId ) => {
            dispatch(
                refreshDriver(
                    driverId ,
                    DEFAULT_SYNC_TITLE_TEXT ,
                    DEFAULT_SYNC_MESSAGE_TEXT ,
                    true , // this action will trigger a refresh of the decartes webservice data...
                    null ,
                )
            );
        } ,
        onStopPress : ( stop , showInstructions ) => {
            dispatch( confirmClose() ); // ensure the key confirmation dialog is hidden...
            dispatch( refreshStop( stop , showInstructions ) );
        } ,
        onBack : ( ) => {
            dispatch( reconnectRoute( ) );
        } ,
        onReconnect : ( driverId ) => {
            dispatch( reconnectRoute( ) );
        } ,
        onStartPress : ( driverId ) => {
            dispatch( startRoute( driverId ) );
        } ,
        onContinuePress : ( driverId ) => {
            dispatch( continueRoute( driverId ) );
        } ,
        onEndPress : ( driverId , stops ) => {
            dispatch( endRoute( driverId , stops ) );
        } ,
    };
};

const RouteProvider = connect(
    mapStateToProps ,
    mapDispatchToProps ,
) ( Route );

export default RouteProvider;

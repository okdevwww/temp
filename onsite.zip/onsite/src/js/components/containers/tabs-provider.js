/* tabs-provider.js */

import { NetInfo } from 'react-native';
import SplashScreen from 'react-native-splash-screen';
import { Actions } from 'react-native-router-flux';
import { connect } from 'react-redux';

import { onProcessPressed } from './../../actions/process-actions';
import { refreshDriver } from './../../actions/refresh-actions';
import { confirmClose } from './../../actions/response-actions';
import {
    setTabStarted ,
    setTabCompleted ,
} from './../../actions/tab-actions';
import {
    CHECKLIST_KEY ,
    PROCESS_KEY_RETURN ,
    SESSION_KEY ,
    DEFAULT_SYNC_MESSAGE_TEXT ,
    DEFAULT_SYNC_TITLE_TEXT ,
    REFRESH_SOUPS_ENABLED ,
} from './../../config/constants';
import { getActiveStop } from './../../reducers/stops-reducers';
import TabsList from './../tabs/tabs-list';

var storeManager = require( './../../bridges/StoreManager.js' );

const mapStateToProps = ( state ) => {
    const driverId = state.session.get( SESSION_KEY );
    const stopId = ( getActiveStop( state.stops ) != undefined ) ? getActiveStop( state.stops ) : "1"; // PMCC STRING ~ local to file...
    const currentStopTabs = state.stops.getIn( [ stopId , CHECKLIST_KEY ] );
    const isConfirmationActive = ( ( state.session.has( "confirmationActive" ) ) ? state.session.get( "confirmationActive" ) : false );
    const isScrollEnabled = ( ( state.session.has( "scrollEnabled" ) ) ? state.session.get( "scrollEnabled" ) : false );
    return {
        driverId : driverId ,
        isConfirmationActive : isConfirmationActive ,
        scrollEnabled : isScrollEnabled ,
        stopId : stopId ,
        stops : state.stops ,
        tabs : currentStopTabs ,
    };
};

const mapDispatchToProps = ( dispatch ) => {
    return {
        onRefresh : ( driverId ) => {
            dispatch(
                refreshDriver(
                    driverId ,
                    DEFAULT_SYNC_TITLE_TEXT ,
                    DEFAULT_SYNC_MESSAGE_TEXT ,
                    false ,
                    null ,
                )
            );
        } ,
        confirmationClose : ( confirm , driverId ) => {
            dispatch( confirmClose() ); // close the confirmation dialog...
            if ( confirm ) {
                SplashScreen.show();
                NetInfo.isConnected.fetch().then(
                    ( isConnected ) => {
                        if ( isConnected ) {
                            // proceed with refresh...
                            console.log( "confirmationClose ~ NetInfo.isConnected " + ( isConnected ? "online" : "offline" ) );
                            if ( REFRESH_SOUPS_ENABLED ) {
                                console.log( "PMCC DBG ~ ################################################################################" );
                                console.log( "PMCC DBG ~ .syncSoups" );
                                var syncSoupsStart = Date.now();
                                storeManager.syncSoups(
                                    ( pictures ) => {
                                        // PMCC TODO ~ add dispatch to reset picture data from the content document results...
                                        console.log( "PMCC DBG ~ .syncSoups.SUCCESS ~ " + ( ( Date.now() - syncSoupsStart ) / 1000 ) );
                                        console.log( "PMCC DBG ~ ################################################################################" );
                                        SplashScreen.hide();
                                        Actions.pop(); // return to the previous screen...
                                    }
                                );
                            }
                        } else {
                            SplashScreen.hide();
                            Actions.pop(); // return to the previous screen...
                        }
                    }
                );
            }
        } ,
        onProcessPressed : ( stopId , processId , active ) => {
            dispatch( onProcessPressed( stopId , processId , active ) );
        } ,
        setTabStarted : ( stopId , id ) => {
            dispatch( setTabStarted( stopId , id ) );
        } ,
        setTabCompleted : ( stopId , id ) => {
            if ( id != PROCESS_KEY_RETURN ) {
                dispatch( setTabCompleted( stopId , id ) );
            }
        } ,
    };
};

const TabsProvider = connect(
    mapStateToProps ,
    mapDispatchToProps ,
) ( TabsList );

export default TabsProvider;

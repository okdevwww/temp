/* header-provider.js */

import { connect } from 'react-redux';

import { setLocale } from './../../actions/locale-actions';
import { openModal } from './../../actions/modal-actions';
import Header from './../header/header';

var oauth = require( './../../bridges/react.force.oauth.js' );

const mapStateToProps = ( state ) => {
    return {
        scene : state.scene ,
        session : state.session ,
        stops : state.stops ,
    };
};

const mapDispatchToProps = ( dispatch ) => {
    return {
        onLocalePress : ( locale ) => {
            dispatch( setLocale( locale ) );
        } ,
        onLogoutPress : ( ) => {
            dispatch(
                openModal(
                    "confirmation" ,
                    {
                        title : "Logout Confirmation" ,
                        text : "Logout?" ,
                        confirmText : "YES" ,
                        cancelText : "NO" ,
                        onClose: () => {
                            // invalidate oauth token...  forces app back to login.salesforce.com...
                            oauth.logout();
                            // PMCC TODO ~ needs to change app state to trigger render...
                        } ,
                    }
                )
            );
        }
    };
};

const HeaderProvider = connect(
    mapStateToProps ,
    mapDispatchToProps ,
) ( Header );

export default HeaderProvider;

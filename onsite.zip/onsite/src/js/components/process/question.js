/* question.js */

import React , { PropTypes } from 'react';
import ImagePicker from 'react-native-image-picker';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {
    Image ,
    Text ,
    TouchableNativeFeedback ,
    TouchableOpacity ,
    View ,
} from 'react-native';

import CheckButton from './../shared/checkbutton';
import qStyles from './../../styles/question-styles';

type QuestionPropTypes = {
    confirmResponse : ( question : Object , responseValue : string ) => void;
    confirmationRequired : boolean;
    onAddPicture : ( stopId : string, question : Object , section : string , picture : Object ) => void;
    onSync : ( driverId : string ) => void;
    pictures : Immutable.Map<string , any>;
    question : Immutable.List<Immutable.Map<string , any>>;
    stopKey : string;
    storeResponse : ( checklistInstanceId : string , question : Immutable.Map<string , any> , choice : string , stopId : string ) => void;
};

type QuestionStateTypes = { };

class Question extends React.Component<any , QuestionPropTypes , QuestionStateTypes> {
    props : QuestionPropTypes;
    state : QuestionStateTypes;
    launchCamera : () => void;
    options : Object;
    selectResponse : ( value : string ) => void;

    constructor( props : QuestionPropTypes ) : void {
        super( props );
        this.options = {
            cameraType : "back" ,
            mediaType : "photo" ,
            maxHeight : 512 ,
            maxWidth : 512 ,
            quality : 0.375 ,
        };
        this.launchCamera = this.launchCamera.bind( this );
        this.selectResponse = this.selectResponse.bind( this );
    }

    selectResponse( value : string ) : void {
        //console.warn( "selectResponse" );
        this.props.storeResponse( this.props.question.get( "Checklist_Instance__c.Id" ) , this.props.question , value , this.props.stopKey );
        if ( this.props.confirmationRequired && this.props.confirmResponse ) {
            this.props.confirmResponse( this.props.question , value ); // handle key return cases...
        } else if ( this.props.question.get( "Question__r" ).has( "Sync__c" )
            && this.props.question.get( "Question__r" ).get( "Sync__c" )
            && this.props.hasOwnProperty( "onSync" )
            && this.props.hasOwnProperty( "driverId" )
            )
        {
            // PMCC TODO ~ this is unreachable with the addition of confirmResponse...
            this.props.onSync( this.props.driverId );
        }
    }

    launchCamera() : void {
        ImagePicker.launchCamera(
            this.options ,
            ( response ) => {
                //console.log( "Response = " , response );
                if ( response.didCancel ) {
                    //console.log( "User cancelled image picker" );
                } else if ( response.error ) {
                    //console.log( "ImagePicker Error: " , response.error );
                } else if ( response.customButton ) {
                    //console.log( "User tapped custom button: " , response.customButton );
                } else {
                    // You can display the image using either data...
                    const source = {
                        uri : "data:image/jpeg;base64," + response.data ,
                        isStatic : true ,
                        pathOnClient : response.path ,
                        versionData : response.data ,
                    };
                    // or a reference to the platform specific asset location
                    //if ( Platform.OS === "ios" ) {
                    //    const source = { uri : response.uri.replace( "file://" , "" ) , isStatic : true };
                    //} else {
                    //    const source = { uri : response.uri , isStatic : true };
                    //}
                    const process = this.props.question.get( "Process__c" ).replace( " " , "_" );
                    this.props.onAddPicture( this.props.stopKey , this.props.question , process , source );
                }
            }
        );
    }

    deletePicture() : void {
    }

    render() : React.Element {
        var baseKey = "question-" + this.props.stopKey;
        var answers = [];
        if ( this.props.question.has( "Question__r" )
            && this.props.question.get( "Question__r" )
            && this.props.question.get( "Question__r" ).has( "Question_Choices__c" )
            && this.props.question.get( "Question__r" ).get( "Question_Choices__c" )
            )
        {
            answers = this.props.question.get( "Question__r" ).get( "Question_Choices__c" ).split( "\n" );
        }
        var pictureRows = [];
        var choice = this.props.question.get( "Choice" );
        var questionId = this.props.question.get( "Name" ) + "-" + this.props.stopKey;
        var answerRows = [];
        var answerBaseKey = "answer-" + baseKey;
        answers.map(
            ( answer , index ) => {
                var answerValue = answer.replace( "\r" , "" );
                var answerKey = answerBaseKey + "-" + index;
                var answerSelected = false;
                if ( choice && ( choice == answerValue ) ) {
                    answerSelected = true;
                }
                answerRows.push(
                    <View key={ answerKey } style={ qStyles.checkbox }>
                        <CheckButton
                            selected={ answerSelected }
                            onSelect={ this.selectResponse }
                            value={ answerValue }
                            />
                    </View>
                );
            }
        );
        if ( this.props.question.get( "Allow_Images__c" ) ) {
            var cameraButtonIcon = <Icon name={ "photo-camera" } size={ 40 } />;
            var cameraButtonKey = answerBaseKey + "-camera";
            answerRows.push(
                <View key={ cameraButtonKey } style={ qStyles.checkbox } >
                    <TouchableOpacity onPress={ this.launchCamera } >
                        { cameraButtonIcon }
                    </TouchableOpacity>
                </View>
            );
        }
        if ( this.props.pictures ) {
            this.props.pictures.map(
                ( picture , index ) => {
                    var pictureKey = questionId + index;
                    var pictureData = picture.getIn( [ questionId ] );
                    if ( pictureData ) {
                        pictureRows.push(
                            <TouchableNativeFeedback
                                onPress={ () => { } }
                                onLongPress={ () => { this.deletePicture( pictureData ) } }
                                key={ pictureKey } >
                                <View key={ pictureKey } style={ [ qStyles.checkbox , qStyles.imageContainer ] } >
                                    <Image source={ pictureData } style={ qStyles.itemImage } />
                                </View>
                            </TouchableNativeFeedback>
                        );
                    }
                }
            );
        }
        // PMCC TODO ~ we need to start rendering the images from the ContentVersion soup as well as the images that are stored locally by the camera...
        //  ~ disabled output for demo...
        var versionData = [];
        if ( false && this.props.question.has( "Allow_Images__c" ) && this.props.question.has( "VersionData" ) && this.props.question.get( "VersionData" ) ) {
            var versionDataKey = answerBaseKey + "versionData";
            var versionDataSubString = this.props.question.get( "VersionData" ).substring( 0 , 101 );
            versionData.push(
                <View key={ versionDataKey }>
                    <Text>
                        { versionDataSubString }
                    </Text>
                </View>
            );
        }
        return (
            <View>
                <View>
                    <Text style={ qStyles.questionText } >
                        { this.props.question.get( "Question_Text__c" ) }
                    </Text>
                </View>
                <View style={ qStyles.answers } >
                    { answerRows }
                </View>
                <View style={ qStyles.images } >
                    { pictureRows }
                </View>
                { versionData }
            </View>
        );
    }
}

Question.propTypes = {
    confirmResponse : PropTypes.func ,
    confirmationRequired : PropTypes.bool ,
    driverId : PropTypes.string.isRequired ,
    onAddPicture : PropTypes.func.isRequired ,
    onSync : PropTypes.func.isRequired ,
    onDeletePicture : PropTypes.func.isRequired ,
    pictures : PropTypes.object.isRequired ,
    question : PropTypes.object.isRequired ,
    stopKey : PropTypes.string.isRequired ,
    storeResponse : PropTypes.func.isRequired ,
};

export default Question;

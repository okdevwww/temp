/* process-content.js */

import Immutable from 'immutable';
import React , { PropTypes } from 'react';
import { Card } from 'react-native-material-design';
import {
    View ,
    Text ,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

import { locale } from './../../config/locale';
import pcStyles from './../../styles/process-content-styles';
import ProcessFactory from './process-factory';

type ProcessContentPropTypes = {
    onPress : ( stopId : string , id : string , active : boolean ) => void;
    setTabCompleted : ( stopId : string , id : string ) => void;
    setTabStarted : ( stopId : string , id : string ) => void;
    stopId : string;
    process : Immutable.Map<string , any>;
    id : string;
};

type ProcessContentStateTypes = {
    minHeight: number;
    maxHeight: number;
    animation: Object;
};

class ProcessContent extends React.PureComponent<any , ProcessContentPropTypes , ProcessContentStateTypes> {
    props : ProcessContentPropTypes;
    state : ProcessContentStateTypes;
    toggle : () => void;

    constructor( props : ProcessContentPropTypes ) {
        super( props );
        this.toggle = this.toggle.bind( this );
    }

    componentDidUpdate() : void { }

    toggle() : void {
        if ( ( ! this.props.process.get( "active" ) ) && ( ! this.props.process.get( "completed" ) ) ) {
            this.props.setTabStarted( this.props.stopId , this.props.processId );
        }
        if ( this.props.process.get( "active" ) && this.props.process.get( "started" ) ) {
            this.props.setTabCompleted( this.props.stopId , this.props.processId );
        }
        this.props.onPress( this.props.stopId , this.props.processId , ( ! this.props.process.get( "active" ) ) );
    }

    render() : React.Element<any> {
        const process = this.props.process;
        const doneIcon = ( ( process.get( "completed" ) )
            ? ( <Icon name="done" size={ 25 } style={ pcStyles.icon } /> )
            : ( <Icon name={ process.get( "icon" ) } size={ 25 } style={ pcStyles.icon } /> )
        );
        const editIcon = ( ( process.get( "completed" ) && ! process.get( "active" ) )
            ? ( <Icon name="mode-edit" size={ 20 } /> )
            : null
        );
        const cardEditing = ( ( process.get( "completed" ) && ( ! process.get( "active" ) ) )
            ? [ pcStyles.card , pcStyles.cardEditing ]
            : [ pcStyles.card ]
        );
        var localeKey = "LOC_" + this.props.processId.toUpperCase();
        var processText = locale.en_US[ localeKey ];
        //console.warn( localeKey + " ~ " + processText );
        const card = (
            <View>
                <Card style={ cardEditing }
                      underlayColor="#F1F1F1"
                      onPress={ this.toggle } >
                    <View style={ pcStyles.left } >
                        <View style={ pcStyles.iconContainer } >
                            { doneIcon }
                        </View>
                        <View style={ pcStyles.captionContainer } >
                            <Text style={ pcStyles.caption }>{ processText }</Text>
                        </View>
                    </View>
                    <View style={ pcStyles.right } >
                        <View style={ pcStyles.iconEditContainer } >
                            { editIcon }
                        </View>
                    </View>
                </Card>
            </View>
        );
        var content = ProcessFactory.getProcess(
            this.props.processId ,
            this.props.stopId ,
        );
        var renderedContent = null;
        if ( this.props.process && this.props.process.has( "active" ) && this.props.process.get( "active" ) ) {
            renderedContent = (
                <View>{ content }</View>
            );
        }
        return (
            <View>
                { card }
                { renderedContent }
            </View>
        );
    }
}

ProcessContent.propTypes = {
    onPress : PropTypes.func.isRequired ,
    setTabCompleted : PropTypes.func.isRequired ,
    setTabStarted : PropTypes.func.isRequired ,
    stopId : PropTypes.string.isRequired ,
    process : PropTypes.object.isRequired ,
    processId : PropTypes.string.isRequired ,
};

export default ProcessContent;



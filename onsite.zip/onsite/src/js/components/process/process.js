/* process.js */

import Immutable from 'immutable';
import React , { PropTypes } from 'react';
import {
    View ,
    Text ,
} from 'react-native';

import {
    COMPLETED_STOPS_ENABLED ,
    PROCESS_KEY_RELEASE ,
    PROCESS_KEY_RETURN ,
    TIMESTAMP_KEY_RELEASE,
    TIMESTAMP_KEY_RETURN ,
} from './../../config/constants';
import Group from './group';
import Room from './room';
import Question from './question';
import Signature from './signature';
import pStyles from './../../styles/process-styles';

type ProcessPropTypes = {
    completeStop : ( stopKey : string ) => void;
    hasSignature : boolean;
    hasRooms : boolean;
    hasGroups : boolean;
    driverId : string;
    stopKey : string;
    questions : Immutable.List<Immutable.Map<string , any>>;
    pictures : Immutable.List<Immutable.Map<string , any>>;
    storeResponse : ( checklistInstanceId : string , question : Immutable.Map<string , any> , choice : string , stopId : string ) => void;
    storeTimestamp : ( stopKey : string , signature : Object ) => void;
    onSync : ( driverId : string , syncParams : Object , stopKey : string ) => void;
    onAddPicture : (stopId : string , question : Object , section : string , picture : Object ) => void;
    onDeletePicture : ( section : string , picture : Object ) => void;
    clearSignatures : ( driverId : string , stopId : string ) => void;
    closeSignatureProcess : ( driverId : string , stopId : string ) => void;
    completeSignatureProcess : ( driverId : string , stopId : string ) => void;
    openModal : ( modalType : string , modalProps : Object ) => void;
    storeSignatureResponse : ( checklistInstanceId : string , question : Object , choice : string , stopId : string , signature : Object , driverId : string ) => void;
};

type ProcessStateTypes = { };

class Process extends React.Component<any , ProcessPropTypes , ProcessStateTypes> {
    props : ProcessPropTypes;
    state : ProcessStateTypes;
    handleConfirmResponse : ( question : Object , responseValue : string ) => void;
    handleStoreResponse : ( checklistInstanceId : string , question : Object , value : string , stopId : string ) => void;
    handleStoreSignatureResponse : ( checklistInstanceId : string , question : Object , choice : string , stopId : string , signature : Object , driverId : string ) => void;
    handleSync : ( ) => void;

    constructor( props : ProcessPropTypes ) : void {
        super( props );
        this.getQuestionRows = this.getQuestionRows.bind( this );
        this.getRoomRows = this.getRoomRows.bind( this );
        this.getSignatureRows = this.getSignatureRows.bind( this );
        this.getGroupRows = this.getGroupRows.bind( this );
        this.getGroupByType = this.getGroupByType.bind( this );
        this.handleConfirmResponse = this.handleConfirmResponse.bind( this );
        this.handleStoreResponse = this.handleStoreResponse.bind( this );
        this.handleStoreSignatureResponse = this.handleStoreSignatureResponse.bind( this );
        this.handleSync = this.handleSync.bind( this );
    }

    handleConfirmResponse( question : Object , responseValue : string ) : void {
        //console.warn( "handleConfirmResponse ~ responseValue == " + responseValue );
        return this.props.confirmAction( this.props.driverId , this.props.stopKey , question , responseValue );
    }

    handleStoreSignatureResponse( checklistInstanceId : string , question : Object , choice : string , stopId : string , signature : Object , driverId : string ) : void {
        this.props.storeSignatureResponse( checklistInstanceId , question , choice , stopId , signature , driverId );
    }

    handleStoreResponse( checklistInstanceId : string , question : Object , value : string , stopId : string ) : void {
        this.props.storeResponse( checklistInstanceId , question , value , stopId );
        var timestamp = null;
        if ( this.props.process === PROCESS_KEY_RELEASE ) {
            timestamp = TIMESTAMP_KEY_RELEASE;
        } else if ( this.props.process === PROCESS_KEY_RETURN ) {
            timestamp = TIMESTAMP_KEY_RETURN;
            if ( COMPLETED_STOPS_ENABLED ) {
                this.props.completeStop( this.props.stopKey );
            }
        }
        if ( timestamp !== null ) {
            this.props.storeTimestamp( this.props.stopKey , timestamp );
        }
    }

    handleSync( ) : void {
        this.props.onSync(
            this.props.driverId ,
            this.props.sync ,
            this.props.stopKey ,
        );
    }

    getGroupByType( type : string ) : React.Element {
        const baseKey = "group-" + type;
        return (
            <View key={ "view-" + baseKey } >
                <Group
                    key={ baseKey }
                    group={ type }
                    items={ this.props.stops.getIn( [ this.props.stopKey , type ] ) }
                    checkDeliveryItem={ this.props.checkDeliveryItem }
                    openModal={ this.props.openModal }
                    />
            </View>
        );
    }

    getGroupRows() : Array {
        var groupRows = [];
        if ( this.props.stopKey
            && this.props.stops
            && this.props.stops.has( this.props.stopKey )
            && this.props.stops.get( this.props.stopKey )
            )
        {
            var stop = this.props.stops.get( this.props.stopKey );
            if ( stop.has( "Delivery" ) && stop.get( "Delivery" ) ) {
                groupRows.push( this.getGroupByType( "Delivery" ) );
            }
            if ( stop.has( "Pickup" ) && stop.get( "Pickup" ) ) {
                groupRows.push( this.getGroupByType( "Pickup" ) );
            }
        }
        return groupRows;
    }

    getRoomRows() : Array {
        var roomRows = [];
        var baseKey = "-" + this.props.stopKey;
        var rooms = Immutable.Map();
        var pictures = Immutable.List();
        if ( this.props.process ) {
            baseKey = this.props.process + baseKey;
            if ( this.props.questions.has( this.props.process ) ) {
                rooms = this.props.questions.get( this.props.process );
            }
            if ( this.props.pictures.has( this.props.process ) ) {
                pictures = this.props.pictures.get( this.props.process );
            }
        }
        rooms.map(
            ( room , roomIndex ) => {
                var roomKey = baseKey + "-room-" + roomIndex;
                roomRows.push(
                    <Room
                        key={ roomKey }
                        stopId={ this.props.stopKey }
                        roomTitle={ roomIndex }
                        questions={ room }
                        driverId={ this.props.driverId }
                        onSync={ this.handleSync }
                        storeResponse={ this.handleStoreResponse }
                        onAddPicture={ this.props.onAddPicture }
                        onDeletePicture={ this.props.onDeletePicture }
                        pictures={ pictures }
                        />
                );
            }
        );
        return roomRows;
    }

    getSignatureRows() : Array {
        var signatureRows = [];
        var baseKey = "-" + this.props.stopKey;
        var questions = Immutable.Map();
        if ( this.props.process ) {
            baseKey = this.props.process + baseKey;
            if ( this.props.questions.has( this.props.process ) ) {
                questions = this.props.questions.get( this.props.process );
            }
        }
        // there should only be a single question with the "Signature" process...
        //  ~ "Who signed?" ~ Customer OR Driver ~ Images Allowed
        //console.warn( " ~ questions == " + JSON.stringify( questions ) );
        //console.warn( " ~ question == " + JSON.stringify( questions.get( 0 ) ) );
        if ( questions.has( 0 ) ) {
            signatureRows.push(
                <Signature
                    key={ baseKey }
                    signature={ this.props.signature }
                    driverId={ this.props.driverId }
                    stopId={ this.props.stopKey }
                    question={ questions.get( 0 ) }
                    storeTimestamp={ this.props.storeTimestamp }
                    closeSignatureProcess={ this.props.closeSignatureProcess }
                    completeSignatureProcess={ this.props.completeSignatureProcess }
                    clearSignatures={ this.props.clearSignatures }
                    storeSignatureResponse={ this.handleStoreSignatureResponse }
                    openModal={ this.props.openModal }
                    />
            );
        }
        return signatureRows;
    }

    getQuestionRows() : Array {
        var questionRows = [];
        var baseKey = "-" + this.props.stopKey;
        var questions = Immutable.Map();
        var pictures = Immutable.List();
        if ( this.props.process ) {
            baseKey = this.props.process + baseKey;
            if ( this.props.questions.has( this.props.process ) ) {
                questions = this.props.questions.get( this.props.process );
            }
            if ( this.props.pictures.has( this.props.process ) ) {
                pictures = this.props.pictures.get( this.props.process );
            }
        }
        questions.map(
            ( question , index ) => {
                var questionId = question.get( "Name" ) + "-" + this.props.stopKey;
                var questionKey = baseKey + "-question-" + index;
                var isConfirmationRequired = ( question
                    && question.get( "Question__r" )
                    && question.get( "Question__r" ).get( "Sync__c" )
                    && ( question.get( "Question__r" ).get( "Sync__c" ) == true )
                );
                questionRows.push(
                    <Question
                        key={ questionKey }
                        stopKey={ this.props.stopKey }
                        question={ question }
                        driverId={ this.props.driverId }
                        onSync={ this.handleSync }
                        storeResponse={ this.handleStoreResponse }
                        onAddPicture={ this.props.onAddPicture }
                        onDeletePicture={ this.props.onDeletePicture }
                        pictures={ pictures }
                        confirmationRequired={ isConfirmationRequired }
                        confirmResponse={ this.handleConfirmResponse }
                        />
                );
            }
        );
        return questionRows;
    }

    render() : React.Element {
        var processRows = [];
        if ( this.props.hasGroups ) {
            processRows = this.getGroupRows();
        } else if ( this.props.hasRooms ) {
            processRows = this.getRoomRows();
        } else if ( this.props.hasSignature ) {
            processRows = this.getSignatureRows();
        } else {
            processRows = this.getQuestionRows();
        }
        // spacer ensures all processes are different sizes and therefore trigger the size change of the contain when opened...
        var spacer = null;
        if ( this.props.process ) {
            spacer = ( <View style={ pStyles[ "spacer_" + this.props.process ] } /> );
        }
        return (
            <View style={ pStyles.container }>
                { processRows }
                { spacer }
            </View>
        );
    }
}

Process.propTypes = {
    completeStop : PropTypes.func.isRequired ,
    hasSignature : PropTypes.bool.isRequired ,
    hasRooms : PropTypes.bool.isRequired ,
    hasGroups : PropTypes.bool.isRequired ,
    process : PropTypes.string.isRequired ,
    driverId : PropTypes.string.isRequired ,
    stopId : PropTypes.string.isRequired ,
    questions : PropTypes.object.isRequired ,
    pictures : PropTypes.object.isRequired ,
    sync : PropTypes.object.isRequired ,
    onSync : PropTypes.func.isRequired ,
    onAddPicture : PropTypes.func.isRequired ,
    onDeletePicture : PropTypes.func.isRequired ,
    clearSignatures : PropTypes.func.isRequired ,
    closeSignatureProcess : PropTypes.func.isRequired ,
    completeSignatureProcess : PropTypes.func.isRequired ,
    openModal : PropTypes.func.isRequired ,
    storeResponse : PropTypes.func.isRequired ,
    storeSignatureResponse : PropTypes.func.isRequired ,
    storeTimestamp : PropTypes.func.isRequired ,
};

export default Process;

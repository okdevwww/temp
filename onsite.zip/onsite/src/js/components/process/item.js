/* items.js */

import Immutable from 'immutable';
import React , { PropTypes } from 'react';
import {
    Text ,
    View ,
} from 'react-native';

import { SKU_EXCEPTIONS_ENABLED } from './../../config/constants';
import { locale } from './../../config/locale';
import CheckButton from './../shared/checkbutton';
import iStyles from './../../styles/item-styles';

type ItemPropTypes = {
    item : Immutable.Map<string , any>;
    checkDeliveryItem : ( stopId : string , item : Object , value : string , exceptionId : string ) => void;
    openModal : ( modalType : string , modalProps : Object ) => void;
};

type ItemStateTypes = { };

class Item extends React.Component<any, ItemPropTypes, ItemStateTypes> {
    props : ItemPropTypes;
    state : ItemStateTypes;
    selectItem : ( value : string ) => void;

    constructor( props : ItemPropTypes ) : void {
        super( props );
        this.selectItem = this.selectItem.bind( this );
        this.openSkuExceptionModal = this.openSkuExceptionModal.bind( this );
        this.onCheckSkuException = this.onCheckSkuException.bind( this );
        this.onSelectException = this.onSelectException.bind( this );
    }

    componentDidUpdate() : void { }

    selectItem( value : string ) : void {
        this.props.checkDeliveryItem(
            this.props.item.get( "STOP_ID" ) ,
            this.props.item ,
            value ,
            "" ,
        );
        if ( value && ( value.toUpperCase() === locale.en_US.LOC_NO.toUpperCase() ) ) {
            this.openSkuExceptionModal();
        }
    }

    openSkuExceptionModal(): void {
        this.props.openModal(
            "deliveryException" ,
            {
                title : locale.en_US.LOC_SKU_EXCEPTION ,
                name : this.props.item.get( "DESCR50" ) ,
                sku : this.props.item.get( "sku_id" ) ,
                onClose : this.onCheckSkuException ,
                onSelect : this.onSelectException ,
            }
        );
    }

    onSelectException( exceptionId : string ) : void {
        this.props.checkDeliveryItem(
            this.props.item.get( "STOP_ID" ) ,
            this.props.item ,
            locale.en_US.LOC_NO ,
            exceptionId ,
        );
    }

    onCheckSkuException( skuId : string ) : Object { }

    render(): React.Element {
        //console.warn( JSON.stringify( this.props.item ) );
        var baseKey = "delivery-item-question-" + this.props.item.get( "STOP_ID" );
        var answerBaseKey = "answer-" + baseKey;
        var answerKey = answerBaseKey + "-";
        var checkedItem = ( ( this.props.item.get( "checked" ) !== undefined ) ? this.props.item.get( "checked" ) : false );
        var skuExceptionView = null;
        if ( SKU_EXCEPTIONS_ENABLED ) {
            var exceptionText = null;
            var exceptionKey = this.props.item.get( "selected_sku_exception" );
            if ( exceptionKey && locale.en_US[ exceptionKey ] ) {
                exceptionText = locale.en_US[ exceptionKey ];
            }
            skuExceptionView = (
                <View style={ iStyles.skuException }>
                    <Text>{ exceptionText }</Text>
                </View>
            );
        }
        return (
            <View style={ iStyles.item } >
                <View style={ iStyles.items } >
                    <Text style={ iStyles.itemName }>
                        { this.props.item.get( "DESCR50" ) }
                    </Text>
                </View>
                <View style={ iStyles.items } >
                    <Text style={ iStyles.itemLabel } >
                        { locale.en_US.LOC_SKU_NUMBER }
                    </Text>
                    <Text style={ iStyles.itemId } >
                        { this.props.item.get( "sku_id" ) }
                    </Text>
                    <Text style={ iStyles.itemLabel } >
                        { locale.en_US.LOC_BARCODE }
                    </Text>
                    <Text style={ iStyles.itemId } >
                        { this.props.item.get( "Barcode_id" ) }
                    </Text>
                </View>
                <View style={ iStyles.answers }>
                    <View key={ answerKey + locale.en_US.LOC_YES } style={ iStyles.checkbutton }>
                        <CheckButton
                            selected={ ! this.props.item.get( "hasUserInput" ) || checkedItem }
                            onSelect={ this.selectItem }
                            value={ locale.en_US.LOC_YES }
                            />
                    </View>
                    <View key={ answerKey + locale.en_US.LOC_NO } style={ iStyles.checkbutton }>
                        <CheckButton
                            id={ this.props.item.get( "sku_id" ) }
                            selected={ ! checkedItem && this.props.item.get( "hasUserInput" ) }
                            onSelect={ this.selectItem }
                            value={ locale.en_US.LOC_NO }
                            />
                    </View>
                    { skuExceptionView }
                </View>
            </View>
        );
    }
}

Item.propTypes = {
    checkDeliveryItem : PropTypes.func.isRequired ,
    item : PropTypes.object.isRequired ,
    openModal : PropTypes.func.isRequired ,
};

export default Item;





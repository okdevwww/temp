/* group.js */

import Immutable from 'immutable';
import React , { PropTypes } from 'react';
import { Text , View } from 'react-native';

import Item from './item';
import gStyles from './../../styles/group-styles';

type GroupPropTypes = {
    group: Immutable.Map<string , any>;
    items: Immutable.List<Immutable.Map<string , any>>;
    checkDeliveryItem : ( stopId : string , item : Object , value : string , exceptionId : string ) => void;
    openModal : ( modalType : string , modalProps : Object ) => void;
};

type GroupStateTypes = { };

class Group extends React.Component<any , GroupPropTypes , GroupStateTypes> {
    props : GroupPropTypes;
    state : GroupPropTypes;

    constructor( props : GroupPropTypes ) : void {
        super( props );
    }

    render() : React.Element {
        return (
            <View style={ gStyles.group } >
               <View><Text style={ gStyles.groupTitle }>{ this.props.group }</Text></View>
                {
                    this.props.items && this.props.items.map(
                        ( item , index ) => {
                            return (
                                <Item
                                    key={ "item-" + index }
                                    item={ item }
                                    checkDeliveryItem={ this.props.checkDeliveryItem }
                                    openModal={ this.props.openModal }
                                    />
                            );
                        }
                    ).toArray()
                }
            </View>
        );
    }
}

Group.propTypes = {
    group : PropTypes.string.isRequired ,
    items : PropTypes.object.isRequired ,
    checkDeliveryItem : PropTypes.func.isRequired ,
    openModal : PropTypes.func.isRequired ,
};

export default Group;

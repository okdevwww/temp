/* process-factory.js */

import React from 'react';
import {
    View ,
    Text ,
} from 'react-native';

import {
    DEFAULT_SYNC_TITLE_TEXT ,
    DEFAULT_SYNC_MESSAGE_TEXT ,
    PROCESS_CHECKLIST ,
    PROCESS_DELIVERY_SETUP ,
    PROCESS_KEY_RETURN ,
    PROCESS_KEYS ,
    PROCESS_SIGNATURE ,
 } from './../../config/constants';
import ProcessProvider from './../containers/process-provider';
import pStyles from './../../styles/process-styles';

class ProcessFactory {
    static getProcess( processId : string , stopId : string ) : ? React.Element<any> {
        var factoryComponent = (
            <View>
                <Text>In progress</Text>
            </View>
        );
        if ( PROCESS_KEYS.indexOf( processId ) >= 0 ) {
            // process defaults...
            var props = { };
            props.stopId = stopId;
            props.process = processId;
            props.hasRooms = props.hasSignature = props.hasGroups = false;
            props.sync = {
                titleText : DEFAULT_SYNC_TITLE_TEXT ,
                messageText : DEFAULT_SYNC_MESSAGE_TEXT ,
                refreshConnection : false ,
                nextAction : null ,
            };
            // then handle process exceptions...
            switch ( processId ) {
                case PROCESS_DELIVERY_SETUP :
                    props.hasGroups = true;
                    break;
                case PROCESS_CHECKLIST :
                    props.hasRooms = true;
                    break;
                case PROCESS_SIGNATURE :
                    props.hasSignature = true;
                    break;
                case PROCESS_KEY_RETURN :
                    props.sync = {
                        titleText : "Stop Complete" ,
                        messageText : "Please confirm that the stop is complete and key is returned." ,
                        refreshConnection : false ,
                        nextAction : "pop" ,
                    };
                    break;
            }
            factoryComponent = React.createFactory( ProcessProvider )( props );
        }
        return factoryComponent;
    }
}

export default ProcessFactory;

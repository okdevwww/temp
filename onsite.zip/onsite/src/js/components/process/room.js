/* room.js */

import React , { PropTypes } from 'react';
import {
    View ,
    Text ,
} from 'react-native';
import Question from './question';
import rStyles from './../../styles/room-styles';

type RoomPropTypes = {
    driverId : string;
    stopId : string;
    roomTitle : string;
    questions : Immutable.List<Immutable.Map<string , any>>;
    pictures : Immutable.List<Immutable.Map<string , any>>;
    storeResponse : ( checklistInstanceId : string , question : Immutable.Map<string , any> , choice : string , stopId : string ) => void;
    onSync : ( driverId : string ) => void;
    onAddPicture : ( stopId : string , question : Object , section : string , picture : Object ) => void;
    onDeletePicture : (stopId : string , process : string , questionId : string , picture : Object ) => void;
};

type RoomStateTypes = { };

class Room extends React.Component<any , RoomPropTypes , RoomStateTypes> {
    props : RoomPropTypes;
    state : RoomStateTypes;

    constructor( props : RoomPropTypes ) : void {
        super( props );
        this.getTitleText = this.getTitleText.bind( this );
    }

    getTitleText( baseKey ) : React.Element {
        var result = null;
        if ( this.props.roomTitle ) {
            var titleKey = baseKey + "-room-title";
            result = (
                <View><Text key={ titleKey } style={ rStyles.roomTitle } >{ this.props.roomTitle }</Text></View>
            );
        }
        return result;
    }

    render(): React.Element {
        var questionRows = [];
        var baseKey = "room-" + this.props.stopId;
        this.props.questions.map(
            ( question , questionIndex ) => {
                var questionId = question.get( "Name" ) + "-" + this.props.stopId;
                var questionKey = baseKey + "-question-" + questionIndex;
                questionRows.push(
                    <Question
                        key={ questionKey }
                        stopKey={ this.props.stopId }
                        question={ question }
                        driverId={ this.props.driverId }
                        onSync={ this.props.onSync }
                        storeResponse={ this.props.storeResponse }
                        onAddPicture={ this.props.onAddPicture }
                        onDeletePicture={ this.props.onDeletePicture }
                        pictures={ this.props.pictures }
                        />
                );
            }
        );
        var titleText = this.getTitleText( baseKey );
        return (
            <View>
                { titleText }
                { questionRows }
            </View>
        );
    }
}

Room.propTypes = {
    driverId : PropTypes.string.isRequired ,
    stopId : PropTypes.string.isRequired ,
    questions : PropTypes.object.isRequired ,
    pictures : PropTypes.object.isRequired ,
    storeResponse : PropTypes.func.isRequired ,
    onSync : PropTypes.func.isRequired ,
    onAddPicture : PropTypes.func.isRequired ,
    onDeletePicture : PropTypes.func.isRequired ,
    roomTitle : PropTypes.string.isRequired ,
};

export default Room;

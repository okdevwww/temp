/* signature.js */

import Immutable from 'immutable';
import React , { PropTypes } from 'react';
import {
    View ,
    Text ,
    Image ,
} from 'react-native';
import SignatureCapture from 'react-native-signature-capture';

import {
    TIMESTAMP_SIGNATURE_CUSTOMER ,
    TIMESTAMP_SIGNATURE_DRIVER ,
} from './../../config/constants';
import { locale } from './../../config/locale';
import Button from './../shared/button';
import sStyles from './../../styles/signature-styles';

type SignaturePropTypes = {
    driverId : string;
    stopId : string;
    question : Object;
    signature : Immutable.Map<string , any>;
    clearSignatures : ( driverId : string , stopId : string ) => void;
    closeSignatureProcess : ( driverId : string , stopId : string ) => void;
    completeSignatureProcess : ( driverId : string , stopId : string ) => void;
    openModal : ( modalType : string , modalProps : Object ) => void;
    storeSignatureResponse : ( checklistInstanceId : string , question : Object , choice : string , stopId : string , signature : Object ) => void;
    storeTimestamp : ( stopId : string , signature : Object ) => void;
};

type SignatureStateTypes = {
    customerSigned : boolean;
    driverSigned : boolean;
};

class Signature extends React.PureComponent<any , SignaturePropTypes , SignatureStateTypes> {
    props : SignaturePropTypes;
    state : SignatureStateTypes;

    constructor( props : SignaturePropTypes ) : void {
        super( props );
        this.onClose = this.onClose.bind( this );
        this.onClear = this.onClear.bind( this );
        this.onSave = this.onSave.bind( this );
        this.saveSignatures = this.saveSignatures.bind( this );
        this.getSignatureCapture = this.getSignatureCapture.bind( this );
        this.onSaveDriverSign = this.onSaveDriverSign.bind( this );
        this.onSaveCustomerSign = this.onSaveCustomerSign.bind( this );
        this.onDragEventDriver = this.onDragEventDriver.bind( this );
        this.onDragEventCustomer = this.onDragEventCustomer.bind( this );
        this.state = {
            customerSigned : false ,
            driverSigned : false ,
        };
    }

    onClose() : void {
        this.props.closeSignatureProcess( this.props.driverId , this.props.stopId );
    }

    onSave() : void {
        if ( ( ( this.props.signature.get( "customerSignature" ) === null ) && this.state.customerSigned )
            || ( ( this.props.signature.get( "driverSignature" ) === null ) && this.state.driverSigned )
            )
        {
            this.props.openModal(
                "confirmation" ,
                {
                    title : "Confirm save signature" ,
                    text : "Are you sure you want to save this signature?" ,
                    cancelText : "NO" ,
                    confirmText : "YES" ,
                    onClose : this.saveSignatures ,
                }
            );
        }
    }

    saveSignatures() : void {
        if ( ( this.props.signature.get( "customerSignature" ) === null ) && this.state.customerSigned ) {
            this.refs.customerSign.saveImage();
        }
        if ( ( this.props.signature.get( "driverSignature" ) === null ) && this.state.driverSigned ) {
            this.refs.driverSign.saveImage();
        }
        this.props.completeSignatureProcess( this.props.driverId , this.props.stopId );
    }

    onClear() : void {
        this.setState(
            {
                driverSigned : false ,
                customerSigned : false ,
            }
        );
        if ( this.refs.driverSign ) {
            this.refs.driverSign.resetImage();
        }
        if ( this.refs.customerSign ) {
            this.refs.customerSign.resetImage();
        }
        this.props.clearSignatures( this.props.driverId , this.props.stopId );
    }

    getSignatureCapture( signatureTitle : string , signatureKey : string , signatureRef : string , onSaveSignature : func , onDragSignature : func ) : React.Element {
        if ( this.props.signature.get( signatureKey ) === null ) {
            return (
                <View style={ sStyles.captureContainer } >
                    <View style={ sStyles.titleView } >
                        <Text style={ sStyles.titleText } >
                            { signatureTitle }
                        </Text>
                    </View>
                    <View style={ sStyles.signatureCapture } >
                        <SignatureCapture
                            ref={ signatureRef }
                            onSaveEvent={ onSaveSignature }
                            onDragEvent={ onDragSignature }
                            saveImageFileInExtStorage={ true }
                            showNativeButtons={ false }
                            viewMode={ "portrait" }
                            />
                    </View>
                </View>
            );
        }
        return (
            <Image
                source={ this.props.signature.get( signatureKey ) }
                style={ sStyles.signatureImage }
                />
        );
    }

    getCustomerSignature() : React.Element {
        return this.getSignatureCapture(
            "Customer" ,
            "customerSignature" ,
            "customerSign" ,
            this.onSaveCustomerSign ,
            this.onDragEventCustomer ,
        );
    }

    getDriverSignature() : React.Element {
        return this.getSignatureCapture(
            "Driver" ,
            "driverSignature" ,
            "driverSign" ,
            this.onSaveDriverSign ,
            this.onDragEventDriver ,
        );
    }

    onSaveCustomerSign( response : Object ) : void {
        const source = {
            uri : "data:image/png;base64," + response.encoded ,
            isStatic : true ,
            pathOnClient : response.pathName ,
            versionData : response.encoded ,
        };
        this.props.storeSignatureResponse( this.props.question.get( "Checklist_Instance__c.Id" ) , this.props.question , "Customer" , this.props.stopId , source , this.props.driverId );
        this.props.storeTimestamp( this.props.stopId , TIMESTAMP_SIGNATURE_CUSTOMER );
    }

    onSaveDriverSign( response : Object ) : void {
        const source = {
            uri : "data:image/png;base64," + response.encoded ,
            isStatic : true ,
            pathOnClient : response.pathName ,
            versionData : response.encoded ,
        };
        this.props.storeSignatureResponse( this.props.question.get( "Checklist_Instance__c.Id" ) , this.props.question , "Driver" , this.props.stopId , source , this.props.driverId );
        this.props.storeTimestamp( this.props.stopId , TIMESTAMP_SIGNATURE_DRIVER );
    }

    onDragEventCustomer() : void {
        this.setState( { customerSigned : true } );
    }

    onDragEventDriver() : void {
        this.setState( { driverSigned : true } );
    }

    getButtons() : React.Element {
        return (
            <View style={ sStyles.buttonsContainer } >
                <Button
                    enabled={ true }
                    theme="white"
                    type="signature"
                    text={ locale.en_US.LOC_CLEAR }
                    onPress={ this.onClear }
                    />
                <Button
                    enabled={ true }
                    theme="grey"
                    type="signature"
                    text={ locale.en_US.LOC_CLOSE }
                    onPress={ this.onClose }
                    />
                <Button
                    enabled={ true }
                    theme="red"
                    type="signature"
                    text={ locale.en_US.LOC_SAVE }
                    onPress={ this.onSave }
                    />
            </View>
        );
    }

    render() : React.Element {
        return (
            <View style={ sStyles.container } >
                { this.getButtons() }
                <View style={ sStyles.spacer } />
                <View style={ sStyles.signaturesContainer } >
                    { this.getCustomerSignature() }
                    <View style={ sStyles.spacer } />
                    { this.getDriverSignature() }
                </View>
            </View>
        );
    }
}

Signature.propTypes = {
    question : PropTypes.object.isRequired ,
    signature : PropTypes.object.isRequired ,
    stopId : PropTypes.string.isRequired ,
    storeTimestamp : PropTypes.func.isRequired ,
    clearSignatures : PropTypes.func.isRequired ,
    closeSignatureProcess : PropTypes.func.isRequired ,
    completeSignatureProcess : PropTypes.func.isRequired ,
    openModal : PropTypes.func.isRequired ,
    storeSignatureResponse : PropTypes.func.isRequired ,
};

export default Signature;
